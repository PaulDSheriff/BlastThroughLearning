'*************************************************************
'* Copyright (C) 2002, PDSA, Inc.
'* www.pdsa.com
'* All rights reserved.
'*
'* The code contained herein is intended for teaching
'* concepts and as a supplement to PDSA, Inc.
'* books and teaching materials only.
'*
'* THIS CODE AND INFORMATION IS PROVIDED "AS IS"
'* WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED 
'* OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
'* WARRANTIES OF MERCHANTABILITY AND/OR FITNESS 
'* FOR A PARTICULAR PURPOSE.
'*************************************************************
Public Class CustCatSales
  Inherits WebPageBase
  Protected WithEvents Label1 As System.Web.UI.WebControls.Label
  Protected WithEvents hypHome As System.Web.UI.WebControls.HyperLink
  Protected WithEvents grdCatSales As System.Web.UI.WebControls.DataGrid

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    If Not Page.IsPostBack Then
      CategoryLoad()
      GridLoad()
    End If
  End Sub

  Private Sub CategoryLoad()
    Dim ds As DataSet
    Dim strSQL As String

    ' Set up SQL and Connection strings.
    strSQL = "SELECT * FROM [Sales By Category]"

    ' Create DataSet and 
    ' store DataSet into Session variable
    Session("DS") = DataHandler.GetDataSet(strSQL, _
     WebAppConfig.ConnectString)
  End Sub

  Private Sub GridLoad()
    Dim ds As DataSet

    ' Get default view from stored DataSet
    ds = CType(Session("DS"), DataSet)

    ' Fill in DataSource and bind to data.
    grdCatSales.DataSource = ds
    grdCatSales.DataBind()
  End Sub
End Class
