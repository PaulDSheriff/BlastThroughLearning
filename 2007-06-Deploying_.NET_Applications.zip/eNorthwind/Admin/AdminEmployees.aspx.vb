'*************************************************************
'* Copyright (C) 2002, PDSA, Inc.
'* www.pdsa.com
'* All rights reserved.
'*
'* The code contained herein is intended for teaching
'* concepts and as a supplement to PDSA, Inc.
'* books and teaching materials only.
'*
'* THIS CODE AND INFORMATION IS PROVIDED "AS IS"
'* WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED 
'* OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
'* WARRANTIES OF MERCHANTABILITY AND/OR FITNESS 
'* FOR A PARTICULAR PURPOSE.
'*************************************************************
Public Class AdminEmployees
  Inherits WebPageBase

  Protected WithEvents lblEmpMaint As System.Web.UI.WebControls.Label
  Protected WithEvents lblFirst As System.Web.UI.WebControls.Label
  Protected WithEvents txtFirst As System.Web.UI.WebControls.TextBox
  Protected WithEvents lblLast As System.Web.UI.WebControls.Label
  Protected WithEvents txtLast As System.Web.UI.WebControls.TextBox
  Protected WithEvents lblBirthDate As System.Web.UI.WebControls.Label
  Protected WithEvents txtBirthDate As System.Web.UI.WebControls.TextBox
  Protected WithEvents lblHireDate As System.Web.UI.WebControls.Label
  Protected WithEvents txtHireDate As System.Web.UI.WebControls.TextBox
  Protected WithEvents lblCity As System.Web.UI.WebControls.Label
  Protected WithEvents txtCity As System.Web.UI.WebControls.TextBox
  Protected WithEvents Label1 As System.Web.UI.WebControls.Label
  Protected WithEvents txtState As System.Web.UI.WebControls.TextBox
  Protected WithEvents lblPostal As System.Web.UI.WebControls.Label
  Protected WithEvents txtZipCode As System.Web.UI.WebControls.TextBox
  Protected WithEvents Label2 As System.Web.UI.WebControls.Label
  Protected WithEvents txtHomePhone As System.Web.UI.WebControls.TextBox
  Protected WithEvents btnSave As System.Web.UI.WebControls.Button

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub Page_Load( _
    ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles MyBase.Load

  End Sub

  Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
    Server.Transfer("/Admin/AdminMain.aspx")
  End Sub
End Class
