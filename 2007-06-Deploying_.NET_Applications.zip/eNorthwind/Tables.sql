CREATE TABLE WebErrorLog
(
lError_id int IDENTITY (1, 1) NOT NULL PRIMARY KEY,
szUser_nm varchar(50) NULL, 
szPage_nm varchar(50) NULL, 
dtError_dt datetime NULL,
szSite_nm varchar(50) NULL,
szError_tx varchar(2500) NULL
)
GO

CREATE TABLE WebUserLog
(
lUserLog_id int IDENTITY (1, 1) NOT NULL PRIMARY KEY,
szUser_nm varchar(50) NULL,
szPage_nm varchar(50) NULL,
szSite_nm varchar(50) NULL,
dtEntry_dt datetime NULL
)
GO

CREATE TABLE WebMenus
(
lMenuItem_id int NOT NULL PRIMARY KEY,
sMenu_nm char(16) NULL,
szMenu_tx varchar(50) NULL,
szAction_tx varchar(255) NULL,
iSeq_no smallint NULL,
szSite_nm varchar(50) NULL
)
GO

Print 'INSERTing data into WebMenus'
Go
INSERT INTO WebMenus (lMenuItem_id,sMenu_nm,szMenu_tx,szAction_tx,iSeq_no,szSite_nm) VALUES(1,'MAIN','Admin','/Admin/AdminMain.aspx',20,'eNorthwind') 
INSERT INTO WebMenus (lMenuItem_id,sMenu_nm,szMenu_tx,szAction_tx,iSeq_no,szSite_nm) VALUES(2,'MAIN','Home','/Default.aspx',10,'eNorthwind') 
INSERT INTO WebMenus (lMenuItem_id,sMenu_nm,szMenu_tx,szAction_tx,iSeq_no,szSite_nm) VALUES(3,'MAIN','Products','/Products/ProductsMain.aspx',30,'eNorthwind') 
INSERT INTO WebMenus (lMenuItem_id,sMenu_nm,szMenu_tx,szAction_tx,iSeq_no,szSite_nm) VALUES(4,'MAIN','Customers','/Cust/CustomersMain.aspx',40,'eNorthwind') 
INSERT INTO WebMenus (lMenuItem_id,sMenu_nm,szMenu_tx,szAction_tx,iSeq_no,szSite_nm) VALUES(5,'ADMINMAIN','Home','/Default.aspx',10,'eNorthwind') 
INSERT INTO WebMenus (lMenuItem_id,sMenu_nm,szMenu_tx,szAction_tx,iSeq_no,szSite_nm) VALUES(6,'ADMINMAIN','Employee Maint','/Admin/AdminEmployees.aspx',20,'eNorthwind') 
INSERT INTO WebMenus (lMenuItem_id,sMenu_nm,szMenu_tx,szAction_tx,iSeq_no,szSite_nm) VALUES(7,'ADMINMAIN','Change password','/Admin/AdminPwdChange.aspx',30,'eNorthwind') 
INSERT INTO WebMenus (lMenuItem_id,sMenu_nm,szMenu_tx,szAction_tx,iSeq_no,szSite_nm) VALUES(8,'CUSTMAIN','Home','/Default.aspx',10,'eNorthwind') 
INSERT INTO WebMenus (lMenuItem_id,sMenu_nm,szMenu_tx,szAction_tx,iSeq_no,szSite_nm) VALUES(9,'CUSTMAIN','Sales by Category','/Cust/CustCatSales.aspx',20,'eNorthwind') 
INSERT INTO WebMenus (lMenuItem_id,sMenu_nm,szMenu_tx,szAction_tx,iSeq_no,szSite_nm) VALUES(10,'PRODMAIN','Home','/Default.aspx',10,'eNorthwind') 
INSERT INTO WebMenus (lMenuItem_id,sMenu_nm,szMenu_tx,szAction_tx,iSeq_no,szSite_nm) VALUES(11,'PRODMAIN','Products','/Products/Products.aspx',20,'eNorthwind') 
INSERT INTO WebMenus (lMenuItem_id,sMenu_nm,szMenu_tx,szAction_tx,iSeq_no,szSite_nm) VALUES(12,'PRODMAIN','Edit Products','/Products/ProductsEdit.aspx',30,'eNorthwind') 
INSERT INTO WebMenus (lMenuItem_id,sMenu_nm,szMenu_tx,szAction_tx,iSeq_no,szSite_nm) VALUES(13,'MAIN','Testing','/Testing.aspx',50,'eNorthwind') 
INSERT INTO WebMenus (lMenuItem_id,sMenu_nm,szMenu_tx,szAction_tx,iSeq_no,szSite_nm) VALUES(14,'PRODMAIN','Sales of Products','/Products/ProductsSales.aspx',40,'eNorthwind') 
GO