Public Class MyNewBase
  Inherits System.Web.UI.Page


End Class
