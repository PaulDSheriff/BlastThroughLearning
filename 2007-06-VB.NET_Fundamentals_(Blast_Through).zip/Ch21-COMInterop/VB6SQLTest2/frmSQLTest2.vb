
Public Class Form1
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub
  Friend WithEvents grdDemo As System.Windows.Forms.DataGrid
  Friend WithEvents btnTest As System.Windows.Forms.Button

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.btnTest = New System.Windows.Forms.Button()
    Me.grdDemo = New System.Windows.Forms.DataGrid()
    CType(Me.grdDemo, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'btnTest
    '
    Me.btnTest.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left)
    Me.btnTest.Location = New System.Drawing.Point(8, 200)
    Me.btnTest.Name = "btnTest"
    Me.btnTest.Size = New System.Drawing.Size(112, 32)
    Me.btnTest.TabIndex = 1
    Me.btnTest.Text = "Test"
    '
    'grdDemo
    '
    Me.grdDemo.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right)
    Me.grdDemo.CaptionText = "Data from VB6 Component"
    Me.grdDemo.DataMember = ""
    Me.grdDemo.Location = New System.Drawing.Point(4, 0)
    Me.grdDemo.Name = "grdDemo"
    Me.grdDemo.Size = New System.Drawing.Size(448, 184)
    Me.grdDemo.TabIndex = 0
    '
    'Form1
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
    Me.ClientSize = New System.Drawing.Size(440, 245)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnTest, Me.grdDemo})
    Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Name = "Form1"
    Me.Text = "VB6 Legacy Test"
    CType(Me.grdDemo, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)

  End Sub

#End Region

  Private Sub btnTest_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles btnTest.Click
        Dim ovb As New VB6SQL.Products()

    Dim dt As DataTable
    Dim ds As New DataSet()

    ' Use StringReader object to retrieve data.
    ' Get the data from COM, in DataSet format.
    Dim sr As New System.IO.StringReader(ovb.GetDataTableXML)

    ' Send the StringReader object's data into the dataset, 
    ' filling it with data.
    ds.ReadXml(sr)

    grdDemo.PreferredColumnWidth = DataGrid.AutoColumnSize
    grdDemo.DataSource = ds.Tables(0)
  End Sub
End Class
