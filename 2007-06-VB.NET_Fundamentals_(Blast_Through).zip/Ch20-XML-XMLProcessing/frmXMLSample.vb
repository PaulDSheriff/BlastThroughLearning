Public Class frmXMLSample
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Public Overloads Overrides Sub Dispose()
        MyBase.Dispose()
        If Not (components Is Nothing) Then
            components.Dispose()
        End If
    End Sub
    Private WithEvents btnLoad As System.Windows.Forms.Button
    Private WithEvents btnSelectSingleNode As System.Windows.Forms.Button
    Private WithEvents btnSelectNodes As System.Windows.Forms.Button
    Private WithEvents btnReadAttribute As System.Windows.Forms.Button
    Private WithEvents btnUpdateElement As System.Windows.Forms.Button
    Private WithEvents btnUpdateAttribute As System.Windows.Forms.Button
        
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThroughAttribute()> Private Sub InitializeComponent()
        Me.btnUpdateAttribute = New System.Windows.Forms.Button()
        Me.btnUpdateElement = New System.Windows.Forms.Button()
        Me.btnSelectSingleNode = New System.Windows.Forms.Button()
        Me.btnLoad = New System.Windows.Forms.Button()
        Me.btnReadAttribute = New System.Windows.Forms.Button()
        Me.btnSelectNodes = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnUpdateAttribute
        '
        Me.btnUpdateAttribute.Location = New System.Drawing.Point(8, 248)
        Me.btnUpdateAttribute.Name = "btnUpdateAttribute"
        Me.btnUpdateAttribute.Size = New System.Drawing.Size(248, 40)
        Me.btnUpdateAttribute.TabIndex = 6
        Me.btnUpdateAttribute.Text = "Update Attribute"
        '
        'btnUpdateElement
        '
        Me.btnUpdateElement.Location = New System.Drawing.Point(8, 200)
        Me.btnUpdateElement.Name = "btnUpdateElement"
        Me.btnUpdateElement.Size = New System.Drawing.Size(248, 40)
        Me.btnUpdateElement.TabIndex = 5
        Me.btnUpdateElement.Text = "Update Element"
        '
        'btnSelectSingleNode
        '
        Me.btnSelectSingleNode.Location = New System.Drawing.Point(8, 56)
        Me.btnSelectSingleNode.Name = "btnSelectSingleNode"
        Me.btnSelectSingleNode.Size = New System.Drawing.Size(248, 40)
        Me.btnSelectSingleNode.TabIndex = 1
        Me.btnSelectSingleNode.Text = "Select Single Node"
        '
        'btnLoad
        '
        Me.btnLoad.Location = New System.Drawing.Point(8, 8)
        Me.btnLoad.Name = "btnLoad"
        Me.btnLoad.Size = New System.Drawing.Size(248, 40)
        Me.btnLoad.TabIndex = 0
        Me.btnLoad.Text = "Load XML Document"
        '
        'btnReadAttribute
        '
        Me.btnReadAttribute.Location = New System.Drawing.Point(8, 152)
        Me.btnReadAttribute.Name = "btnReadAttribute"
        Me.btnReadAttribute.Size = New System.Drawing.Size(248, 40)
        Me.btnReadAttribute.TabIndex = 4
        Me.btnReadAttribute.Text = "Read Attribute"
        '
        'btnSelectNodes
        '
        Me.btnSelectNodes.Location = New System.Drawing.Point(8, 104)
        Me.btnSelectNodes.Name = "btnSelectNodes"
        Me.btnSelectNodes.Size = New System.Drawing.Size(248, 40)
        Me.btnSelectNodes.TabIndex = 3
        Me.btnSelectNodes.Text = "Select Nodes"
        '
        'frmXMLSample
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(264, 298)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnUpdateAttribute, Me.btnUpdateElement, Me.btnReadAttribute, Me.btnSelectNodes, Me.btnSelectSingleNode, Me.btnLoad})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmXMLSample"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "XMLDocument Samples"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoad.Click
        Dim xd As System.Xml.XmlDocument

        xd = New System.Xml.XmlDocument()

        xd.Load(GetFileNameAndPath())

        MessageBox.Show(xd.InnerXml)
        MessageBox.Show(xd.InnerText)
    End Sub

    Private Sub btnSelectSingleNode_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelectSingleNode.Click
        Dim xd As System.Xml.XmlDocument
        Dim strXPath As String
        Dim oNode As System.Xml.XmlNode

        ' Create new XmlDocument
        xd = New System.Xml.XmlDocument()
        ' Load File
        xd.Load(GetFileNameAndPath())

        strXPath = "/contact/name/first"
        ' Get a Single Node
        oNode = xd.SelectSingleNode(strXPath)

        MessageBox.Show(oNode.InnerXml)
        MessageBox.Show(oNode.OuterXml)
    End Sub

    Private Sub btnSelectNodes_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelectNodes.Click
        Dim xd As System.Xml.XmlDocument
        Dim strXPath As String
        Dim oNodeList As System.Xml.XmlNodeList
        Dim intLoop As Integer

        xd = New System.Xml.XmlDocument()
        xd.Load(GetFileNameAndPath())

        strXPath = "/contact/email"

        ' Get Node Collection
        oNodeList = xd.SelectNodes(strXPath)

        MessageBox.Show(oNodeList.Count)

        For intLoop = 0 To oNodeList.Count - 1
            MessageBox.Show(oNodeList.Item(intLoop).InnerXml)
        Next
    End Sub

    Private Sub btnReadAttribute_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReadAttribute.Click
        Dim xd As System.Xml.XmlDocument
        Dim strXPath As String
        Dim oNode As System.Xml.XmlNode

        xd = New System.Xml.XmlDocument()
        xd.Load(GetFileNameAndPath())

        strXPath = "/contact/address/@city"
        oNode = xd.SelectSingleNode(strXPath)

        MessageBox.Show(oNode.OuterXml)
        MessageBox.Show(oNode.InnerXml)
    End Sub

    Private Sub btnUpdateElement_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdateElement.Click
        Dim xd As System.Xml.XmlDocument
        Dim strXPath As String
        Dim oNode As System.Xml.XmlNode

        xd = New System.Xml.XmlDocument()
        xd.Load(GetFileNameAndPath())
        MessageBox.Show(xd.InnerXml)

        strXPath = "/contact/name/first"
        oNode = xd.SelectSingleNode(strXPath)

        MessageBox.Show(oNode.OuterXml)

        oNode.InnerText = "Roberto"

        MessageBox.Show(oNode.OuterXml)
        MessageBox.Show(xd.InnerXml)

        'xd.Save(GetFileNameAndPath())
    End Sub

    Private Sub btnUpdateAttribute_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdateAttribute.Click
        Dim xd As System.Xml.XmlDocument
        Dim strXPath As String
        Dim oNode As System.Xml.XmlNode

        xd = New System.Xml.XmlDocument()
        xd.Load(GetFileNameAndPath())
        MessageBox.Show(xd.InnerXml)

        strXPath = "/contact/address/@city"
        oNode = xd.SelectSingleNode(strXPath)
        MessageBox.Show(oNode.OuterXml)

        oNode.InnerText = "Lake Forest"

        MessageBox.Show(oNode.OuterXml)
        MessageBox.Show(xd.InnerXml)
    End Sub
End Class
