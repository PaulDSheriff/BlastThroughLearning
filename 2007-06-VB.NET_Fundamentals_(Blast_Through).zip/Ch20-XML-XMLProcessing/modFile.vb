Module modFile

    Public Function GetFileNameAndPath() As String
        Dim strFile As String

        ' Executable Path returns everything including 
        ' the name of the .EXE
        strFile = Application.ExecutablePath
#If DEBUG Then
        ' Look for the \bin\ and get everything 
        ' up to that location
        strFile = strFile.Substring(0, strFile.LastIndexOf("\bin\")) & "\"
#End If

        ' Add on the file name
        strFile &= "Contact.xml"

        Return strFile
    End Function

    Public Function GetPath() As String
        Dim strFile As String

        ' Executable Path returns everything including 
        ' the name of the .EXE
        strFile = Application.ExecutablePath
#If DEBUG Then
        ' Look for the \bin\ and get everything 
        ' up to that location
        strFile = strFile.Substring(0, strFile.LastIndexOf("\bin\"))
#End If

        ' Add on backslash
        strFile &= "\"

        Return strFile
    End Function

End Module
