Public Class frmDataSetsXML
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents btnRead As System.Windows.Forms.Button
    Friend WithEvents btnWrite As System.Windows.Forms.Button
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tpgData As System.Windows.Forms.TabPage
    Friend WithEvents tpgXML As System.Windows.Forms.TabPage
    Friend WithEvents tpgSchema As System.Windows.Forms.TabPage
    Friend WithEvents grdProducts As System.Windows.Forms.DataGrid
    Friend WithEvents txtXML As System.Windows.Forms.TextBox
    Friend WithEvents txtSchema As System.Windows.Forms.TextBox

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.txtSchema = New System.Windows.Forms.TextBox()
        Me.btnWrite = New System.Windows.Forms.Button()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.tpgData = New System.Windows.Forms.TabPage()
        Me.grdProducts = New System.Windows.Forms.DataGrid()
        Me.tpgXML = New System.Windows.Forms.TabPage()
        Me.txtXML = New System.Windows.Forms.TextBox()
        Me.tpgSchema = New System.Windows.Forms.TabPage()
        Me.btnRead = New System.Windows.Forms.Button()
        Me.TabControl1.SuspendLayout()
        Me.tpgData.SuspendLayout()
        CType(Me.grdProducts, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpgXML.SuspendLayout()
        Me.tpgSchema.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtSchema
        '
        Me.txtSchema.Location = New System.Drawing.Point(8, 8)
        Me.txtSchema.Multiline = True
        Me.txtSchema.Name = "txtSchema"
        Me.txtSchema.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtSchema.Size = New System.Drawing.Size(616, 184)
        Me.txtSchema.TabIndex = 0
        Me.txtSchema.Text = ""
        '
        'btnWrite
        '
        Me.btnWrite.Location = New System.Drawing.Point(16, 8)
        Me.btnWrite.Name = "btnWrite"
        Me.btnWrite.Size = New System.Drawing.Size(128, 48)
        Me.btnWrite.TabIndex = 0
        Me.btnWrite.Text = "Write"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.AddRange(New System.Windows.Forms.Control() {Me.tpgData, Me.tpgXML, Me.tpgSchema})
        Me.TabControl1.Location = New System.Drawing.Point(8, 64)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(640, 232)
        Me.TabControl1.TabIndex = 1
        '
        'tpgData
        '
        Me.tpgData.Controls.AddRange(New System.Windows.Forms.Control() {Me.grdProducts})
        Me.tpgData.Location = New System.Drawing.Point(4, 29)
        Me.tpgData.Name = "tpgData"
        Me.tpgData.Size = New System.Drawing.Size(632, 199)
        Me.tpgData.TabIndex = 0
        Me.tpgData.Text = "Data"
        '
        'grdProducts
        '
        Me.grdProducts.DataMember = ""
        Me.grdProducts.Location = New System.Drawing.Point(8, 8)
        Me.grdProducts.Name = "grdProducts"
        Me.grdProducts.Size = New System.Drawing.Size(616, 184)
        Me.grdProducts.TabIndex = 1
        '
        'tpgXML
        '
        Me.tpgXML.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtXML})
        Me.tpgXML.Location = New System.Drawing.Point(4, 4)
        Me.tpgXML.Name = "tpgXML"
        Me.tpgXML.Size = New System.Drawing.Size(632, 224)
        Me.tpgXML.TabIndex = 1
        Me.tpgXML.Text = "XML"
        '
        'txtXML
        '
        Me.txtXML.Location = New System.Drawing.Point(8, 8)
        Me.txtXML.Multiline = True
        Me.txtXML.Name = "txtXML"
        Me.txtXML.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtXML.Size = New System.Drawing.Size(616, 184)
        Me.txtXML.TabIndex = 0
        Me.txtXML.Text = ""
        '
        'tpgSchema
        '
        Me.tpgSchema.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtSchema})
        Me.tpgSchema.Location = New System.Drawing.Point(4, 4)
        Me.tpgSchema.Name = "tpgSchema"
        Me.tpgSchema.Size = New System.Drawing.Size(632, 224)
        Me.tpgSchema.TabIndex = 2
        Me.tpgSchema.Text = "Schema"
        '
        'btnRead
        '
        Me.btnRead.Location = New System.Drawing.Point(152, 8)
        Me.btnRead.Name = "btnRead"
        Me.btnRead.Size = New System.Drawing.Size(128, 48)
        Me.btnRead.TabIndex = 0
        Me.btnRead.Text = "Read"
        '
        'frmDataSetsXML
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(656, 298)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.TabControl1, Me.btnWrite, Me.btnRead})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmDataSetsXML"
        Me.Text = "DataSet to XML"
        Me.TabControl1.ResumeLayout(False)
        Me.tpgData.ResumeLayout(False)
        CType(Me.grdProducts, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpgXML.ResumeLayout(False)
        Me.tpgSchema.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnWrite_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnWrite.Click
        Dim oAdapter As OleDb.OleDbDataAdapter
        Dim oDS As DataSet
        Dim strSQL As String
        Dim strConn As String
        Dim intLoop As Integer

        Me.Cursor = Cursors.WaitCursor

        ' Get Connection String
        strConn = ConnectStringBuild()

        ' Build SQL String
        strSQL = "SELECT ProductID, ProductName "
        strSQL &= "FROM Products"


        oDS = New DataSet()
        Try
            ' Create New Data Adapter
            oAdapter = New OleDb.OleDbDataAdapter(strSQL, strConn)
            ' Fill Data Set From Adapter
            ' and assign table name
            oAdapter.Fill(oDS, "Products")

            ' Fill Grid
            '            grdProducts.PreferredColumnWidth = DataGrid.AutoColumnSize
            grdProducts.DataSource = oDS.Tables("Products")

            ' Put data into controls
            txtXML.Text = oDS.GetXml()
            txtSchema.Text = oDS.GetXmlSchema()

            ' Write Data to a File
            oDS.WriteXml(GetPath() & "Products.xml")
            oDS.WriteXmlSchema(GetPath() & "ProductsSchema.xml")

        Catch oException As Exception
            MessageBox.Show(oException.Message)

        End Try

        Me.Cursor = Cursors.Default
    End Sub

    Private Function ConnectStringBuild() As String
        Dim strConn As String

        strConn = "Provider=sqloledb;"
        strConn &= "Data Source=(local);"
        strConn &= "Initial Catalog=Northwind;"
        strConn &= "User ID=sa"

        Return strConn
    End Function

    Private Sub btnRead_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRead.Click
        Dim oDS As DataSet

        Me.Cursor = Cursors.WaitCursor

        oDS = New DataSet()

        ' Read data from file, get schema FIRST!
        'oDS.ReadXmlSchema(GetPath() & "ProductsSchema.xml")
        oDS.ReadXml(GetPath() & "Products.xml")

        ' Fill Grid
        grdProducts.DataSource = Nothing
        '        grdProducts.PreferredColumnWidth = DataGrid.AutoColumnSize
        grdProducts.DataSource = oDS.Tables("Products")

        ' Put data into controls
        txtXML.Text = oDS.GetXml()
        txtSchema.Text = oDS.GetXmlSchema()

        Me.Cursor = Cursors.Default
    End Sub
End Class
