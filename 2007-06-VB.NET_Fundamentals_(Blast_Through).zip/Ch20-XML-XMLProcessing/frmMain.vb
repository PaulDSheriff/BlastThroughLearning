Public Class frmMain
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents btnXMLDoc As System.Windows.Forms.Button
    Friend WithEvents btnXMLReader As System.Windows.Forms.Button
    Friend WithEvents btnADO As System.Windows.Forms.Button
    Friend WithEvents btnDataDoc As System.Windows.Forms.Button

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnXMLReader = New System.Windows.Forms.Button()
        Me.btnADO = New System.Windows.Forms.Button()
        Me.btnDataDoc = New System.Windows.Forms.Button()
        Me.btnXMLDoc = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnXMLReader
        '
        Me.btnXMLReader.Location = New System.Drawing.Point(160, 8)
        Me.btnXMLReader.Name = "btnXMLReader"
        Me.btnXMLReader.Size = New System.Drawing.Size(144, 56)
        Me.btnXMLReader.TabIndex = 0
        Me.btnXMLReader.Text = "XMLReader"
        '
        'btnADO
        '
        Me.btnADO.Location = New System.Drawing.Point(312, 8)
        Me.btnADO.Name = "btnADO"
        Me.btnADO.Size = New System.Drawing.Size(144, 56)
        Me.btnADO.TabIndex = 0
        Me.btnADO.Text = "DataSet and XML"
        '
        'btnDataDoc
        '
        Me.btnDataDoc.Location = New System.Drawing.Point(464, 8)
        Me.btnDataDoc.Name = "btnDataDoc"
        Me.btnDataDoc.Size = New System.Drawing.Size(144, 56)
        Me.btnDataDoc.TabIndex = 0
        Me.btnDataDoc.Text = "String to DataSet"
        '
        'btnXMLDoc
        '
        Me.btnXMLDoc.Location = New System.Drawing.Point(8, 8)
        Me.btnXMLDoc.Name = "btnXMLDoc"
        Me.btnXMLDoc.Size = New System.Drawing.Size(144, 56)
        Me.btnXMLDoc.TabIndex = 0
        Me.btnXMLDoc.Text = "XMLDocument"
        '
        'frmMain
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(616, 74)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnDataDoc, Me.btnADO, Me.btnXMLReader, Me.btnXMLDoc})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmMain"
        Me.Text = "XML Samples"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnXMLDoc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnXMLDoc.Click
        Dim frm As frmXMLSample

        frm = New frmXMLSample()

        frm.Show()
    End Sub

    Private Sub btnXMLReader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnXMLReader.Click
        Dim frm As frmXMLReader

        frm = New frmXMLReader()

        frm.Show()
    End Sub

    Private Sub btnADO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnADO.Click
        Dim frm As frmDataSetsXML

        frm = New frmDataSetsXML()

        frm.Show()
    End Sub

    Private Sub btnDataDoc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataDoc.Click
        Dim frm As frmStringToDataset

        frm = New frmStringToDataset()

        frm.Show()
    End Sub
End Class
