Imports System.Xml

Public Class frmXMLReader
    Inherits System.Windows.Forms.Form


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents btnRead As System.Windows.Forms.Button
    Friend WithEvents txtXML As System.Windows.Forms.TextBox
    Friend WithEvents btnWrite As System.Windows.Forms.Button

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnWrite = New System.Windows.Forms.Button()
        Me.btnRead = New System.Windows.Forms.Button()
        Me.txtXML = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btnWrite
        '
        Me.btnWrite.Location = New System.Drawing.Point(144, 8)
        Me.btnWrite.Name = "btnWrite"
        Me.btnWrite.Size = New System.Drawing.Size(128, 48)
        Me.btnWrite.TabIndex = 0
        Me.btnWrite.Text = "Write"
        '
        'btnRead
        '
        Me.btnRead.Location = New System.Drawing.Point(8, 8)
        Me.btnRead.Name = "btnRead"
        Me.btnRead.Size = New System.Drawing.Size(128, 48)
        Me.btnRead.TabIndex = 0
        Me.btnRead.Text = "Read"
        '
        'txtXML
        '
        Me.txtXML.Location = New System.Drawing.Point(8, 64)
        Me.txtXML.Multiline = True
        Me.txtXML.Name = "txtXML"
        Me.txtXML.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtXML.Size = New System.Drawing.Size(496, 200)
        Me.txtXML.TabIndex = 1
        Me.txtXML.Text = ""
        '
        'frmXMLReader
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(512, 274)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnWrite, Me.txtXML, Me.btnRead})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmXMLReader"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "XMLReader Samples"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Const conURL As String = "http://localhost/PKXMLReaderApp/Contact.xml"

    Private Sub btnRead_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRead.Click
        Dim oXML As XmlTextReader
        Dim strXML As String

        Try
            'oXML = New XmlTextReader(conURL)
            oXML = New XmlTextReader(GetFileNameAndPath())

            Do While oXML.Read()
                Select Case oXML.NodeType
                    'Display beginning of element
                Case XmlNodeType.Element
                        strXML &= "<" + oXML.Name
                        If oXML.HasAttributes Then
                            While oXML.MoveToNextAttribute()
                                'Display attribute name and value.
                                strXML &= String.Format(" {0}='{1}'", oXML.Name, oXML.Value)
                            End While
                        End If
                        strXML &= ">"

                        'Display the text in each element
                    Case XmlNodeType.Text
                        strXML &= oXML.Value

                        'Display end of element
                    Case XmlNodeType.EndElement
                        strXML &= "</" + oXML.Name
                        strXML &= ">"

                End Select
            Loop
            txtXML.Text = strXML

        Catch oException As Exception
            MessageBox.Show(oException.Message)

        End Try

    End Sub

    Private Sub btnWrite_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnWrite.Click
        Dim oXML As XmlTextWriter

        oXML = New XmlTextWriter(GetPath() & "Test.xml", System.Text.Encoding.Default)

        oXML.WriteString(txtXML.Text)

        oXML.Close()
    End Sub
End Class
