Public Class frmStringToDataset
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents btnLoad As System.Windows.Forms.Button
    Friend WithEvents grdProducts As System.Windows.Forms.DataGrid
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.grdProducts = New System.Windows.Forms.DataGrid()
        Me.btnLoad = New System.Windows.Forms.Button()
        CType(Me.grdProducts, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grdProducts
        '
        Me.grdProducts.DataMember = ""
        Me.grdProducts.Location = New System.Drawing.Point(8, 56)
        Me.grdProducts.Name = "grdProducts"
        Me.grdProducts.Size = New System.Drawing.Size(464, 256)
        Me.grdProducts.TabIndex = 1
        '
        'btnLoad
        '
        Me.btnLoad.Location = New System.Drawing.Point(16, 8)
        Me.btnLoad.Name = "btnLoad"
        Me.btnLoad.Size = New System.Drawing.Size(112, 32)
        Me.btnLoad.TabIndex = 0
        Me.btnLoad.Text = "Load"
        '
        'frmStringToDataset
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(480, 314)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.grdProducts, Me.btnLoad})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmStringToDataset"
        Me.Text = "Create DataSet From Memory"
        CType(Me.grdProducts, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoad.Click
        Dim ds As DataSet
        Dim sr As System.IO.StringReader
        Dim strXML As String

        strXML &= "<NewDataSet>"
        strXML &= "<Products>"
        strXML &= "<ProductID>1</ProductID>"
        strXML &= "<ProductName>Chai</ProductName>"
        strXML &= "<SupplierID>1</SupplierID>"
        strXML &= "<CategoryID>1</CategoryID>"
        strXML &= "<QuantityPerUnit>10 boxes x 20 bags</QuantityPerUnit>"
        strXML &= "<UnitPrice>18</UnitPrice>"
        strXML &= "<UnitsInStock>39</UnitsInStock>"
        strXML &= "<UnitsOnOrder>0</UnitsOnOrder>"
        strXML &= "<ReorderLevel>10</ReorderLevel>"
        strXML &= "<Discontinued>false</Discontinued>"
        strXML &= "</Products>"
        strXML &= "<Products>"
        strXML &= "<ProductID>2</ProductID>"
        strXML &= "<ProductName>Chang</ProductName>"
        strXML &= "<SupplierID>1</SupplierID>"
        strXML &= "<CategoryID>1</CategoryID>"
        strXML &= "<QuantityPerUnit>24 - 12 oz bottles</QuantityPerUnit>"
        strXML &= "<UnitPrice>19</UnitPrice>"
        strXML &= "<UnitsInStock>17</UnitsInStock>"
        strXML &= "<UnitsOnOrder>40</UnitsOnOrder>"
        strXML &= "<ReorderLevel>25</ReorderLevel>"
        strXML &= "<Discontinued>false</Discontinued>"
        strXML &= "</Products>"
        strXML &= "</NewDataSet>"

        sr = New System.IO.StringReader(strXML)

        ds = New DataSet()
        ds.ReadXml(sr)

        grdProducts.DataSource = ds.Tables("Products")
    End Sub
End Class
