Public Class frmChildWithMenus
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
        Friend WithEvents mnuMaint As System.Windows.Forms.MenuItem
    Friend WithEvents mnuMSuppliers As System.Windows.Forms.MenuItem
    Friend WithEvents mnuMCategories As System.Windows.Forms.MenuItem
    Friend WithEvents mnuMainMaint As System.Windows.Forms.MainMenu

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mnuMSuppliers = New System.Windows.Forms.MenuItem()
        Me.mnuMainMaint = New System.Windows.Forms.MainMenu()
        Me.mnuMaint = New System.Windows.Forms.MenuItem()
        Me.mnuMCategories = New System.Windows.Forms.MenuItem()
        '
        'mnuMSuppliers
        '
        Me.mnuMSuppliers.Index = 0
        Me.mnuMSuppliers.Text = "Suppliers"
        '
        'mnuMainMaint
        '
        Me.mnuMainMaint.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuMaint})
        '
        'mnuMaint
        '
        Me.mnuMaint.Index = 0
        Me.mnuMaint.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuMSuppliers, Me.mnuMCategories})
        Me.mnuMaint.Text = "Maintenance"
        '
        'mnuMCategories
        '
        Me.mnuMCategories.Index = 1
        Me.mnuMCategories.Text = "Categories"
        '
        'frmChildWithMenus
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(320, 126)
        Me.Menu = Me.mnuMainMaint
        Me.Name = "frmChildWithMenus"
        Me.Text = "frmChildWithMenus"

    End Sub

#End Region

End Class
