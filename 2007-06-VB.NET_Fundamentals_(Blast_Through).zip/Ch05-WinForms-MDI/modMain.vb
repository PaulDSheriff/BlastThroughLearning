Module modMain

    'Dim frmMain As frmMain
    Public frmParent As frmMain

    Sub Main()
        'Dim frmLogin As frmLogin

        '' Display the Main form first
        'frmMain = New frmMain()

        'frmMain.Show()
        'frmMain.Refresh()

        '' Display the Login form
        'frmLogin = New frmLogin()

        'If frmLogin.ShowDialog() = DialogResult.OK Then
        '    ' Check user name and password
        '    MessageBox.Show("Valid Login ID and Password")
        'Else
        '    frmMain.Close()
        'End If

        Dim frm As frmProducts

        frmParent = New frmMain()
        frmParent.Show()
        frmParent.Refresh()

        frm = New frmProducts()
        frm.MdiParent = frmParent

        frm.Show()

        ' Open 2nd instance
        frm = New frmProducts()
        frm.MdiParent = frmParent

        frm.Show()
    End Sub

End Module
