Public Class frmMain
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents MdiClient1 As System.Windows.Forms.MdiClient
    Friend WithEvents mnuFProducts As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFExit As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFile As System.Windows.Forms.MenuItem
    Friend WithEvents mnuMain As System.Windows.Forms.MainMenu
    Friend WithEvents mnuWVertical As System.Windows.Forms.MenuItem
    Friend WithEvents mnuWHorizontal As System.Windows.Forms.MenuItem
    Friend WithEvents mnuWArrange As System.Windows.Forms.MenuItem
    Friend WithEvents mnuWCascade As System.Windows.Forms.MenuItem
    Friend WithEvents mnuEdit As System.Windows.Forms.MenuItem
    Friend WithEvents mnuECut As System.Windows.Forms.MenuItem
    Friend WithEvents mnuECopy As System.Windows.Forms.MenuItem
    Friend WithEvents mnuEPaste As System.Windows.Forms.MenuItem
    Friend WithEvents mnuWindow As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFAddMenus As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFRemoveMenus As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFAddNew As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFChildMenus As System.Windows.Forms.MenuItem
                    Friend WithEvents mnuWCenterChild As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mnuFRemoveMenus = New System.Windows.Forms.MenuItem()
        Me.MenuItem1 = New System.Windows.Forms.MenuItem()
        Me.MenuItem2 = New System.Windows.Forms.MenuItem()
        Me.mnuEPaste = New System.Windows.Forms.MenuItem()
        Me.mnuWCascade = New System.Windows.Forms.MenuItem()
        Me.mnuFChildMenus = New System.Windows.Forms.MenuItem()
        Me.mnuFAddNew = New System.Windows.Forms.MenuItem()
        Me.mnuWHorizontal = New System.Windows.Forms.MenuItem()
        Me.mnuWVertical = New System.Windows.Forms.MenuItem()
        Me.MenuItem4 = New System.Windows.Forms.MenuItem()
        Me.mnuFExit = New System.Windows.Forms.MenuItem()
        Me.mnuWCenterChild = New System.Windows.Forms.MenuItem()
        Me.mnuECopy = New System.Windows.Forms.MenuItem()
        Me.mnuFile = New System.Windows.Forms.MenuItem()
        Me.mnuFProducts = New System.Windows.Forms.MenuItem()
        Me.mnuFAddMenus = New System.Windows.Forms.MenuItem()
        Me.mnuWArrange = New System.Windows.Forms.MenuItem()
        Me.mnuECut = New System.Windows.Forms.MenuItem()
        Me.MdiClient1 = New System.Windows.Forms.MdiClient()
        Me.mnuEdit = New System.Windows.Forms.MenuItem()
        Me.mnuWindow = New System.Windows.Forms.MenuItem()
        Me.mnuMain = New System.Windows.Forms.MainMenu()
        Me.SuspendLayout()
        '
        'mnuFRemoveMenus
        '
        Me.mnuFRemoveMenus.Index = 4
        Me.mnuFRemoveMenus.Text = "&Remove Menus"
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 2
        Me.MenuItem1.Text = "-"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 4
        Me.MenuItem2.Text = "-"
        '
        'mnuEPaste
        '
        Me.mnuEPaste.Index = 2
        Me.mnuEPaste.Text = "&Paste"
        '
        'mnuWCascade
        '
        Me.mnuWCascade.Index = 0
        Me.mnuWCascade.RadioCheck = True
        Me.mnuWCascade.Text = "&Cascade"
        '
        'mnuFChildMenus
        '
        Me.mnuFChildMenus.Index = 1
        Me.mnuFChildMenus.Text = "Child with Menus"
        '
        'mnuFAddNew
        '
        Me.mnuFAddNew.Index = 5
        Me.mnuFAddNew.Text = "Add &New Menu"
        '
        'mnuWHorizontal
        '
        Me.mnuWHorizontal.Index = 1
        Me.mnuWHorizontal.RadioCheck = True
        Me.mnuWHorizontal.Text = "Tile &Horizontal"
        '
        'mnuWVertical
        '
        Me.mnuWVertical.Index = 2
        Me.mnuWVertical.RadioCheck = True
        Me.mnuWVertical.Text = "Tile &Vertical"
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 6
        Me.MenuItem4.Text = "-"
        '
        'mnuFExit
        '
        Me.mnuFExit.Index = 7
        Me.mnuFExit.Text = "E&xit"
        '
        'mnuWCenterChild
        '
        Me.mnuWCenterChild.Index = 5
        Me.mnuWCenterChild.Text = "Center Child &Form"
        '
        'mnuECopy
        '
        Me.mnuECopy.Index = 1
        Me.mnuECopy.Text = "&Copy"
        '
        'mnuFile
        '
        Me.mnuFile.Index = 0
        Me.mnuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFProducts, Me.mnuFChildMenus, Me.MenuItem1, Me.mnuFAddMenus, Me.mnuFRemoveMenus, Me.mnuFAddNew, Me.MenuItem4, Me.mnuFExit})
        Me.mnuFile.Text = "&File"
        '
        'mnuFProducts
        '
        Me.mnuFProducts.Index = 0
        Me.mnuFProducts.Text = "&Products"
        '
        'mnuFAddMenus
        '
        Me.mnuFAddMenus.Index = 3
        Me.mnuFAddMenus.Text = "&Add Menus"
        '
        'mnuWArrange
        '
        Me.mnuWArrange.Index = 3
        Me.mnuWArrange.RadioCheck = True
        Me.mnuWArrange.Text = "&Arrange Icons"
        '
        'mnuECut
        '
        Me.mnuECut.Index = 0
        Me.mnuECut.Text = "Cu&t"
        '
        'MdiClient1
        '
        Me.MdiClient1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MdiClient1.Name = "MdiClient1"
        Me.MdiClient1.TabIndex = 0
        '
        'mnuEdit
        '
        Me.mnuEdit.Index = 1
        Me.mnuEdit.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuECut, Me.mnuECopy, Me.mnuEPaste})
        Me.mnuEdit.Text = "&Edit"
        '
        'mnuWindow
        '
        Me.mnuWindow.Index = 2
        Me.mnuWindow.MdiList = True
        Me.mnuWindow.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuWCascade, Me.mnuWHorizontal, Me.mnuWVertical, Me.mnuWArrange, Me.MenuItem2, Me.mnuWCenterChild})
        Me.mnuWindow.Text = "&Window"
        '
        'mnuMain
        '
        Me.mnuMain.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFile, Me.mnuEdit, Me.mnuWindow})
        '
        'frmMain
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(592, 326)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.MdiClient1})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IsMdiContainer = True
        Me.Menu = Me.mnuMain
        Me.Name = "frmMain"
        Me.Text = "Main Form"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub mnuFProducts_Click( _
     ByVal sender As System.Object, _
     ByVal e As System.EventArgs) _
     Handles mnuFProducts.Click
        Dim frm As frmProducts
        Static intCount As Integer

        frm = New frmProducts()

        ' Increment the caption counter.
        intCount += 1

        ' Set the caption to be unique.
        frm.Text = frm.Text & " " & intCount.ToString()

        frm.MdiParent = Me
        frm.Show()
    End Sub

    Public Sub CenterChildForm(ByVal frmChild As Form)
        Dim ptLoc As Point = New Point()

        ptLoc.X = CInt((Me.ClientRectangle.Width - _
         frmChild.Size.Width) / 2)
        ptLoc.Y = CInt((Me.ClientRectangle.Height - _
         frmChild.Size.Height) / 2)

        frmChild.Location = ptLoc
    End Sub

    Private Sub mnuFAddMenus_Click( _
     ByVal sender As System.Object, _
     ByVal e As System.EventArgs) _
     Handles mnuFAddMenus.Click
        If Not mnuFAddMenus.Checked Then
            mnuFAddMenus.Checked = True
            ' Adds these menus to the end of the File menu
            With mnuFile.MenuItems
                .Add("New Menu 1")
                .Add("New Menu 2")
            End With
        End If
    End Sub

    Private Sub mnuFRemoveMenus_Click( _
     ByVal sender As System.Object, _
     ByVal e As System.EventArgs) _
     Handles mnuFRemoveMenus.Click
        If mnuFAddMenus.Checked Then
            With mnuFile.MenuItems
                ' Remove the last two items
                .RemoveAt(.Count - 1)
                .RemoveAt(.Count - 1)
            End With
            mnuFAddMenus.Checked = False
        End If
    End Sub

    Private Sub mnuFExit_Click( _
     ByVal sender As System.Object, _
     ByVal e As System.EventArgs) _
     Handles mnuFExit.Click
        Me.Close()
    End Sub

    Private Sub mnuWCascade_Click( _
     ByVal sender As System.Object, _
     ByVal e As System.EventArgs) _
     Handles mnuWCascade.Click
        Me.LayoutMdi(MdiLayout.Cascade)
    End Sub

    Private Sub mnuWHorizontal_Click( _
     ByVal sender As System.Object, _
     ByVal e As System.EventArgs) _
     Handles mnuWHorizontal.Click
        Me.LayoutMdi(MdiLayout.TileHorizontal)
    End Sub

    Private Sub mnuWVertical_Click( _
     ByVal sender As System.Object, _
     ByVal e As System.EventArgs) _
     Handles mnuWVertical.Click
        Me.LayoutMdi(MdiLayout.TileVertical)
    End Sub

    Private Sub mnuWArrange_Click( _
     ByVal sender As System.Object, _
     ByVal e As System.EventArgs) _
     Handles mnuWArrange.Click
        Me.LayoutMdi(MdiLayout.ArrangeIcons)
    End Sub

    Private Sub RadioCheck_Click( _
     ByVal sender As System.Object, _
     ByVal e As System.EventArgs) _
     Handles mnuWArrange.Click, mnuWCascade.Click, _
     mnuWHorizontal.Click, mnuWVertical.Click
        mnuWArrange.Checked = False
        mnuWCascade.Checked = False
        mnuWHorizontal.Checked = False
        mnuWVertical.Checked = False
        CType(sender, MenuItem).Checked = True
    End Sub

    Private Sub mnuFChildMenus_Click( _
     ByVal sender As System.Object, _
     ByVal e As System.EventArgs) _
     Handles mnuFChildMenus.Click
        Dim frm As New frmChildWithMenus()
        frm.MdiParent = Me
        frm.Show()
    End Sub

    Private Sub mnuWCenterChild_Click( _
     ByVal sender As System.Object, _
     ByVal e As System.EventArgs) _
     Handles mnuWCenterChild.Click
        CenterChildForm(Me.ActiveMdiChild)
    End Sub

    Private Sub mnuWindow_Popup( _
     ByVal sender As Object, _
     ByVal e As System.EventArgs) _
     Handles mnuWindow.Popup
        mnuWCenterChild.Enabled = _
         Not (Me.ActiveMdiChild Is Nothing)
    End Sub
End Class
