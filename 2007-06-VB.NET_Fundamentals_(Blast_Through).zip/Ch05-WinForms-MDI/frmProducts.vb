Public Class frmProducts
    Inherits System.Windows.Forms.Form


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Win Form Designer.
        InitializeComponent()
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    Private WithEvents Label4 As System.Windows.Forms.Label
    Private WithEvents Label3 As System.Windows.Forms.Label
    Private WithEvents Label2 As System.Windows.Forms.Label
    Private WithEvents Label1 As System.Windows.Forms.Label
    Private WithEvents txtProductName As System.Windows.Forms.TextBox
    Private WithEvents txtUnitPrice As System.Windows.Forms.TextBox
    Private WithEvents txtProductID As System.Windows.Forms.TextBox
    Private WithEvents txtUnitsInStock As System.Windows.Forms.TextBox
    Friend WithEvents cmnuProdID As System.Windows.Forms.ContextMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MenuItem2 = New System.Windows.Forms.MenuItem()
        Me.MenuItem3 = New System.Windows.Forms.MenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtProductID = New System.Windows.Forms.TextBox()
        Me.cmnuProdID = New System.Windows.Forms.ContextMenu()
        Me.MenuItem1 = New System.Windows.Forms.MenuItem()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtUnitPrice = New System.Windows.Forms.TextBox()
        Me.txtUnitsInStock = New System.Windows.Forms.TextBox()
        Me.txtProductName = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 1
        Me.MenuItem2.Text = "&Copy"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 2
        Me.MenuItem3.Text = "&Paste"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(128, 24)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Product ID"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(128, 24)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Product Name"
        '
        'txtProductID
        '
        Me.txtProductID.ContextMenu = Me.cmnuProdID
        Me.txtProductID.Location = New System.Drawing.Point(152, 8)
        Me.txtProductID.Name = "txtProductID"
        Me.txtProductID.Size = New System.Drawing.Size(176, 27)
        Me.txtProductID.TabIndex = 1
        Me.txtProductID.Text = ""
        '
        'cmnuProdID
        '
        Me.cmnuProdID.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem2, Me.MenuItem3})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.Text = "&Lookup"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(8, 72)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(112, 24)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Unit Price"
        '
        'txtUnitPrice
        '
        Me.txtUnitPrice.Location = New System.Drawing.Point(152, 72)
        Me.txtUnitPrice.Name = "txtUnitPrice"
        Me.txtUnitPrice.Size = New System.Drawing.Size(176, 27)
        Me.txtUnitPrice.TabIndex = 3
        Me.txtUnitPrice.Text = ""
        '
        'txtUnitsInStock
        '
        Me.txtUnitsInStock.Location = New System.Drawing.Point(152, 104)
        Me.txtUnitsInStock.Name = "txtUnitsInStock"
        Me.txtUnitsInStock.Size = New System.Drawing.Size(176, 27)
        Me.txtUnitsInStock.TabIndex = 7
        Me.txtUnitsInStock.Text = ""
        '
        'txtProductName
        '
        Me.txtProductName.Location = New System.Drawing.Point(152, 40)
        Me.txtProductName.Name = "txtProductName"
        Me.txtProductName.Size = New System.Drawing.Size(176, 27)
        Me.txtProductName.TabIndex = 2
        Me.txtProductName.Text = ""
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(8, 104)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(136, 24)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Units In Stock"
        '
        'frmProducts
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(9, 20)
        Me.ClientSize = New System.Drawing.Size(336, 138)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label4, Me.txtUnitsInStock, Me.Label3, Me.Label2, Me.Label1, Me.txtUnitPrice, Me.txtProductName, Me.txtProductID})
        Me.Font = New System.Drawing.Font("Tahoma", 12!, System.Drawing.FontStyle.Bold)
        Me.Name = "frmProducts"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Product Information"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private mboolDirty As Boolean

    Private Sub frmProducts_Closing( _
     ByVal sender As Object, _
     ByVal e As System.ComponentModel.CancelEventArgs) _
     Handles MyBase.Closing

        Dim dr As DialogResult
        If mboolDirty Then
            dr = _
             MessageBox.Show( _
             "Save changes?", "Closing " & Me.Text, _
             MessageBoxButtons.YesNoCancel, _
             MessageBoxIcon.Question)
            ' By default, e.Cancel is False.
            Select Case dr
                Case DialogResult.Yes
                    ' Call code here to save the data.
                    mboolDirty = False
                Case DialogResult.No
                    ' Do nothing all. Just let the form close.
                Case DialogResult.Cancel
                    e.Cancel = True
                Case Else
                    ' This won't happen!
            End Select
        End If
    End Sub

    Private Sub HandleTextChanged( _
     ByVal sender As System.Object, _
     ByVal e As System.EventArgs) _
     Handles txtProductID.TextChanged, _
     txtProductName.TextChanged, _
     txtUnitPrice.TextChanged, _
     txtUnitsInStock.TextChanged
        mboolDirty = True
    End Sub

End Class
