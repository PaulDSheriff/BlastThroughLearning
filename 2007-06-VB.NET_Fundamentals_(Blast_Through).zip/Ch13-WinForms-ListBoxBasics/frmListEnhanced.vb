Public Class frmListEnhanced
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    Private WithEvents txtID As System.Windows.Forms.TextBox
    Private WithEvents txtValue As System.Windows.Forms.TextBox
    Private WithEvents lstNames As System.Windows.Forms.ListBox

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.txtValue = New System.Windows.Forms.TextBox()
        Me.lstNames = New System.Windows.Forms.ListBox()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'txtValue
        '
        Me.txtValue.Location = New System.Drawing.Point(8, 200)
        Me.txtValue.Name = "txtValue"
        Me.txtValue.Size = New System.Drawing.Size(248, 26)
        Me.txtValue.TabIndex = 1
        Me.txtValue.Text = ""
        '
        'lstNames
        '
        Me.lstNames.ItemHeight = 20
        Me.lstNames.Location = New System.Drawing.Point(8, 8)
        Me.lstNames.Name = "lstNames"
        Me.lstNames.Size = New System.Drawing.Size(248, 184)
        Me.lstNames.TabIndex = 0
        '
        'txtID
        '
        Me.txtID.Location = New System.Drawing.Point(8, 232)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(248, 26)
        Me.txtID.TabIndex = 2
        Me.txtID.Text = ""
        '
        'frmListEnhanced
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(264, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtID, Me.txtValue, Me.lstNames})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold)
        Me.Name = "frmListEnhanced"
        Me.Text = "ListEnhanced"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Class PDSAListItem
        Private mstrValue As String
        Private mintID As Integer

        Public Sub New(ByVal strValue As String, ByVal intID As Integer)
            mstrValue = strValue
            mintID = intID
        End Sub

        Property Value() As String
            Get
                Return mstrValue
            End Get
            Set(ByVal Value As String)
                mstrValue = Value
            End Set
        End Property

        Property ID() As Integer
            Get
                Return mintID
            End Get
            Set(ByVal Value As Integer)
                mintID = Value
            End Set
        End Property

        ' If you do not Override ToString(), you must set
        ' the DisplayMember property on the list box to "Value"
        Public Overrides Function ToString() As String
            Return mstrValue
        End Function
    End Class

    Private Sub ListLoad()
        With lstNames
            .Items.Add(New PDSAListItem("Paul", 1))
            .Items.Add(New PDSAListItem("Ken", 2))
            .Items.Add(New PDSAListItem("Michael", 3))
        End With
    End Sub

    Private Sub lstNames_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstNames.SelectedIndexChanged
        Dim oPDSAListItem As PDSAListItem

        oPDSAListItem = CType(lstNames.SelectedItem, PDSAListItem)
        txtValue.Text = oPDSAListItem.Value
        txtID.Text = oPDSAListItem.ID.ToString()
    End Sub

    Private Sub ListEnhanced_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ListLoad()
    End Sub
End Class
