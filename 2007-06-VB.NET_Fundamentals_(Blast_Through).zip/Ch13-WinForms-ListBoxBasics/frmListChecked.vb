Public Class frmListChecked
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    Private WithEvents btnAdd As System.Windows.Forms.Button
    Private WithEvents clstSelected As System.Windows.Forms.CheckedListBox
    Private WithEvents clstUnSelected As System.Windows.Forms.CheckedListBox

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
Me.clstUnSelected = New System.Windows.Forms.CheckedListBox()
Me.clstSelected = New System.Windows.Forms.CheckedListBox()
Me.btnAdd = New System.Windows.Forms.Button()
Me.SuspendLayout()
'
'clstUnSelected
'
Me.clstUnSelected.CheckOnClick = True
Me.clstUnSelected.Location = New System.Drawing.Point(8, 8)
Me.clstUnSelected.Name = "clstUnSelected"
Me.clstUnSelected.Size = New System.Drawing.Size(200, 214)
Me.clstUnSelected.Sorted = True
Me.clstUnSelected.TabIndex = 0
'
'clstSelected
'
Me.clstSelected.Location = New System.Drawing.Point(304, 8)
Me.clstSelected.Name = "clstSelected"
Me.clstSelected.Size = New System.Drawing.Size(200, 214)
Me.clstSelected.Sorted = True
Me.clstSelected.TabIndex = 1
'
'btnAdd
'
Me.btnAdd.Location = New System.Drawing.Point(216, 56)
Me.btnAdd.Name = "btnAdd"
Me.btnAdd.TabIndex = 2
Me.btnAdd.Text = "Add >>"
'
'frmListChecked
'
Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
Me.ClientSize = New System.Drawing.Size(512, 226)
Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnAdd, Me.clstSelected, Me.clstUnSelected})
Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold)
Me.Name = "frmListChecked"
Me.Text = "Checked List Box"
Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub ListLoad()
        Dim astrValues() As String = {"Paul", "Ken", "Michael", "Keith", "Jeff", "Chris"}

        clstUnSelected.Items.AddRange(astrValues)
    End Sub

    Private Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Dim oItems As CheckedListBox.CheckedItemCollection
        Dim intLoop As Integer

        ' Move items from checked to unchecked list
        oItems = clstUnSelected.CheckedItems
        For intLoop = 0 To oItems.Count - 1
            clstSelected.Items.Add(oItems(intLoop))
        Next

        ' Clear items using object
        oItems = clstUnSelected.CheckedItems
        For intLoop = oItems.Count - 1 To 0 Step -1
            clstUnSelected.Items.Remove(oItems(intLoop))
        Next
    End Sub

    Private Sub ListChecked_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ListLoad()
    End Sub
End Class
