Public Class frmMain
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    Private WithEvents btnChecked As System.Windows.Forms.Button
    Private WithEvents btnMulti As System.Windows.Forms.Button
    Private WithEvents btnLBoxEnh As System.Windows.Forms.Button
    Private WithEvents btnList As System.Windows.Forms.Button

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnChecked = New System.Windows.Forms.Button()
        Me.btnList = New System.Windows.Forms.Button()
        Me.btnMulti = New System.Windows.Forms.Button()
        Me.btnLBoxEnh = New System.Windows.Forms.Button()

        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        btnChecked.Location = New System.Drawing.Point(272, 8)
        btnChecked.Size = New System.Drawing.Size(128, 32)
        btnChecked.TabIndex = 4
        btnChecked.Text = "Checked List"

        btnList.Location = New System.Drawing.Point(8, 8)
        btnList.Size = New System.Drawing.Size(104, 32)
        btnList.TabIndex = 1
        btnList.Text = "List Box"

        btnMulti.Location = New System.Drawing.Point(128, 8)
        btnMulti.Size = New System.Drawing.Size(128, 32)
        btnMulti.TabIndex = 3
        btnMulti.Text = "Multi-Select"

        btnLBoxEnh.Location = New System.Drawing.Point(416, 8)
        btnLBoxEnh.Size = New System.Drawing.Size(128, 32)
        btnLBoxEnh.TabIndex = 2
        btnLBoxEnh.Text = "List Box Enh"
        Me.Text = "List Box Test"
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold)
        Me.ClientSize = New System.Drawing.Size(552, 50)

        Me.Controls.Add(btnChecked)
        Me.Controls.Add(btnMulti)
        Me.Controls.Add(btnLBoxEnh)
        Me.Controls.Add(btnList)
    End Sub

#End Region

    Private Sub btnChecked_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnChecked.Click
        Dim frm As frmListChecked = New frmListChecked()

        frm.Show()
    End Sub

    Private Sub btnMulti_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnMulti.Click
        Dim frm As frmListMulti = New frmListMulti()

        frm.Show()
    End Sub

    Private Sub btnLBoxEnh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnLBoxEnh.Click
        Dim frm As frmProducts = New frmProducts()

        frm.Show()
    End Sub

    Private Sub btnList_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnList.Click
        Dim frm As frmListTest = New frmListTest()

        frm.Show()
    End Sub
End Class
