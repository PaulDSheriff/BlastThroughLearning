Public Class frmListTest
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub


  Private WithEvents txtName As System.Windows.Forms.TextBox
  Private WithEvents lstNames As System.Windows.Forms.ListBox
  Private WithEvents btnAdd As System.Windows.Forms.Button
  Private WithEvents btnInsert As System.Windows.Forms.Button
  Private WithEvents btnAddRange As System.Windows.Forms.Button

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.btnAdd = New System.Windows.Forms.Button()
    Me.lstNames = New System.Windows.Forms.ListBox()
    Me.txtName = New System.Windows.Forms.TextBox()
    Me.btnInsert = New System.Windows.Forms.Button()
    Me.btnAddRange = New System.Windows.Forms.Button()
    Me.SuspendLayout()
    '
    'btnAdd
    '
    Me.btnAdd.Location = New System.Drawing.Point(8, 248)
    Me.btnAdd.Name = "btnAdd"
    Me.btnAdd.Size = New System.Drawing.Size(100, 25)
    Me.btnAdd.TabIndex = 3
    Me.btnAdd.Text = "Add"
    '
    'lstNames
    '
    Me.lstNames.ItemHeight = 20
    Me.lstNames.Location = New System.Drawing.Point(8, 8)
    Me.lstNames.Name = "lstNames"
    Me.lstNames.Size = New System.Drawing.Size(408, 184)
    Me.lstNames.Sorted = True
    Me.lstNames.TabIndex = 0
    '
    'txtName
    '
    Me.txtName.Location = New System.Drawing.Point(8, 208)
    Me.txtName.Name = "txtName"
    Me.txtName.Size = New System.Drawing.Size(408, 26)
    Me.txtName.TabIndex = 1
    Me.txtName.Text = ""
    '
    'btnInsert
    '
    Me.btnInsert.Location = New System.Drawing.Point(112, 248)
    Me.btnInsert.Name = "btnInsert"
    Me.btnInsert.Size = New System.Drawing.Size(100, 25)
    Me.btnInsert.TabIndex = 4
    Me.btnInsert.Text = "Insert"
    '
    'btnAddRange
    '
    Me.btnAddRange.Location = New System.Drawing.Point(216, 248)
    Me.btnAddRange.Name = "btnAddRange"
    Me.btnAddRange.Size = New System.Drawing.Size(100, 25)
    Me.btnAddRange.TabIndex = 5
    Me.btnAddRange.Text = "AddRange"
    '
    'frmListTest
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
    Me.ClientSize = New System.Drawing.Size(424, 282)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnAddRange, Me.btnInsert, Me.btnAdd, Me.txtName, Me.lstNames})
    Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
    Me.Name = "frmListTest"
    Me.Text = "List Box Test"
    Me.ResumeLayout(False)

  End Sub

#End Region

  Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
    lstNames.Items.Clear()

    lstNames.Items.Add("Paul")
    lstNames.Items.Add("Ken")
    lstNames.Items.Add("Michael")
  End Sub

  Private Sub btnInsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInsert.Click
    lstNames.Items.Clear()

    lstNames.Sorted = False
    lstNames.Items.Insert(0, "Paul")
    lstNames.Items.Insert(1, "Ken")
    lstNames.Items.Insert(0, "Michael")

    lstNames.SetSelected(0, True)
  End Sub

  Private Sub btnAddRange_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddRange.Click
    Dim astrValues() As String = {"Paul", "Ken", "Michael"}

    lstNames.Items.Clear()

    lstNames.Items.AddRange(astrValues)
  End Sub

  Private Sub lstNames_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstNames.SelectedIndexChanged
    txtName.Text = lstNames.Items(lstNames.SelectedIndex).ToString()
  End Sub
End Class