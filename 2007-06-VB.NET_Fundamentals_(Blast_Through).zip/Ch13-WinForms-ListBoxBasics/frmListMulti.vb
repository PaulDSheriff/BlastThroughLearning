Public Class frmListMulti
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    Private WithEvents btnAdd As System.Windows.Forms.Button
    Private WithEvents lstSelected As System.Windows.Forms.ListBox
    Private WithEvents lstUnSelected As System.Windows.Forms.ListBox

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.lstUnSelected = New System.Windows.Forms.ListBox()
        Me.lstSelected = New System.Windows.Forms.ListBox()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lstUnSelected
        '
        Me.lstUnSelected.ItemHeight = 20
        Me.lstUnSelected.Location = New System.Drawing.Point(8, 8)
        Me.lstUnSelected.Name = "lstUnSelected"
        Me.lstUnSelected.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.lstUnSelected.Size = New System.Drawing.Size(184, 184)
        Me.lstUnSelected.Sorted = True
        Me.lstUnSelected.TabIndex = 0
        '
        'lstSelected
        '
        Me.lstSelected.ItemHeight = 20
        Me.lstSelected.Location = New System.Drawing.Point(288, 8)
        Me.lstSelected.Name = "lstSelected"
        Me.lstSelected.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.lstSelected.Size = New System.Drawing.Size(184, 184)
        Me.lstSelected.Sorted = True
        Me.lstSelected.TabIndex = 1
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(200, 32)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(80, 23)
        Me.btnAdd.TabIndex = 2
        Me.btnAdd.Text = "Add >>"
        '
        'frmListMulti
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(480, 218)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnAdd, Me.lstSelected, Me.lstUnSelected})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold)
        Me.Name = "frmListMulti"
        Me.Text = "Multi-Select List Box"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub ListLoad()
        Dim astrValues() As String = _
         {"Paul", "Ken", "Michael", "Keith", "Jeff", "Chris"}

        lstUnSelected.Items.AddRange(astrValues)
    End Sub

    Private Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Dim intLoop As Integer

        For intLoop = lstUnSelected.Items.Count - 1 To 0 Step -1
            If lstUnSelected.GetSelected(intLoop) Then
                lstSelected.Items.Add(lstUnSelected.Items(intLoop))
                lstUnSelected.Items.RemoveAt(intLoop)
            End If
        Next
    End Sub

    Private Sub ListMulti_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lstUnSelected.SelectionMode = SelectionMode.MultiExtended
        ListLoad()
    End Sub
End Class
