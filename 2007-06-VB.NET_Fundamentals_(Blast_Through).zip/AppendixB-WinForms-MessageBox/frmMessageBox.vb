Public Class frmMessageBox
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents btnSimple As System.Windows.Forms.Button
    Friend WithEvents btnTitle As System.Windows.Forms.Button
    Friend WithEvents btnButtons As System.Windows.Forms.Button
    Friend WithEvents btnResult As System.Windows.Forms.Button

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnTitle = New System.Windows.Forms.Button()
        Me.btnSimple = New System.Windows.Forms.Button()
        Me.btnResult = New System.Windows.Forms.Button()
        Me.btnButtons = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnTitle
        '
        Me.btnTitle.Location = New System.Drawing.Point(8, 72)
        Me.btnTitle.Name = "btnTitle"
        Me.btnTitle.Size = New System.Drawing.Size(128, 56)
        Me.btnTitle.TabIndex = 0
        Me.btnTitle.Text = "With Title"
        '
        'btnSimple
        '
        Me.btnSimple.Location = New System.Drawing.Point(8, 8)
        Me.btnSimple.Name = "btnSimple"
        Me.btnSimple.Size = New System.Drawing.Size(128, 56)
        Me.btnSimple.TabIndex = 0
        Me.btnSimple.Text = "Simple"
        '
        'btnResult
        '
        Me.btnResult.Location = New System.Drawing.Point(8, 208)
        Me.btnResult.Name = "btnResult"
        Me.btnResult.Size = New System.Drawing.Size(128, 56)
        Me.btnResult.TabIndex = 0
        Me.btnResult.Text = "With Result"
        '
        'btnButtons
        '
        Me.btnButtons.Location = New System.Drawing.Point(8, 136)
        Me.btnButtons.Name = "btnButtons"
        Me.btnButtons.Size = New System.Drawing.Size(128, 56)
        Me.btnButtons.TabIndex = 0
        Me.btnButtons.Text = "With Buttons"
        '
        'frmMessageBox
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(336, 274)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnResult, Me.btnButtons, Me.btnTitle, Me.btnSimple})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmMessageBox"
        Me.Text = "MessageBox Samples"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnSimple_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimple.Click
        MessageBox.Show("Do you want to quit?")
    End Sub

    Private Sub btnTitle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTitle.Click
        MessageBox.Show("Do you want to quit?", "MessageBox Sample")
    End Sub

    Private Sub btnButtons_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnButtons.Click
        MessageBox.Show("Do you want to quit?", _
         "MessageBox Sample", _
         MessageBoxButtons.YesNo, _
         MessageBoxIcon.Hand, _
         MessageBoxDefaultButton.Button2)
    End Sub

    Private Sub btnResult_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnResult.Click
        Dim dr As DialogResult

        dr = MessageBox.Show("Do you want to quit?", _
         "MessageBox Sample", _
         MessageBoxButtons.YesNo, _
         MessageBoxIcon.Asterisk, _
         MessageBoxDefaultButton.Button2)

        Select Case dr
            Case DialogResult.Yes
                Me.Close()

            Case DialogResult.No
                ' Do Nothing at all

        End Select
    End Sub
End Class
