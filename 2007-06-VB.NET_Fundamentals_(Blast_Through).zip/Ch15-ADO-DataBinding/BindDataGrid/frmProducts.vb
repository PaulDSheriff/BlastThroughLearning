Public Class frmProducts
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents grdProducts As System.Windows.Forms.DataGrid
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboCategories As System.Windows.Forms.ComboBox

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.grdProducts = New System.Windows.Forms.DataGrid()
        Me.cboCategories = New System.Windows.Forms.ComboBox()
        CType(Me.grdProducts, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(104, 24)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Categories"
        '
        'grdProducts
        '
        Me.grdProducts.DataMember = ""
        Me.grdProducts.Location = New System.Drawing.Point(8, 48)
        Me.grdProducts.Name = "grdProducts"
        Me.grdProducts.Size = New System.Drawing.Size(568, 208)
        Me.grdProducts.TabIndex = 0
        '
        'cboCategories
        '
        Me.cboCategories.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCategories.DropDownWidth = 208
        Me.cboCategories.Location = New System.Drawing.Point(120, 8)
        Me.cboCategories.Name = "cboCategories"
        Me.cboCategories.Size = New System.Drawing.Size(304, 28)
        Me.cboCategories.TabIndex = 2
        '
        'frmProducts
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(592, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cboCategories, Me.Label1, Me.grdProducts})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmProducts"
        Me.Text = "Product Information"
        CType(Me.grdProducts, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub frmProducts_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call ComboLoad()
    End Sub

    Private Sub GridLoad()
        Dim da As OleDb.OleDbDataAdapter
        Dim dt As DataTable = New DataTable()
        Dim strSQL As String
        Dim strConn As String

        strConn = "Provider=sqloledb;Data Source=(local);Initial Catalog=Northwind;User ID=sa"

        strSQL = "SELECT ProductID, ProductName, "
        strSQL &= "UnitPrice, UnitsInStock "
        strSQL &= "FROM Products "
        strSQL &= "WHERE CategoryID = " & cboCategories.SelectedValue.ToString

        Try
            da = New OleDb.OleDbDataAdapter(strSQL, strConn)

            da.Fill(dt)

            grdProducts.DataSource = dt

        Catch e As Exception
            MessageBox.Show(e.Message)

        End Try
    End Sub

    Private Sub ComboLoad()
        Dim da As OleDb.OleDbDataAdapter
        Dim dt As DataTable = New DataTable()
        Dim strSQL As String
        Dim strConn As String

        strConn = "Provider=sqloledb;Data Source=(local);Initial Catalog=Northwind;User ID=sa"

        strSQL = "SELECT CategoryId, CategoryName  "
        strSQL &= "FROM Categories"

        Try
            da = New OleDb.OleDbDataAdapter(strSQL, strConn)

            da.Fill(dt)

            With cboCategories
                ' Set these properties first
                .DisplayMember = "CategoryName"
                .ValueMember = "CategoryId"

                ' Then set the DataSource
                .DataSource = dt
            End With

        Catch e As Exception
            MessageBox.Show(e.Message)

        End Try
    End Sub

    Private Sub cboCategories_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboCategories.SelectedIndexChanged
        Call GridLoad()
    End Sub
End Class
