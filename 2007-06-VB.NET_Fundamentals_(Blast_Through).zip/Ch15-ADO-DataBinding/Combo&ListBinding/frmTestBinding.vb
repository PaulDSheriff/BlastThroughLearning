Public Class frmTest
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents cboCat As System.Windows.Forms.ComboBox
    Friend WithEvents lstCat As System.Windows.Forms.ListBox
    Friend WithEvents txtCDisplay As System.Windows.Forms.TextBox
    Friend WithEvents txtCValue As System.Windows.Forms.TextBox
    Friend WithEvents txtLDisplay As System.Windows.Forms.TextBox
    Friend WithEvents txtLValue As System.Windows.Forms.TextBox

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.txtLValue = New System.Windows.Forms.TextBox()
        Me.txtCDisplay = New System.Windows.Forms.TextBox()
        Me.cboCat = New System.Windows.Forms.ComboBox()
        Me.lstCat = New System.Windows.Forms.ListBox()
        Me.txtLDisplay = New System.Windows.Forms.TextBox()
        Me.txtCValue = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'txtLValue
        '
        Me.txtLValue.Location = New System.Drawing.Point(256, 144)
        Me.txtLValue.Name = "txtLValue"
        Me.txtLValue.Size = New System.Drawing.Size(176, 20)
        Me.txtLValue.TabIndex = 3
        Me.txtLValue.Text = ""
        '
        'txtCDisplay
        '
        Me.txtCDisplay.Location = New System.Drawing.Point(256, 8)
        Me.txtCDisplay.Name = "txtCDisplay"
        Me.txtCDisplay.Size = New System.Drawing.Size(176, 20)
        Me.txtCDisplay.TabIndex = 2
        Me.txtCDisplay.Text = ""
        '
        'cboCat
        '
        Me.cboCat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCat.DropDownWidth = 232
        Me.cboCat.Location = New System.Drawing.Point(8, 16)
        Me.cboCat.Name = "cboCat"
        Me.cboCat.Size = New System.Drawing.Size(232, 21)
        Me.cboCat.TabIndex = 0
        '
        'lstCat
        '
        Me.lstCat.Location = New System.Drawing.Point(8, 88)
        Me.lstCat.Name = "lstCat"
        Me.lstCat.Size = New System.Drawing.Size(232, 95)
        Me.lstCat.TabIndex = 1
        '
        'txtLDisplay
        '
        Me.txtLDisplay.Location = New System.Drawing.Point(256, 112)
        Me.txtLDisplay.Name = "txtLDisplay"
        Me.txtLDisplay.Size = New System.Drawing.Size(176, 20)
        Me.txtLDisplay.TabIndex = 2
        Me.txtLDisplay.Text = ""
        '
        'txtCValue
        '
        Me.txtCValue.Location = New System.Drawing.Point(256, 40)
        Me.txtCValue.Name = "txtCValue"
        Me.txtCValue.Size = New System.Drawing.Size(176, 20)
        Me.txtCValue.TabIndex = 3
        Me.txtCValue.Text = ""
        '
        'frmTest
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(472, 194)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtLDisplay, Me.txtLValue, Me.txtCValue, Me.txtCDisplay, Me.lstCat, Me.cboCat})
        Me.Name = "frmTest"
        Me.Text = "Test Categories"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub frmTest_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call ComboLoad()

        Call ListLoad()
    End Sub

    Private Sub ComboLoad()
        Dim da As OleDb.OleDbDataAdapter
        Dim dt As DataTable = New DataTable()
        Dim strSQL As String
        Dim strConn As String

        strConn = "Provider=sqloledb;Data Source=(local);Initial Catalog=Northwind;User ID=sa"

        strSQL = "SELECT CategoryId, CategoryName  "
        strSQL &= "FROM Categories"

        Try
            da = New OleDb.OleDbDataAdapter(strSQL, strConn)

            da.Fill(dt)

            With cboCat
                ' Set these properties first
                .DisplayMember = "CategoryName"
                .ValueMember = "CategoryId"

                ' Then set the DataSource
                .DataSource = dt
            End With

        Catch e As Exception
            MessageBox.Show(e.Message)

        End Try
    End Sub

    Private Sub ListLoad()
        Dim ds As DataSet
        Dim strSQL As String
        Dim strConn As String

        strConn = "Provider=sqloledb;Data Source=(local);Initial Catalog=Northwind;User ID=sa"

        strSQL = "SELECT ProductID, ProductName  "
        strSQL &= "FROM Products"

        Try
            ds = GetDataSet(strSQL, strConn)

            With lstCat
                ' Set these properties first
                .DisplayMember = "ProductName"
                .ValueMember = "ProductId"

                ' Then set the DataSource
                .DataSource = ds.Tables(0)
            End With

        Catch e As Exception
            MessageBox.Show(e.Message)

        End Try
    End Sub

    Private Function GetDataSet(ByVal strSQL As String, ByVal strConn As String) As DataSet
        Dim da As OleDb.OleDbDataAdapter
        Dim ds As New DataSet()

        da = New OleDb.OleDbDataAdapter(strSQL, strConn)

        da.Fill(ds)

        Return ds
    End Function

    Private Sub cboCat_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboCat.SelectedIndexChanged
        txtCDisplay.Text = cboCat.Text
        txtCValue.Text = cboCat.SelectedValue.ToString
    End Sub

    Private Sub lstCat_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstCat.SelectedIndexChanged
        txtLDisplay.Text = lstCat.Text
        txtLValue.Text = lstCat.SelectedValue.ToString
    End Sub
End Class
