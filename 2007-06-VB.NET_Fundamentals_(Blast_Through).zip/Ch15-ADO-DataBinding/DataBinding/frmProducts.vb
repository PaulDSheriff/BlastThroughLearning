Public Class frmProducts
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents DataGrid1 As System.Windows.Forms.DataGrid
    Friend WithEvents OleDbDataAdapter1 As System.Data.OleDb.OleDbDataAdapter
    Friend WithEvents OleDbSelectCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbInsertCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbUpdateCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbDeleteCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbConnection1 As System.Data.OleDb.OleDbConnection
    Friend WithEvents DsProducts1 As DataBind2.dsProducts
    Friend WithEvents OleDbDataAdapter2 As System.Data.OleDb.OleDbDataAdapter
    Friend WithEvents OleDbSelectCommand2 As System.Data.OleDb.OleDbCommand
    Friend WithEvents DsCat1 As DataBind2.dsCat
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboCategories As System.Windows.Forms.ComboBox

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
Me.OleDbInsertCommand1 = New System.Data.OleDb.OleDbCommand()
Me.OleDbConnection1 = New System.Data.OleDb.OleDbConnection()
Me.OleDbSelectCommand2 = New System.Data.OleDb.OleDbCommand()
Me.cboCategories = New System.Windows.Forms.ComboBox()
Me.DsCat1 = New DataBind2.dsCat()
Me.Label1 = New System.Windows.Forms.Label()
Me.OleDbDataAdapter1 = New System.Data.OleDb.OleDbDataAdapter()
Me.OleDbDeleteCommand1 = New System.Data.OleDb.OleDbCommand()
Me.OleDbSelectCommand1 = New System.Data.OleDb.OleDbCommand()
Me.OleDbUpdateCommand1 = New System.Data.OleDb.OleDbCommand()
Me.DsProducts1 = New DataBind2.dsProducts()
Me.OleDbDataAdapter2 = New System.Data.OleDb.OleDbDataAdapter()
Me.DataGrid1 = New System.Windows.Forms.DataGrid()
CType(Me.DsCat1, System.ComponentModel.ISupportInitialize).BeginInit()
CType(Me.DsProducts1, System.ComponentModel.ISupportInitialize).BeginInit()
CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
Me.SuspendLayout()
'
'OleDbInsertCommand1
'
Me.OleDbInsertCommand1.CommandText = "INSERT INTO Products(ProductName, UnitPrice, UnitsInStock) VALUES (?, ?, ?); SELE" & _
"CT ProductID, ProductName, UnitPrice, UnitsInStock FROM Products WHERE (ProductI" & _
"D = @@IDENTITY)"
Me.OleDbInsertCommand1.Connection = Me.OleDbConnection1
Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ProductName", System.Data.OleDb.OleDbType.VarWChar, 40, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ProductName", System.Data.DataRowVersion.Current, Nothing))
Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("UnitPrice", System.Data.OleDb.OleDbType.Currency, 8, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "UnitPrice", System.Data.DataRowVersion.Current, Nothing))
Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("UnitsInStock", System.Data.OleDb.OleDbType.Integer, 2, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "UnitsInStock", System.Data.DataRowVersion.Current, Nothing))
'
'OleDbConnection1
'
Me.OleDbConnection1.ConnectionString = "Provider=SQLOLEDB.1;Persist Security Info=False;User ID=sa;Initial Catalog=Northw" & _
"ind;Data Source=(local);Use Procedure for Prepare=1;Auto Translate=True;Packet S" & _
"ize=4096;Workstation ID=PDSATOSHIBA3;Use Encryption for Data=False;Tag with colu" & _
"mn collation when possible=False"
'
'OleDbSelectCommand2
'
Me.OleDbSelectCommand2.CommandText = "SELECT CategoryID, CategoryName FROM Categories"
Me.OleDbSelectCommand2.Connection = Me.OleDbConnection1
'
'cboCategories
'
Me.cboCategories.DataSource = Me.DsCat1
Me.cboCategories.DisplayMember = "Categories.CategoryName"
Me.cboCategories.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
Me.cboCategories.DropDownWidth = 272
Me.cboCategories.Location = New System.Drawing.Point(144, 8)
Me.cboCategories.Name = "cboCategories"
Me.cboCategories.Size = New System.Drawing.Size(272, 28)
Me.cboCategories.TabIndex = 2
Me.cboCategories.ValueMember = "CategoryID"
'
'DsCat1
'
Me.DsCat1.DataSetName = "dsCat"
Me.DsCat1.Locale = New System.Globalization.CultureInfo("en-US")
Me.DsCat1.Namespace = "http://www.tempuri.org/dsCat.xsd"
'
'Label1
'
Me.Label1.Location = New System.Drawing.Point(8, 8)
Me.Label1.Name = "Label1"
Me.Label1.Size = New System.Drawing.Size(120, 24)
Me.Label1.TabIndex = 1
Me.Label1.Text = "Categories"
'
'OleDbDataAdapter1
'
Me.OleDbDataAdapter1.DeleteCommand = Me.OleDbDeleteCommand1
Me.OleDbDataAdapter1.InsertCommand = Me.OleDbInsertCommand1
Me.OleDbDataAdapter1.SelectCommand = Me.OleDbSelectCommand1
Me.OleDbDataAdapter1.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Products", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("ProductID", "ProductID"), New System.Data.Common.DataColumnMapping("ProductName", "ProductName"), New System.Data.Common.DataColumnMapping("UnitPrice", "UnitPrice"), New System.Data.Common.DataColumnMapping("UnitsInStock", "UnitsInStock")})})
Me.OleDbDataAdapter1.UpdateCommand = Me.OleDbUpdateCommand1
'
'OleDbDeleteCommand1
'
Me.OleDbDeleteCommand1.CommandText = "DELETE FROM Products WHERE (ProductID = ?) AND (ProductName = ?) AND (UnitPrice =" & _
" ? OR ? IS NULL AND UnitPrice IS NULL) AND (UnitsInStock = ? OR ? IS NULL AND Un" & _
"itsInStock IS NULL)"
Me.OleDbDeleteCommand1.Connection = Me.OleDbConnection1
Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ProductID", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ProductID", System.Data.DataRowVersion.Original, Nothing))
Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ProductName", System.Data.OleDb.OleDbType.VarWChar, 40, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ProductName", System.Data.DataRowVersion.Original, Nothing))
Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("UnitPrice", System.Data.OleDb.OleDbType.Currency, 8, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "UnitPrice", System.Data.DataRowVersion.Original, Nothing))
Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("UnitPrice1", System.Data.OleDb.OleDbType.Currency, 8, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "UnitPrice", System.Data.DataRowVersion.Original, Nothing))
Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("UnitsInStock", System.Data.OleDb.OleDbType.Integer, 2, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "UnitsInStock", System.Data.DataRowVersion.Original, Nothing))
Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("UnitsInStock1", System.Data.OleDb.OleDbType.Integer, 2, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "UnitsInStock", System.Data.DataRowVersion.Original, Nothing))
'
'OleDbSelectCommand1
'
Me.OleDbSelectCommand1.CommandText = "SELECT ProductID, ProductName, UnitPrice, UnitsInStock FROM Products WHERE (Categ" & _
"oryID = ?)"
Me.OleDbSelectCommand1.Connection = Me.OleDbConnection1
Me.OleDbSelectCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("CategoryID", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "CategoryID", System.Data.DataRowVersion.Current, Nothing))
'
'OleDbUpdateCommand1
'
Me.OleDbUpdateCommand1.CommandText = "UPDATE Products SET ProductName = ?, UnitPrice = ?, UnitsInStock = ? WHERE (Produ" & _
"ctID = ?) AND (ProductName = ?) AND (UnitPrice = ? OR ? IS NULL AND UnitPrice IS" & _
" NULL) AND (UnitsInStock = ? OR ? IS NULL AND UnitsInStock IS NULL); SELECT Prod" & _
"uctID, ProductName, UnitPrice, UnitsInStock FROM Products WHERE (ProductID = ?)"
Me.OleDbUpdateCommand1.Connection = Me.OleDbConnection1
Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ProductName", System.Data.OleDb.OleDbType.VarWChar, 40, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ProductName", System.Data.DataRowVersion.Current, Nothing))
Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("UnitPrice", System.Data.OleDb.OleDbType.Currency, 8, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "UnitPrice", System.Data.DataRowVersion.Current, Nothing))
Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("UnitsInStock", System.Data.OleDb.OleDbType.Integer, 2, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "UnitsInStock", System.Data.DataRowVersion.Current, Nothing))
Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ProductID", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ProductID", System.Data.DataRowVersion.Original, Nothing))
Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ProductName", System.Data.OleDb.OleDbType.VarWChar, 40, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ProductName", System.Data.DataRowVersion.Original, Nothing))
Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_UnitPrice", System.Data.OleDb.OleDbType.Currency, 8, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "UnitPrice", System.Data.DataRowVersion.Original, Nothing))
Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_UnitPrice1", System.Data.OleDb.OleDbType.Currency, 8, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "UnitPrice", System.Data.DataRowVersion.Original, Nothing))
Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_UnitsInStock", System.Data.OleDb.OleDbType.Integer, 2, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "UnitsInStock", System.Data.DataRowVersion.Original, Nothing))
Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_UnitsInStock1", System.Data.OleDb.OleDbType.Integer, 2, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "UnitsInStock", System.Data.DataRowVersion.Original, Nothing))
Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Select_ProductID", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ProductID", System.Data.DataRowVersion.Current, Nothing))
'
'DsProducts1
'
Me.DsProducts1.DataSetName = "dsProducts"
Me.DsProducts1.Locale = New System.Globalization.CultureInfo("en-US")
Me.DsProducts1.Namespace = "http://www.tempuri.org/dsProducts.xsd"
'
'OleDbDataAdapter2
'
Me.OleDbDataAdapter2.SelectCommand = Me.OleDbSelectCommand2
Me.OleDbDataAdapter2.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Categories", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("CategoryID", "CategoryID"), New System.Data.Common.DataColumnMapping("CategoryName", "CategoryName")})})
'
'DataGrid1
'
Me.DataGrid1.DataMember = "Products"
Me.DataGrid1.DataSource = Me.DsProducts1
Me.DataGrid1.Location = New System.Drawing.Point(8, 48)
Me.DataGrid1.Name = "DataGrid1"
Me.DataGrid1.Size = New System.Drawing.Size(552, 216)
Me.DataGrid1.TabIndex = 0
'
'frmProducts
'
Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
Me.ClientSize = New System.Drawing.Size(568, 266)
Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cboCategories, Me.Label1, Me.DataGrid1})
Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.Name = "frmProducts"
Me.Text = "Product Information"
CType(Me.DsCat1, System.ComponentModel.ISupportInitialize).EndInit()
CType(Me.DsProducts1, System.ComponentModel.ISupportInitialize).EndInit()
CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).EndInit()
Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub frmProducts_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        OleDbDataAdapter2.Fill(DsCat1, "Categories")
    End Sub

Private Sub cboCategories_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboCategories.SelectedIndexChanged
    With OleDbDataAdapter1.SelectCommand.Parameters
        .Item(0).Value = cboCategories.SelectedValue
    End With

    ' Clear the dataset
    DsProducts1.Clear()
    ' Load the dataset using the parameter value
    OleDbDataAdapter1.Fill(DsProducts1, "Products")

End Sub
End Class
