Public Class Products
    Inherits DataSource

    '******************************************************
    ' Private Data To Match the Table Definition
    '******************************************************
    Private mintProductID As Integer
    Private mstrProductName As String
    Private mdecUnitPrice As Decimal
    Private msrtUnitsInStock As Short

    ' DataTable with all the data
    Private mDT As DataTable

    Private Enum Cols
        ProductID = 0
        ProductName = 1
        UnitPrice = 2
        UnitsInStock = 3
    End Enum

    '******************************************************
    '* Properties to Match Table Definition
    '******************************************************
    Property ProductID() As Integer
        Get
            Return mintProductID
        End Get

        Set(ByVal Value As Integer)
            mintProductID = Value
        End Set
    End Property

    Property ProductName() As String
        Get
            Return mstrProductName
        End Get

        Set(ByVal Value As String)
            mstrProductName = Value
        End Set
    End Property

    Property UnitPrice() As Decimal
        Get
            Return mdecUnitPrice
        End Get

        Set(ByVal Value As Decimal)
            mdecUnitPrice = Value
        End Set
    End Property

    Property UnitsInStock() As Short
        Get
            Return msrtUnitsInStock
        End Get

        Set(ByVal Value As Short)
            msrtUnitsInStock = Value
        End Set
    End Property

    '*******************************************************************
    '* Methods
    '*******************************************************************
    Public Sub New()
        Dim strFile As String

        ' Get File Name For Data
        strFile = GetFileNameAndPath()

        ' Set FileName of DataSource class
        MyBase.FileName = strFile

        BuildDataTable()
    End Sub

    Public Overloads Sub Dispose()
        Dispose(True)
    End Sub

    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub

    Private Function GetFileNameAndPath() As String
        Dim strFile As String

        ' Executable Path returns everything including 
        ' the name of the .EXE
        strFile = Application.ExecutablePath
        ' Look for the \bin\ and get everything 
        ' up to that location
        strFile = strFile.Substring(0, strFile.LastIndexOf("\bin\"))

        ' Add on the file name
        strFile &= "\Products.txt"

        Return strFile
    End Function

    Private Sub BuildDataTable()
        Dim dr As DataRow

        ' Create a new DataTable
        mDT = TableCreate()

        Try
            ' Open the File
            MyBase.Open()
            ' Read all lines
            Do While MyBase.Read()
                dr = mDT.NewRow

                dr("ProductID") = MyBase.Values(Cols.ProductID)
                dr("ProductName") = MyBase.Values(Cols.ProductName)
                dr("UnitPrice") = MyBase.Values(Cols.UnitPrice)
                dr("UnitsInStock") = MyBase.Values(Cols.UnitsInStock)

                mDT.Rows.Add(dr)
            Loop

        Catch oException As Exception
            Throw oException

        End Try
    End Sub

    Private Function TableCreate() As DataTable
        Dim dt As DataTable = New DataTable("Products")
        Dim dc As DataColumn

        dc = dt.Columns.Add("ProductID")
        dt.Columns.Add("ProductName")
        dt.Columns.Add("UnitPrice")
        dt.Columns.Add("UnitsInStock")

        dt.PrimaryKey = New DataColumn() {dc}

        Return dt
    End Function

    Public Function Find(ByVal intProductID As Integer) As DataTable
        Dim dt As DataTable
        Dim drFind As DataRow
        Dim dr As DataRow
        Dim intIndex As Integer

        Try
            ' Create a new DataTable
            dt = TableCreate()

            ' Find the Row Based on the Primary Key
            drFind = mDT.Rows.Find(intProductID)

            ' Create a new DataRow for the row we just found
            dr = dt.NewRow
            ' Copy the values from the 
            ' found row into the new row
            With drFind
                dr("ProductID") = .Item(Cols.ProductID)
                dr("ProductName") = .Item(Cols.ProductName)
                dr("UnitPrice") = .Item(Cols.UnitPrice)
                dr("UnitsInStock") = .Item(Cols.UnitsInStock)
            End With
            ' Add the new row to the new data table
            dt.Rows.Add(dr)

            ' Fill in the member variables with 
            ' the values from the data row
            mintProductID = dr(Cols.ProductID)
            mstrProductName = dr(Cols.ProductName)
            mdecUnitPrice = dr(Cols.UnitPrice)
            msrtUnitsInStock = dr(Cols.UnitsInStock)

            ' Return the new DataTable
            Return dt

        Catch oException As Exception
            oException = New Exception("Row not found")
            Throw oException

        End Try
    End Function

    Public Function GetDataTable() As DataTable
        Return mDT
    End Function

End Class
