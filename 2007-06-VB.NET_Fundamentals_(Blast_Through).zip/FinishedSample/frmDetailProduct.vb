
Public Class frmDetailProduct
  Inherits WinformDemo.frmDetail

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub
  Friend WithEvents txtProductID As System.Windows.Forms.TextBox
  Friend WithEvents txtProductName As System.Windows.Forms.TextBox
  Friend WithEvents txtUnitsInStock As System.Windows.Forms.TextBox
  Friend WithEvents txtUnitPrice As System.Windows.Forms.TextBox
  Friend WithEvents Label1 As System.Windows.Forms.Label
  Friend WithEvents Label2 As System.Windows.Forms.Label
  Friend WithEvents Label3 As System.Windows.Forms.Label
  Friend WithEvents Label4 As System.Windows.Forms.Label

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.Label2 = New System.Windows.Forms.Label()
    Me.txtUnitPrice = New System.Windows.Forms.TextBox()
    Me.txtProductID = New System.Windows.Forms.TextBox()
    Me.Label3 = New System.Windows.Forms.Label()
    Me.Label4 = New System.Windows.Forms.Label()
    Me.txtProductName = New System.Windows.Forms.TextBox()
    Me.txtUnitsInStock = New System.Windows.Forms.TextBox()
    Me.SuspendLayout()
    '
    'Label1
    '
    Me.Label1.Location = New System.Drawing.Point(32, 24)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(128, 23)
    Me.Label1.TabIndex = 5
    Me.Label1.Text = "Product ID:"
    '
    'Label2
    '
    Me.Label2.Location = New System.Drawing.Point(32, 56)
    Me.Label2.Name = "Label2"
    Me.Label2.Size = New System.Drawing.Size(128, 23)
    Me.Label2.TabIndex = 5
    Me.Label2.Text = "Product Name:"
    '
    'txtUnitPrice
    '
    Me.txtUnitPrice.Location = New System.Drawing.Point(160, 80)
    Me.txtUnitPrice.Name = "txtUnitPrice"
    Me.txtUnitPrice.ReadOnly = True
    Me.txtUnitPrice.TabIndex = 3
    Me.txtUnitPrice.Text = ""
    '
    'txtProductID
    '
    Me.txtProductID.Location = New System.Drawing.Point(160, 16)
    Me.txtProductID.Name = "txtProductID"
    Me.txtProductID.ReadOnly = True
    Me.txtProductID.TabIndex = 1
    Me.txtProductID.Text = ""
    '
    'Label3
    '
    Me.Label3.Location = New System.Drawing.Point(32, 88)
    Me.Label3.Name = "Label3"
    Me.Label3.Size = New System.Drawing.Size(128, 23)
    Me.Label3.TabIndex = 5
    Me.Label3.Text = "Unit Price:"
    '
    'Label4
    '
    Me.Label4.Location = New System.Drawing.Point(32, 120)
    Me.Label4.Name = "Label4"
    Me.Label4.Size = New System.Drawing.Size(128, 23)
    Me.Label4.TabIndex = 5
    Me.Label4.Text = "Units In Stock:"
    '
    'txtProductName
    '
    Me.txtProductName.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right)
    Me.txtProductName.Location = New System.Drawing.Point(160, 48)
    Me.txtProductName.Name = "txtProductName"
    Me.txtProductName.ReadOnly = True
    Me.txtProductName.Size = New System.Drawing.Size(248, 26)
    Me.txtProductName.TabIndex = 4
    Me.txtProductName.Text = ""
    '
    'txtUnitsInStock
    '
    Me.txtUnitsInStock.Location = New System.Drawing.Point(160, 112)
    Me.txtUnitsInStock.Name = "txtUnitsInStock"
    Me.txtUnitsInStock.ReadOnly = True
    Me.txtUnitsInStock.TabIndex = 2
    Me.txtUnitsInStock.Text = ""
    '
    'frmDetailProduct
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
    Me.ClientSize = New System.Drawing.Size(416, 213)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label4, Me.Label3, Me.Label2, Me.Label1, Me.txtProductName, Me.txtUnitPrice, Me.txtUnitsInStock, Me.txtProductID})
    Me.MinimumSize = New System.Drawing.Size(424, 240)
    Me.Name = "frmDetailProduct"
    Me.Text = "Product Detail"
    Me.ResumeLayout(False)

  End Sub

#End Region

  Public WriteOnly Property ProductID() As Integer
    Set(ByVal Value As Integer)
      Me.txtProductID.Text = Value.ToString
    End Set
  End Property

  Public WriteOnly Property Product() As String
    Set(ByVal Value As String)
      Me.txtProductName.Text = Value
    End Set
  End Property

  Public WriteOnly Property UnitPrice() As Decimal
    Set(ByVal Value As Decimal)
      Me.txtUnitPrice.Text = Value.ToString
    End Set
  End Property

  Public WriteOnly Property UnitsInStock() As Integer
    Set(ByVal Value As Integer)
      Me.txtUnitsInStock.Text = Value.ToString
    End Set
  End Property

End Class
