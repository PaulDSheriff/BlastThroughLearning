Imports System.IO

Public Class DataSource
    Private mstrText As String
    Private mstrFileName As String
    Private mstrDelim As String
    Private mStream As StreamReader
    Private mastrValues() As String

    Public Sub New()
        mstrDelim = ","
    End Sub

    Protected Overridable Overloads Sub Dispose(ByVal disposing As Boolean)
        mStream.Close()
    End Sub

    Protected Overrides Sub Finalize()
        mStream.Close()
    End Sub

    Property Delimiter() As String
        Get
            Return mstrDelim
        End Get
        Set(ByVal Value As String)
            mstrDelim = Value
        End Set
    End Property

    Property FileName() As String
        Get
            Return mstrFileName
        End Get
        Set(ByVal Value As String)
            mstrFileName = Value
        End Set
    End Property

    ReadOnly Property Text() As String
        Get
            Return mstrText
        End Get
    End Property

    Default ReadOnly Property Values(ByVal intIndex As Integer) As String
        Get
            Return mastrValues(intIndex)
        End Get
    End Property

    Public Sub Open()
        Try
            ' Open the file
            mStream = File.OpenText(mstrFileName)

        Catch oException As IOException
            Throw oException

        End Try
    End Sub

    Public Function Read() As Boolean
        Try
            ' Read a line of text
            mstrText = mStream.ReadLine()
            If mstrText Is Nothing Then
                mStream.Close()

                Return False
            Else
                ' Create an array based on the delimiter string
                mastrValues = mstrText.Split(mstrDelim.ToCharArray())

                Return True
            End If

        Catch oException As IOException
            Throw oException

        End Try
    End Function
End Class
