Imports System.Xml
Imports System.IO

Public Class Form1

  Inherits System.Windows.Forms.Form

  Private astrData(,) As String = _
  {{"1", "Chai", "18", "39"}, _
  {"2", "Chang", "19", "17"}, _
  {"3", "Aniseed Syrup", "10", "13"}, _
  {"4", "Chef Anton's Cajun Seasoning", "22", "53"}, _
  {"5", "Chef Anton's Gumbo Mix", "21.35", "0"}, _
  {"6", "Grandma's Boysenberry Spread", "25", "120"}, _
  {"7", "Uncle Bob's Organic Dried Pears", "30", "15"}, _
  {"8", "Northwoods Cranberry Sauce", "40", "6"}, _
  {"9", "Mishi Kobe Niku", "97", "29"}, _
  {"10", "Ikura", "31", "31"}, _
  {"11", "Queso Cabrales", "21", "22"}, _
  {"12", "Queso Manchego La Pastora", "38", "86"}, _
  {"13", "Konbu", "6", "24"}, _
  {"14", "Tofu", "23.25", "35"}, _
  {"15", "Genen Shouyu", "15.5", "39"}, _
  {"16", "Pavlova", "17.45", "29"}, _
  {"17", "Alice Mutton", "39", "0"}, _
  {"18", "Carnarvon Tigers", "62.5", "42"}, _
  {"19", "Teatime Chocolate Biscuits", "9.2", "25"}, _
  {"20", "Sir Rodney's Marmalade", "81", "40"}}

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub
  Friend WithEvents DataGrid1 As System.Windows.Forms.DataGrid
  Friend WithEvents Splitter1 As System.Windows.Forms.Splitter
  Friend WithEvents MdiClient1 As System.Windows.Forms.MdiClient
  Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
  Friend WithEvents mnuFile As System.Windows.Forms.MenuItem
  Friend WithEvents mnuFileExit As System.Windows.Forms.MenuItem
  Friend WithEvents mnuWindow As System.Windows.Forms.MenuItem
  Friend WithEvents mnuWindowArrange As System.Windows.Forms.MenuItem
  Friend WithEvents mnuWindowTileHorizontal As System.Windows.Forms.MenuItem
  Friend WithEvents mnuWindowTileVertical As System.Windows.Forms.MenuItem
  Friend WithEvents mnuWindowCascade As System.Windows.Forms.MenuItem
    Friend WithEvents mnuDisplayDetail As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
  Friend WithEvents mnuLoadArray As System.Windows.Forms.MenuItem
  Friend WithEvents mnuLoadCOM As System.Windows.Forms.MenuItem
  Friend WithEvents mnuLoadADO As System.Windows.Forms.MenuItem
  Friend WithEvents mnuLoadClass As System.Windows.Forms.MenuItem
  Friend WithEvents mnuLoadWebService As System.Windows.Forms.MenuItem
          
  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
    Me.mnuFileExit = New System.Windows.Forms.MenuItem()
    Me.mnuWindowArrange = New System.Windows.Forms.MenuItem()
    Me.DataGrid1 = New System.Windows.Forms.DataGrid()
    Me.mnuLoadCOM = New System.Windows.Forms.MenuItem()
    Me.mnuLoadADO = New System.Windows.Forms.MenuItem()
    Me.mnuLoadArray = New System.Windows.Forms.MenuItem()
    Me.mnuDisplayDetail = New System.Windows.Forms.MenuItem()
    Me.MenuItem1 = New System.Windows.Forms.MenuItem()
    Me.mnuLoadClass = New System.Windows.Forms.MenuItem()
    Me.mnuLoadWebService = New System.Windows.Forms.MenuItem()
    Me.mnuFile = New System.Windows.Forms.MenuItem()
    Me.Splitter1 = New System.Windows.Forms.Splitter()
    Me.MainMenu1 = New System.Windows.Forms.MainMenu()
    Me.mnuWindow = New System.Windows.Forms.MenuItem()
    Me.mnuWindowTileHorizontal = New System.Windows.Forms.MenuItem()
    Me.mnuWindowTileVertical = New System.Windows.Forms.MenuItem()
    Me.mnuWindowCascade = New System.Windows.Forms.MenuItem()
    Me.MdiClient1 = New System.Windows.Forms.MdiClient()
    CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'mnuFileExit
    '
    Me.mnuFileExit.Index = 2
    Me.mnuFileExit.Text = "&Exit"
    '
    'mnuWindowArrange
    '
    Me.mnuWindowArrange.Index = 0
    Me.mnuWindowArrange.Text = "&Arrange Icons"
    '
    'DataGrid1
    '
    Me.DataGrid1.AlternatingBackColor = System.Drawing.SystemColors.ScrollBar
    Me.DataGrid1.CaptionFont = New System.Drawing.Font("Arial", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.DataGrid1.DataMember = ""
    Me.DataGrid1.Dock = System.Windows.Forms.DockStyle.Top
    Me.DataGrid1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.DataGrid1.Name = "DataGrid1"
    Me.DataGrid1.ParentRowsVisible = False
    Me.DataGrid1.PreferredColumnWidth = -1
    Me.DataGrid1.ReadOnly = True
    Me.DataGrid1.Size = New System.Drawing.Size(776, 200)
    Me.DataGrid1.TabIndex = 0
    '
    'mnuLoadCOM
    '
    Me.mnuLoadCOM.Index = 1
    Me.mnuLoadCOM.Text = "From COM"
    '
    'mnuLoadADO
    '
    Me.mnuLoadADO.Index = 2
    Me.mnuLoadADO.Text = "From ADO.Net"
    '
    'mnuLoadArray
    '
    Me.mnuLoadArray.Index = 0
    Me.mnuLoadArray.Text = "From Array"
    '
    'mnuDisplayDetail
    '
    Me.mnuDisplayDetail.Index = 1
    Me.mnuDisplayDetail.Text = "&Display Detail for Selected Item"
    '
    'MenuItem1
    '
    Me.MenuItem1.Index = 0
    Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuLoadArray, Me.mnuLoadCOM, Me.mnuLoadADO, Me.mnuLoadClass, Me.mnuLoadWebService})
    Me.MenuItem1.Text = "Load Product Info "
    '
    'mnuLoadClass
    '
    Me.mnuLoadClass.Index = 3
    Me.mnuLoadClass.Text = "From Text File"
    '
    'mnuLoadWebService
    '
    Me.mnuLoadWebService.Index = 4
    Me.mnuLoadWebService.Text = "From Web Service"
    '
    'mnuFile
    '
    Me.mnuFile.Index = 0
    Me.mnuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.mnuDisplayDetail, Me.mnuFileExit})
    Me.mnuFile.Text = "&File"
    '
    'Splitter1
    '
    Me.Splitter1.Dock = System.Windows.Forms.DockStyle.Top
    Me.Splitter1.Location = New System.Drawing.Point(0, 200)
    Me.Splitter1.Name = "Splitter1"
    Me.Splitter1.Size = New System.Drawing.Size(776, 6)
    Me.Splitter1.TabIndex = 2
    Me.Splitter1.TabStop = False
    '
    'MainMenu1
    '
    Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFile, Me.mnuWindow})
    '
    'mnuWindow
    '
    Me.mnuWindow.Index = 1
    Me.mnuWindow.MdiList = True
    Me.mnuWindow.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuWindowArrange, Me.mnuWindowTileHorizontal, Me.mnuWindowTileVertical, Me.mnuWindowCascade})
    Me.mnuWindow.Text = "&Window"
    '
    'mnuWindowTileHorizontal
    '
    Me.mnuWindowTileHorizontal.Index = 1
    Me.mnuWindowTileHorizontal.Text = "Tile &Horizontal"
    '
    'mnuWindowTileVertical
    '
    Me.mnuWindowTileVertical.Index = 2
    Me.mnuWindowTileVertical.Text = "Tile &Vertical"
    '
    'mnuWindowCascade
    '
    Me.mnuWindowCascade.Index = 3
    Me.mnuWindowCascade.Text = "&Cascade"
    '
    'MdiClient1
    '
    Me.MdiClient1.Dock = System.Windows.Forms.DockStyle.Fill
    Me.MdiClient1.Location = New System.Drawing.Point(0, 206)
    Me.MdiClient1.Name = "MdiClient1"
    Me.MdiClient1.TabIndex = 3
    '
    'Form1
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
    Me.ClientSize = New System.Drawing.Size(776, 674)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Splitter1, Me.DataGrid1, Me.MdiClient1})
    Me.Font = New System.Drawing.Font("Arial", 12!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
    Me.IsMdiContainer = True
    Me.Menu = Me.MainMenu1
    Me.Name = "Form1"
    Me.Text = "Product Information"
    CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)

  End Sub

#End Region

  Private Enum DataLocation
    Array
    COM
    TextFile
    ADO
    WebService
  End Enum

  Private mdl As DataLocation
  Private mdt As DataTable

  Private Function FillDataTable(ByVal dl As DataLocation) As DataTable
    mdt = New DataTable("Products")

    ' Store away the data source for later use.
    mdl = dl

    ' Go retrieve the data, from the requested source.
    Select Case dl
      Case DataLocation.Array
        mdt = FillDataTableFromArray()
      Case DataLocation.COM
        mdt = FillDataTableFromCOM()
      Case DataLocation.ADO
        mdt = FillDataTableFromADO()
      Case DataLocation.TextFile
        mdt = FillDataTableFromTextFile()
      Case DataLocation.WebService
        mdt = FillDataTableFromWebService()
    End Select
    DataGrid1.DataSource = mdt
    Me.DataGrid1.CaptionText = _
     String.Format("Product Information (from {0})", mdl.ToString)
  End Function

  Private Function FillDataTableFromTextFile() As DataTable
    Dim otf As New Products()
    mdt = otf.GetDataTable
    Return mdt
  End Function

  Private Function FillDataTableFromADO() As DataTable
    Dim oADO As New ProductsADO()
    mdt = oADO.GetDataTable
    Return mdt
  End Function

  Private Function FillDataTableFromWebService() As DataTable
    Dim oWS As New ProductsWS()
    mdt = oWS.GetDataTable
    Return mdt
  End Function

  Private Function FillDataTableFromArray() As DataTable
    ' Fill a DataTable with hard-coded data.
    Dim i As Integer
    mdt.Columns.Add("ProductID")
    mdt.Columns.Add("ProductName")
    mdt.Columns.Add("UnitPrice")
    mdt.Columns.Add("UnitsInStock")

    Dim dr As DataRow
    For i = 0 To astrData.GetUpperBound(0)
      dr = mdt.NewRow
      dr("ProductID") = astrData(i, 0)
      dr("ProductName") = astrData(i, 1)
      dr("UnitPrice") = astrData(i, 2)
      dr("UnitsInStock") = astrData(i, 3)
      mdt.Rows.Add(dr)
    Next
    Return mdt
  End Function

  Private Function FillDataTableFromCOM() As DataTable
    Dim ovb As New VB6SQL.Products()
    Dim ds As New DataSet()

    ' Use StringReader object to retrieve data.
    ' Get the data from COM, in DataSet format.
    Dim sr As New StringReader(ovb.GetDataTableXML)

    ' Send the StringReader object's data into the dataset, 
    ' filling it with data.
    ds.ReadXml(sr)

    ' Return the 0th data table from the dataset.
    mdt = ds.Tables(0)
    Return mdt
  End Function

  Private Sub mnuDisplayDetail_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuDisplayDetail.Click
    Call ShowDetail(Me.DataGrid1.CurrentRowIndex)
  End Sub

  Private Sub DataGrid1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataGrid1.DoubleClick
    Call ShowDetail(Me.DataGrid1.CurrentRowIndex)
  End Sub

  Private Sub ShowDetail(ByVal CurrentRow As Integer)
    Dim frm As New frmDetailProduct()
    Dim intProductID As Integer

    frm.MdiParent = Me

    Dim dr As DataRow
    dr = mdt.Rows(CurrentRow)
    intProductID = dr("ProductID")
    frm.Text = "Detail for Product ID " & intProductID
    frm.ProductID = intProductID
    frm.Product = dr("ProductName")
    frm.UnitPrice = dr("UnitPrice")
    frm.UnitsInStock = dr("UnitsInStock")

    frm.Show()
  End Sub

  Private Sub mnuWindowCascade_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuWindowCascade.Click
    Me.LayoutMdi(MdiLayout.Cascade)
  End Sub

  Private Sub mnuWindowHorizontal_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuWindowTileHorizontal.Click
    Me.LayoutMdi(MdiLayout.TileHorizontal)
  End Sub

  Private Sub mnuWindowVertical_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuWindowTileVertical.Click
    Me.LayoutMdi(MdiLayout.TileVertical)
  End Sub

  Private Sub mnuWindowArrange_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuWindowArrange.Click
    Me.LayoutMdi(MdiLayout.ArrangeIcons)
  End Sub

  Private Sub mnuCOMLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuLoadCOM.Click
    FillDataTable(DataLocation.COM)
  End Sub

  Private Sub mnuLoadWebService_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuLoadWebService.Click
    FillDataTable(DataLocation.WebService)
  End Sub

  Private Sub mnuLoadArray_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuLoadArray.Click
    FillDataTable(DataLocation.Array)
  End Sub

  Private Sub mnuLoadADO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuLoadADO.Click
    FillDataTable(DataLocation.ADO)
  End Sub

  Private Sub mnuLoadClass_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuLoadClass.Click
    FillDataTable(DataLocation.TextFile)
  End Sub

End Class
