Public Class ProductsWS
  '******************************************************
  ' Private Data To Match the Table Definition
  '******************************************************
  Private mintProductID As Integer
  Private mstrProductName As String
  Private mdecUnitPrice As Decimal
  Private msrtUnitsInStock As Short

  ' DataTable with all the data
  Private mDT As DataTable

  Private Enum Cols
    ProductID = 0
    ProductName = 1
    UnitPrice = 2
    UnitsInStock = 3
  End Enum

  '******************************************************
  '* Properties to Match Table Definition
  '******************************************************
  Property ProductID() As Integer
    Get
      Return mintProductID
    End Get

    Set(ByVal Value As Integer)
      mintProductID = Value
    End Set
  End Property

  Property ProductName() As String
    Get
      Return mstrProductName
    End Get

    Set(ByVal Value As String)
      mstrProductName = Value
    End Set
  End Property

  Property UnitPrice() As Decimal
    Get
      Return mdecUnitPrice
    End Get

    Set(ByVal Value As Decimal)
      mdecUnitPrice = Value
    End Set
  End Property

  Property UnitsInStock() As Short
    Get
      Return msrtUnitsInStock
    End Get

    Set(ByVal Value As Short)
      msrtUnitsInStock = Value
    End Set
  End Property

  '*******************************************************************
  '* Methods
  '*******************************************************************
  Public Sub New()
    BuildDataTable()
  End Sub

  Private Sub BuildDataTable()
    Try
      ' Create a new DataTable
      mDT = TableCreate()

    Catch oException As Exception
      Throw oException

    End Try
  End Sub

  Private Function TableCreate() As DataTable
    Dim wsProd As ProductWS.Products
    Dim dt As DataTable

    wsProd = New ProductWS.Products()
    dt = New DataTable()

    dt = wsProd.AllProducts().Tables("Products")

    dt.PrimaryKey = New DataColumn() {dt.Columns("ProductID")}

    Return dt
  End Function

  Private Function ConnectStringBuild() As String
    Dim strConn As String

    ' Build the connection string		
    strConn = "Provider=sqloledb;"
    strConn &= "Data Source=(local);"
    strConn &= "Initial Catalog=Northwind;"
    strConn &= "User ID=sa"

    Return strConn
  End Function

  Public Function Find(ByVal intProductID As Integer) As DataTable
    Dim dt As DataTable = New DataTable()
    Dim drFind As DataRow
    Dim dr As DataRow
    Dim intIndex As Integer

    Try
      ' Create a new DataTable
      dt = mDT.Clone()

      ' Find the Row Based on the Primary Key
      drFind = mDT.Rows.Find(intProductID)

      ' Create a new DataRow for the row we just found
      dr = dt.NewRow
      ' Copy the values from the 
      ' found row into the new row
      With drFind
        dr("ProductID") = .Item(Cols.ProductID)
        dr("ProductName") = .Item(Cols.ProductName)
        dr("UnitPrice") = .Item(Cols.UnitPrice)
        dr("UnitsInStock") = .Item(Cols.UnitsInStock)
      End With
      ' Add the new row to the new data table
      dt.Rows.Add(dr)

      ' Fill in the member variables with 
      ' the values from the data row
      mintProductID = dr(Cols.ProductID)
      mstrProductName = dr(Cols.ProductName)
      mdecUnitPrice = dr(Cols.UnitPrice)
      msrtUnitsInStock = dr(Cols.UnitsInStock)

      ' Return the new DataView
      Return dt

    Catch oException As Exception
      oException = New Exception("Row not found")
      Throw oException

    End Try
  End Function

  Public Function GetDataTable() As DataTable
    Return mDT
  End Function

End Class
