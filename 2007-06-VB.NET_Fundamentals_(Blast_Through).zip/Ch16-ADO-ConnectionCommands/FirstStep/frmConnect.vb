Public Class frmConnect
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Win Form Designer.
        InitializeComponent()

        Call InitSQL()
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub


    Private WithEvents Label1 As System.Windows.Forms.Label
    Private WithEvents txtRows As System.Windows.Forms.TextBox

    Private WithEvents btnExecute As System.Windows.Forms.Button
    Private WithEvents txtSQL As System.Windows.Forms.TextBox
    Private WithEvents btnConnect As System.Windows.Forms.Button

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnConnect = New System.Windows.Forms.Button()
        Me.txtSQL = New System.Windows.Forms.TextBox()
        Me.txtRows = New System.Windows.Forms.TextBox()
        Me.btnExecute = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 256)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(136, 16)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Rows Affected"
        '
        'btnConnect
        '
        Me.btnConnect.Location = New System.Drawing.Point(8, 8)
        Me.btnConnect.Name = "btnConnect"
        Me.btnConnect.Size = New System.Drawing.Size(112, 23)
        Me.btnConnect.TabIndex = 1
        Me.btnConnect.Text = "Connect"
        '
        'txtSQL
        '
        Me.txtSQL.Location = New System.Drawing.Point(8, 48)
        Me.txtSQL.Multiline = True
        Me.txtSQL.Name = "txtSQL"
        Me.txtSQL.Size = New System.Drawing.Size(376, 192)
        Me.txtSQL.TabIndex = 2
        Me.txtSQL.Text = ""
        '
        'txtRows
        '
        Me.txtRows.Location = New System.Drawing.Point(160, 248)
        Me.txtRows.Name = "txtRows"
        Me.txtRows.ReadOnly = True
        Me.txtRows.Size = New System.Drawing.Size(40, 26)
        Me.txtRows.TabIndex = 4
        Me.txtRows.Text = ""
        '
        'btnExecute
        '
        Me.btnExecute.Location = New System.Drawing.Point(224, 248)
        Me.btnExecute.Name = "btnExecute"
        Me.btnExecute.Size = New System.Drawing.Size(160, 23)
        Me.btnExecute.TabIndex = 3
        Me.btnExecute.Text = "Execute SQL"
        '
        'frmConnect
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(392, 282)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label1, Me.txtRows, Me.btnExecute, Me.txtSQL, Me.btnConnect})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold)
        Me.Name = "frmConnect"
        Me.Text = "SQL Tester"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Protected Sub InitSQL()
        Dim strSQL As String

        strSQL = "INSERT INTO Customers(CustomerID, CompanyName, ContactName) "
        strSQL &= ControlChars.CrLf
        strSQL &= "VALUES('ELMAU', 'Schloss Elmau, GMBH', 'Dietmar Elmau')"

        txtSQL.Text = strSQL
    End Sub
End Class