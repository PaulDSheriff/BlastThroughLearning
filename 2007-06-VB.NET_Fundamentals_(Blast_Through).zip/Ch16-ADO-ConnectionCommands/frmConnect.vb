Public Class frmConnect
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Win Form Designer.
        InitializeComponent()

        Call InitSQL()
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub


    Private WithEvents Label1 As System.Windows.Forms.Label
    Private WithEvents txtRows As System.Windows.Forms.TextBox

    Private WithEvents btnExecute As System.Windows.Forms.Button
    Private WithEvents txtSQL As System.Windows.Forms.TextBox
    Private WithEvents btnConnect As System.Windows.Forms.Button
    Friend WithEvents btnTrans As System.Windows.Forms.Button

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.txtSQL = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnConnect = New System.Windows.Forms.Button()
        Me.txtRows = New System.Windows.Forms.TextBox()
        Me.btnExecute = New System.Windows.Forms.Button()
        Me.btnTrans = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtSQL
        '
        Me.txtSQL.Location = New System.Drawing.Point(8, 48)
        Me.txtSQL.Multiline = True
        Me.txtSQL.Name = "txtSQL"
        Me.txtSQL.Size = New System.Drawing.Size(376, 192)
        Me.txtSQL.TabIndex = 2
        Me.txtSQL.Text = ""
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 256)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(136, 16)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Rows Affected"
        '
        'btnConnect
        '
        Me.btnConnect.Location = New System.Drawing.Point(8, 8)
        Me.btnConnect.Name = "btnConnect"
        Me.btnConnect.Size = New System.Drawing.Size(112, 23)
        Me.btnConnect.TabIndex = 1
        Me.btnConnect.Text = "Connect"
        '
        'txtRows
        '
        Me.txtRows.Location = New System.Drawing.Point(160, 248)
        Me.txtRows.Name = "txtRows"
        Me.txtRows.ReadOnly = True
        Me.txtRows.Size = New System.Drawing.Size(40, 26)
        Me.txtRows.TabIndex = 4
        Me.txtRows.Text = ""
        '
        'btnExecute
        '
        Me.btnExecute.Location = New System.Drawing.Point(224, 248)
        Me.btnExecute.Name = "btnExecute"
        Me.btnExecute.Size = New System.Drawing.Size(160, 23)
        Me.btnExecute.TabIndex = 3
        Me.btnExecute.Text = "Execute SQL"
        '
        'btnTrans
        '
        Me.btnTrans.Location = New System.Drawing.Point(224, 288)
        Me.btnTrans.Name = "btnTrans"
        Me.btnTrans.Size = New System.Drawing.Size(160, 23)
        Me.btnTrans.TabIndex = 3
        Me.btnTrans.Text = "Transaction"
        '
        'frmConnect
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(392, 314)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnTrans, Me.Label1, Me.txtRows, Me.btnExecute, Me.txtSQL, Me.btnConnect})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold)
        Me.Name = "frmConnect"
        Me.Text = "SQL Tester"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnExecute_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnExecute.Click
        Dim oCmd As OleDb.OleDbCommand
        Dim strConn As String

        Try
            ' Build the connection string		
            strConn = "Provider=sqloledb;"
            strConn &= "Data Source=(local);"
            strConn &= "Initial Catalog=Northwind;"
            strConn &= "User ID=sa;"
            strConn &= "Password=;"

            ' Create the Command Object
            oCmd = New OleDb.OleDbCommand()
            ' Assign Connection to Command Object
            oCmd.Connection = _
             New OleDb.OleDbConnection(strConn)
            ' Open the Connection
            oCmd.Connection.Open()
            ' Assign the SQL to the Command Object
            oCmd.CommandText = txtSQL.Text
            ' Execute the SQL, Return Number of Records Affected
            txtRows.Text = _
             oCmd.ExecuteNonQuery().ToString()

            MessageBox.Show("SQL statement succeeded", _
             "btnExecute_Click()")

            ' Close the Connection		
            oCmd.Connection.Close()

        Catch oExcept As Exception
            txtRows.Text = 0.ToString()
            MessageBox.Show("Error executing SQL: " & oExcept.Message, "btnExecute_Click()")

        End Try
    End Sub

    Private Sub btnConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConnect.Click
        Dim oConn As OleDb.OleDbConnection
        Dim strConn As String

        Try
            ' Create the Connection object
            ' Build the connection string		
            strConn = "Provider=sqloledb;"
            strConn &= "Data Source=(local);"
            strConn &= "Initial Catalog=Northwind;"
            strConn &= "User ID=sa;"
            strConn &= "Password=;"

            oConn = New OleDb.OleDbConnection(strConn)

            ' Set the Connection String
            'oConn.ConnectionString = strConn

            ' Open the Connection
            oConn.Open()

            MessageBox.Show("Connection Open", _
             "btnConnect_Click()")

            ' Close the Connection
            oConn.Close()

        Catch oExcept As Exception
            MessageBox.Show(oExcept.Message, _
             "btnConnect_Click()")

        End Try

    End Sub

    Private Sub InitSQL()
        Dim strSQL As String

        strSQL = "INSERT INTO Customers(CustomerID, CompanyName, ContactName) "
        strSQL &= ControlChars.CrLf
        strSQL &= "VALUES('ELMAU', 'Schloss Elmau, GMBH', 'Dietmar Elmau')"

        txtSQL.Text = strSQL
    End Sub

    Private Sub btnTrans_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTrans.Click
        Dim oCmd1 As OleDb.OleDbCommand
        Dim oCmd2 As OleDb.OleDbCommand
        Dim oConn As OleDb.OleDbConnection
        Dim oTrans As OleDb.OleDbTransaction
        Dim strConn As String
        Dim strSQL As String

        Try
            ' Create the Connection object
            ' Build the connection string		
            strConn = "Provider=sqloledb;"
            strConn &= "Data Source=(local);"
            strConn &= "Initial Catalog=Northwind;"
            strConn &= "User ID=sa;"
            strConn &= "Password=;"

            ' Create connection
            oConn = New OleDb.OleDbConnection(strConn)
            oConn.Open()

            ' Start a Transaction
            oTrans = oConn.BeginTransaction()

            ' Setup first SQL statement
            strSQL = "UPDATE Products SET UnitsInStock = UnitsInStock + 1"
            oCmd1 = New OleDb.OleDbCommand()
            With oCmd1
                .Connection = oConn
                .CommandText = strSQL
                .Transaction = oTrans
                .ExecuteNonQuery()
            End With

            ' Setup first SQL statement
            strSQL = "UPDATE Products SET UnitsInStock = UnitsInStock - 1"
            oCmd2 = New OleDb.OleDbCommand()
            With oCmd2
                .Connection = oConn
                .CommandText = strSQL
                .Transaction = oTrans
                .ExecuteNonQuery()
            End With

            oTrans.Commit()

        Catch oExcept As Exception
            oTrans.Rollback()
            MessageBox.Show(oExcept.Message)

        Finally
            oConn.Close()

        End Try

    End Sub
End Class