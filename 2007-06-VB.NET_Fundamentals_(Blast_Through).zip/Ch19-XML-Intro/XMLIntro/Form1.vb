Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
  Friend WithEvents EmployeeData1 As XMLIntro.EmployeeData
  Friend WithEvents grdEmployees As System.Windows.Forms.DataGrid
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.EmployeeData1 = New XMLIntro.EmployeeData()
    Me.grdEmployees = New System.Windows.Forms.DataGrid()
    CType(Me.EmployeeData1, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.grdEmployees, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'EmployeeData1
    '
    Me.EmployeeData1.DataSetName = "EmployeeData"
    Me.EmployeeData1.EnforceConstraints = False
    Me.EmployeeData1.Locale = New System.Globalization.CultureInfo("en-US")
    Me.EmployeeData1.Namespace = "http://tempuri.org/EmployeeData.xsd"
    '
    'grdEmployees
    '
    Me.grdEmployees.DataMember = ""
    Me.grdEmployees.HeaderForeColor = System.Drawing.SystemColors.ControlText
    Me.grdEmployees.Location = New System.Drawing.Point(8, 8)
    Me.grdEmployees.Name = "grdEmployees"
    Me.grdEmployees.Size = New System.Drawing.Size(396, 252)
    Me.grdEmployees.TabIndex = 0
    '
    'Form1
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.ClientSize = New System.Drawing.Size(408, 294)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.grdEmployees})
    Me.Name = "Form1"
    Me.Text = "Employee Info"
    CType(Me.EmployeeData1, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.grdEmployees, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)

  End Sub

#End Region

  Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    EmployeeData1.ReadXml(FileGet("EmployeeData.xml"))

    grdEmployees.DataSource = EmployeeData1.Tables(0)
  End Sub

  Private Function FileGet(ByVal FileName As String) As String
    Dim strPath As String

    strPath = Environment.CurrentDirectory

    strPath = strPath.Substring(0, strPath.LastIndexOf("\") + 1)

    Return strPath & FileName
  End Function
End Class
