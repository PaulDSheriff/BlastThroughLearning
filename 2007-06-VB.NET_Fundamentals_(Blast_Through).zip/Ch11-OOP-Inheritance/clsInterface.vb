Interface IPerson
    Property FirstName() As String
    Property LastName() As String

    Sub Print()
    Function Talk() As String
End Interface

Public Class NewEmployee
    Implements IPerson

    Private mstrFirstName As String
    Private mstrLastName As String

    Property FirstName() As String Implements IPerson.FirstName
        Get
            Return mstrFirstName
        End Get
        Set(ByVal Value As String)
            mstrFirstName = Value
        End Set
    End Property

    Property LastName() As String Implements IPerson.LastName
        Get
            Return mstrLastName
        End Get
        Set(ByVal Value As String)
            mstrLastName = Value
        End Set
    End Property

    Public Sub Print() Implements IPerson.Print

    End Sub

    Public Function Talk() As String Implements IPerson.Talk

    End Function
End Class

Public MustInherit Class Person2
    MustOverride Property FirstName() As String
    MustOverride Property LastName() As String

    MustOverride Sub Print()
    MustOverride Function Talk() As String
End Class

Public MustInherit Class Person
    Private mstrFirstName As String
    Private mstrLastName As String

    Property FirstName() As String
        Get
            Return mstrFirstName
        End Get
        Set(ByVal Value As String)
            mstrFirstName = Value
        End Set
    End Property

    Property LastName() As String
        Get
            Return mstrLastName
        End Get
        Set(ByVal Value As String)
            mstrLastName = Value
        End Set
    End Property

    Public MustOverride Sub Print()
    Public MustOverride Function Talk() As String
End Class

Public Class Manager
    Inherits Person

    Public Overrides Sub Print()
        Debug.WriteLine("Manager")
    End Sub

    Public Overrides Function Talk() As String
        Debug.WriteLine("Get to work!")
    End Function
End Class

Public Class Employee
    Inherits Person

    Public Overrides Sub Print()
        Debug.WriteLine("Employee")
    End Sub

    Public Overrides Function Talk() As String
        Debug.WriteLine("I am working!")
    End Function
End Class