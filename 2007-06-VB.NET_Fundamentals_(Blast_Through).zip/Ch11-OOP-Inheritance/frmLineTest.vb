Public Class frmLineTest
    Inherits System.Windows.Forms.Form
    
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If Disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub

    
	Private WithEvents txtReplace As System.Windows.Forms.TextBox
	Private WithEvents btnReplace As System.Windows.Forms.Button
	Private WithEvents txtFirstWord As System.Windows.Forms.TextBox

    Private WithEvents GroupBox2 As System.Windows.Forms.GroupBox
	Private WithEvents txtDelim As System.Windows.Forms.TextBox
	Private WithEvents Label1 As System.Windows.Forms.Label
	    Private WithEvents txtLine As System.Windows.Forms.TextBox
        Private WithEvents Label2 As System.Windows.Forms.Label
    Dim WithEvents frmLineTest As System.Windows.Forms.Form
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private WithEvents btnGetWord As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThroughAttribute()> Private Sub InitializeComponent()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtFirstWord = New System.Windows.Forms.TextBox()
        Me.btnGetWord = New System.Windows.Forms.Button()
        Me.txtReplace = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtLine = New System.Windows.Forms.TextBox()
        Me.btnReplace = New System.Windows.Forms.Button()
        Me.txtDelim = New System.Windows.Forms.TextBox()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtFirstWord, Me.btnGetWord})
        Me.GroupBox2.Location = New System.Drawing.Point(8, 72)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(472, 72)
        Me.GroupBox2.TabIndex = 12
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Get First Word"
        '
        'txtFirstWord
        '
        Me.txtFirstWord.Location = New System.Drawing.Point(120, 32)
        Me.txtFirstWord.Name = "txtFirstWord"
        Me.txtFirstWord.ReadOnly = True
        Me.txtFirstWord.Size = New System.Drawing.Size(344, 26)
        Me.txtFirstWord.TabIndex = 1
        Me.txtFirstWord.TabStop = False
        Me.txtFirstWord.Text = ""
        '
        'btnGetWord
        '
        Me.btnGetWord.Location = New System.Drawing.Point(8, 32)
        Me.btnGetWord.Name = "btnGetWord"
        Me.btnGetWord.Size = New System.Drawing.Size(104, 24)
        Me.btnGetWord.TabIndex = 2
        Me.btnGetWord.Text = "Get Word"
        '
        'txtReplace
        '
        Me.txtReplace.Location = New System.Drawing.Point(120, 160)
        Me.txtReplace.Name = "txtReplace"
        Me.txtReplace.ReadOnly = True
        Me.txtReplace.Size = New System.Drawing.Size(360, 26)
        Me.txtReplace.TabIndex = 14
        Me.txtReplace.TabStop = False
        Me.txtReplace.Text = ""
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(96, 16)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Delimiter"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(104, 16)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Line of Text"
        '
        'txtLine
        '
        Me.txtLine.Location = New System.Drawing.Point(120, 8)
        Me.txtLine.Name = "txtLine"
        Me.txtLine.Size = New System.Drawing.Size(360, 26)
        Me.txtLine.TabIndex = 0
        Me.txtLine.Text = "The rain in Spain stays mainly in the plain"
        '
        'btnReplace
        '
        Me.btnReplace.Location = New System.Drawing.Point(8, 160)
        Me.btnReplace.Name = "btnReplace"
        Me.btnReplace.Size = New System.Drawing.Size(104, 32)
        Me.btnReplace.TabIndex = 13
        Me.btnReplace.Text = "Replace"
        '
        'txtDelim
        '
        Me.txtDelim.Location = New System.Drawing.Point(120, 40)
        Me.txtDelim.Name = "txtDelim"
        Me.txtDelim.Size = New System.Drawing.Size(96, 26)
        Me.txtDelim.TabIndex = 1
        Me.txtDelim.Text = ","
        '
        'frmLineTest
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(488, 194)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtReplace, Me.btnReplace, Me.GroupBox2, Me.txtDelim, Me.Label1, Me.txtLine, Me.Label2})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Name = "frmLineTest"
        Me.Text = "Inherit Test"
        Me.GroupBox2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region
	
    Private Sub btnReplace_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnReplace.Click
        Dim oLine As LineDelim = New LineDelim()

        oLine.Delimiter = txtDelim.Text
        oLine.Text = txtLine.Text
        txtReplace.Text = oLine.ReplaceAll()
        txtLine.Text = txtReplace.Text
    End Sub

    Private Sub btnGetWord_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetWord.Click
        Dim oLine As LineDelim = New LineDelim()

        oLine.Delimiter = txtDelim.Text
        oLine.Text = txtLine.Text
        txtFirstWord.Text = oLine.GetWord()
    End Sub
End Class
