Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms

Public Class frmLineTest
    Inherits System.WinForms.Form
    
    Public Sub New()
        MyBase.New()
        
        frmLineTest = Me
        
        'This call is required by the Win Form Designer.
        InitializeComponent()
        
        'TODO: Add any initialization after the InitializeComponent() call
    End Sub
    
    'Form overrides dispose to clean up the component list.
    Public Overrides Sub Dispose()
        MyBase.Dispose()
        components.Dispose()
    End Sub
    
#Region " Windows Form Designer generated code "
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
	Private WithEvents txtReplace As System.WinForms.TextBox
	Private WithEvents btnReplace As System.WinForms.Button
	Private WithEvents txtFirstWord As System.WinForms.TextBox
	Private WithEvents btnFirst As System.WinForms.Button
	
	Private WithEvents GroupBox2 As System.WinForms.GroupBox
	Private WithEvents txtDelim As System.WinForms.TextBox
	Private WithEvents Label1 As System.WinForms.Label
	
	
	
	
	
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
	
	
	
	
	
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    Private WithEvents txtLine As System.WinForms.TextBox
    
    
    
    Private WithEvents Label2 As System.WinForms.Label
    
    
    Dim WithEvents frmLineTest As System.WinForms.Form
    
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
	Private Sub InitializeComponent()
		Me.components = New System.ComponentModel.Container()
		Me.txtLine = New System.WinForms.TextBox()
		Me.GroupBox2 = New System.WinForms.GroupBox()
		Me.Label2 = New System.WinForms.Label()
		Me.txtFirstWord = New System.WinForms.TextBox()
		Me.Label1 = New System.WinForms.Label()
		Me.btnFirst = New System.WinForms.Button()
		Me.txtReplace = New System.WinForms.TextBox()
		Me.btnReplace = New System.WinForms.Button()
		Me.txtDelim = New System.WinForms.TextBox()
		
		'@design Me.TrayHeight = 0
		'@design Me.TrayLargeIcon = False
		'@design Me.TrayAutoArrange = True
		txtLine.Location = New System.Drawing.Point(120, 8)
		txtLine.Text = "The rain in Spain stays mainly in the plain"
		txtLine.TabIndex = 0
		txtLine.Size = New System.Drawing.Size(272, 20)
		
		GroupBox2.Location = New System.Drawing.Point(8, 72)
		GroupBox2.TabIndex = 12
		GroupBox2.TabStop = False
		GroupBox2.Text = "Get First Word"
		GroupBox2.Size = New System.Drawing.Size(384, 64)
		
		Label2.Location = New System.Drawing.Point(8, 8)
		Label2.Text = "Line of Text"
		Label2.Size = New System.Drawing.Size(64, 16)
		Label2.TabIndex = 0
		
		txtFirstWord.Location = New System.Drawing.Point(120, 24)
		txtFirstWord.ReadOnly = True
		txtFirstWord.TabIndex = 1
		txtFirstWord.TabStop = False
		txtFirstWord.Size = New System.Drawing.Size(208, 20)
		
		Label1.Location = New System.Drawing.Point(8, 40)
		Label1.Text = "Delimiter"
		Label1.Size = New System.Drawing.Size(96, 16)
		Label1.TabIndex = 10
		
		btnFirst.Location = New System.Drawing.Point(8, 24)
		btnFirst.Size = New System.Drawing.Size(104, 24)
		btnFirst.TabIndex = 2
		btnFirst.Text = "Get Word"
		
		txtReplace.Location = New System.Drawing.Point(120, 152)
		txtReplace.ReadOnly = True
		txtReplace.TabIndex = 14
		txtReplace.TabStop = False
		txtReplace.Size = New System.Drawing.Size(272, 20)
		
		btnReplace.Location = New System.Drawing.Point(8, 152)
		btnReplace.Size = New System.Drawing.Size(104, 24)
		btnReplace.TabIndex = 13
		btnReplace.Text = "Replace"
		
		txtDelim.Location = New System.Drawing.Point(120, 40)
		txtDelim.Text = ","
		txtDelim.TabIndex = 1
		txtDelim.Size = New System.Drawing.Size(96, 20)
		
		Me.Text = "Inherit Test"
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.ClientSize = New System.Drawing.Size(400, 186)
		
		Me.Controls.Add(txtReplace)
		Me.Controls.Add(btnReplace)
		Me.Controls.Add(GroupBox2)
		Me.Controls.Add(txtDelim)
		Me.Controls.Add(Label1)
		Me.Controls.Add(txtLine)
		Me.Controls.Add(Label2)
		GroupBox2.Controls.Add(txtFirstWord)
		GroupBox2.Controls.Add(btnFirst)
	End Sub
	
#End Region
	
	Protected Sub btnReplace_Click(ByVal sender As Object, ByVal e As System.EventArgs)
		
	End Sub
	
	Protected Sub btnFirst_Click(ByVal sender As Object, ByVal e As System.EventArgs)
		Dim oLine As LineDelim = New LineDelim()
		
		oLine.Line = txtLine.Text
		txtFirstWord.Text = oLine.GetWord()
	End Sub
	
End Class
