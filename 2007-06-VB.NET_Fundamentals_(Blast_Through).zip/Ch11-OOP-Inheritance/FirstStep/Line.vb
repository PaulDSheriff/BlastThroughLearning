Public Class Line
    Private mstrLine As String
    
	Public Overloads Sub New()
		' Do Nothing
	End Sub
	
	Public Overloads Sub New(ByVal strLine As String)
		mstrLine = strLine
	End Sub
	
	Property Line() As String
		Get
			Return mstrLine
		End Get
		Set
			mstrLine = Value
		End Set
	End Property
	
	ReadOnly Property Length() As Integer
		Get
			Return mstrLine.Length
		End Get
	End Property
	
	Public Overloads Function GetWord() As String
		Dim astrWords() As String
		
		astrWords = mstrLine.Split(" ".ToCharArray())
		
		Return astrWords(0)
	End Function
	
	Public Overloads Function GetWord(ByVal intPosition As Integer) As String
		Dim astrWords() As String
		
		astrWords = mstrLine.Split(" ".ToCharArray())
		
		If intPosition > astrWords.Length Then
			Return ""
		Else
			Return astrWords(intPosition - 1)
		End If
	End Function
	
	Public Overloads Function GetWord(ByVal strSearch As String) As String
		Dim astrWords() As String
		Dim intLoop As Integer
		
		astrWords = mstrLine.Split(" ".ToCharArray())
		
		For intLoop = 0 To astrWords.Length - 1
			If astrWords(intLoop).IndexOf(strSearch) > -1 Then
				Exit For
			End If
		Next
		If intLoop < astrWords.Length Then
			Return astrWords(intLoop)
		End If
	End Function
End Class
