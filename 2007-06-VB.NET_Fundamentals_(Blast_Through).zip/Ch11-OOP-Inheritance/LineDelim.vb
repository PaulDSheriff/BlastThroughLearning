Public Class LineDelim
    Inherits LineData
	
	Private mstrDelim As String = " "
	Private mstrOriginal As String
	
	Public Property Delimiter() As String
		Get
			Return mstrDelim
        End Get
        Set(ByVal Value As String)
            mstrDelim = Value
        End Set
    End Property
	
	Public ReadOnly Property OriginalLine() As String
		Get
			Return mstrOriginal
		End Get
	End Property
	
    Public Overloads Overrides Function GetWord() As String
        Dim astrWords() As String

        astrWords = Split(MyBase.Text, mstrDelim)

        Return astrWords(0)
    End Function

    Public Function ReplaceAll() As String
        mstrOriginal = MyBase.Text

        Return Replace(MyBase.Text, " ", mstrDelim)
    End Function
End Class
