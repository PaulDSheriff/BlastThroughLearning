Public Class frmMain
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents MdiClient1 As System.Windows.Forms.MdiClient
    Friend WithEvents mnuFProducts As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFExit As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFile As System.Windows.Forms.MenuItem
    Friend WithEvents mnuMain As System.Windows.Forms.MainMenu
    Friend WithEvents mnuWVertical As System.Windows.Forms.MenuItem
    Friend WithEvents mnuWHorizontal As System.Windows.Forms.MenuItem
    Friend WithEvents mnuWArrange As System.Windows.Forms.MenuItem
    Friend WithEvents mnuWCascade As System.Windows.Forms.MenuItem
    Friend WithEvents mnuEdit As System.Windows.Forms.MenuItem
    Friend WithEvents mnuECut As System.Windows.Forms.MenuItem
    Friend WithEvents mnuECopy As System.Windows.Forms.MenuItem
    Friend WithEvents mnuEPaste As System.Windows.Forms.MenuItem
    Friend WithEvents mnuWindow As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFAddMenus As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFRemoveMenus As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFAddNew As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFChildMenus As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFormat As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFFont As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFColor As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFSize As System.Windows.Forms.MenuItem

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mnuFormat = New System.Windows.Forms.MenuItem()
        Me.mnuFFont = New System.Windows.Forms.MenuItem()
        Me.mnuFColor = New System.Windows.Forms.MenuItem()
        Me.mnuFSize = New System.Windows.Forms.MenuItem()
        Me.MenuItem1 = New System.Windows.Forms.MenuItem()
        Me.mnuFAddMenus = New System.Windows.Forms.MenuItem()
        Me.mnuWCascade = New System.Windows.Forms.MenuItem()
        Me.mnuFChildMenus = New System.Windows.Forms.MenuItem()
        Me.mnuEPaste = New System.Windows.Forms.MenuItem()
        Me.mnuFAddNew = New System.Windows.Forms.MenuItem()
        Me.mnuWHorizontal = New System.Windows.Forms.MenuItem()
        Me.mnuWVertical = New System.Windows.Forms.MenuItem()
        Me.MenuItem4 = New System.Windows.Forms.MenuItem()
        Me.mnuFExit = New System.Windows.Forms.MenuItem()
        Me.mnuFRemoveMenus = New System.Windows.Forms.MenuItem()
        Me.mnuECopy = New System.Windows.Forms.MenuItem()
        Me.mnuFile = New System.Windows.Forms.MenuItem()
        Me.mnuFProducts = New System.Windows.Forms.MenuItem()
        Me.mnuWArrange = New System.Windows.Forms.MenuItem()
        Me.mnuECut = New System.Windows.Forms.MenuItem()
        Me.MdiClient1 = New System.Windows.Forms.MdiClient()
        Me.mnuEdit = New System.Windows.Forms.MenuItem()
        Me.mnuWindow = New System.Windows.Forms.MenuItem()
        Me.mnuMain = New System.Windows.Forms.MainMenu()
        Me.SuspendLayout()
        '
        'mnuFormat
        '
        Me.mnuFormat.Index = 2
        Me.mnuFormat.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFFont, Me.mnuFColor, Me.mnuFSize})
        Me.mnuFormat.Text = "Format"
        '
        'mnuFFont
        '
        Me.mnuFFont.Index = 0
        Me.mnuFFont.RadioCheck = True
        Me.mnuFFont.Text = "Font"
        '
        'mnuFColor
        '
        Me.mnuFColor.Index = 1
        Me.mnuFColor.RadioCheck = True
        Me.mnuFColor.Text = "Color"
        '
        'mnuFSize
        '
        Me.mnuFSize.Index = 2
        Me.mnuFSize.RadioCheck = True
        Me.mnuFSize.Text = "Size"
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 2
        Me.MenuItem1.Text = "-"
        '
        'mnuFAddMenus
        '
        Me.mnuFAddMenus.Index = 3
        Me.mnuFAddMenus.Text = "&Add Menus"
        '
        'mnuWCascade
        '
        Me.mnuWCascade.Index = 0
        Me.mnuWCascade.Text = "&Cascade"
        '
        'mnuFChildMenus
        '
        Me.mnuFChildMenus.Index = 1
        Me.mnuFChildMenus.Text = "Child with Menus"
        '
        'mnuEPaste
        '
        Me.mnuEPaste.Index = 2
        Me.mnuEPaste.Text = "&Paste"
        '
        'mnuFAddNew
        '
        Me.mnuFAddNew.Index = 5
        Me.mnuFAddNew.Text = "Add &New Menu"
        '
        'mnuWHorizontal
        '
        Me.mnuWHorizontal.Index = 1
        Me.mnuWHorizontal.Text = "Tile &Horizontal"
        '
        'mnuWVertical
        '
        Me.mnuWVertical.Index = 2
        Me.mnuWVertical.Text = "Tile &Vertical"
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 6
        Me.MenuItem4.Text = "-"
        '
        'mnuFExit
        '
        Me.mnuFExit.Index = 7
        Me.mnuFExit.Text = "E&xit"
        '
        'mnuFRemoveMenus
        '
        Me.mnuFRemoveMenus.Index = 4
        Me.mnuFRemoveMenus.Text = "&Remove Menus"
        '
        'mnuECopy
        '
        Me.mnuECopy.Index = 1
        Me.mnuECopy.Text = "&Copy"
        '
        'mnuFile
        '
        Me.mnuFile.Index = 0
        Me.mnuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFProducts, Me.mnuFChildMenus, Me.MenuItem1, Me.mnuFAddMenus, Me.mnuFRemoveMenus, Me.mnuFAddNew, Me.MenuItem4, Me.mnuFExit})
        Me.mnuFile.Text = "&File"
        '
        'mnuFProducts
        '
        Me.mnuFProducts.Index = 0
        Me.mnuFProducts.Text = "&Products"
        '
        'mnuWArrange
        '
        Me.mnuWArrange.Index = 3
        Me.mnuWArrange.Text = "&Arrange Icons"
        '
        'mnuECut
        '
        Me.mnuECut.Index = 0
        Me.mnuECut.Text = "Cu&t"
        '
        'MdiClient1
        '
        Me.MdiClient1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MdiClient1.Name = "MdiClient1"
        Me.MdiClient1.TabIndex = 0
        '
        'mnuEdit
        '
        Me.mnuEdit.Index = 1
        Me.mnuEdit.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuECut, Me.mnuECopy, Me.mnuEPaste})
        Me.mnuEdit.MergeOrder = 1
        Me.mnuEdit.Text = "&Edit"
        '
        'mnuWindow
        '
        Me.mnuWindow.Index = 3
        Me.mnuWindow.MdiList = True
        Me.mnuWindow.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuWCascade, Me.mnuWHorizontal, Me.mnuWVertical, Me.mnuWArrange})
        Me.mnuWindow.MergeOrder = 2
        Me.mnuWindow.Text = "&Window"
        '
        'mnuMain
        '
        Me.mnuMain.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFile, Me.mnuEdit, Me.mnuFormat, Me.mnuWindow})
        '
        'frmMain
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(592, 326)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.MdiClient1})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IsMdiContainer = True
        Me.Menu = Me.mnuMain
        Me.Name = "frmMain"
        Me.Text = "Main Form"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ResumeLayout(False)

    End Sub

#End Region

    Public Sub CenterChildForm(ByVal frmChild As Form)
        Dim ptLoc As Point = New Point()

        ptLoc.X = CInt(Me.ClientRectangle.Width / 2) _
         - CInt(frmChild.Size.Width / 2)
        ptLoc.Y = CInt(Me.ClientRectangle.Height / 2) _
         - CInt(frmChild.Size.Height / 2)

        frmChild.Location = ptLoc
    End Sub

    Private Sub mnuWCascade_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuWCascade.Click
        Me.LayoutMdi(MdiLayout.Cascade)
    End Sub

    Private Sub mnuFAddMenus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFAddMenus.Click
        mnuFAddMenus.Checked = True

        ' Adds these menus to the end of the file menu
        mnuFile.MenuItems.Add("New Menu 1")
        mnuFile.MenuItems.Add("New Menu 2")
    End Sub

    Private Sub mnuFRemoveMenus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFRemoveMenus.Click
        mnuFRemoveMenus.Checked = True

        With mnuFile.MenuItems
            ' Remove the last two items
            .RemoveAt(.Count - 1)
            .RemoveAt(.Count - 1)
        End With
    End Sub

    Private Sub mnuFExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFExit.Click
        Me.Close()
    End Sub

    Private Sub mnuWHorizontal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuWHorizontal.Click
        Me.LayoutMdi(MdiLayout.TileHorizontal)
    End Sub

    Private Sub mnuWVertical_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuWVertical.Click
        Me.LayoutMdi(MdiLayout.TileVertical)
    End Sub

    Private Sub mnuWArrange_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuWArrange.Click
        Me.LayoutMdi(MdiLayout.ArrangeIcons)
    End Sub

    Private Sub mnuFAddNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFAddNew.Click
        Dim mnuNew As MainMenu
        Dim mnuMaint As MenuItem

        ' Create New Menu
        mnuNew = New MainMenu()

        mnuMaint = mnuNew.MenuItems.Add("Maintenance")
        ' Place it after the Edit menu
        mnuMaint.MergeOrder = 1
        mnuMaint.MergeType = MenuMerge.Add
        ' Add Sub Items
        mnuMaint.MenuItems.Add("Suppliers")
        mnuMaint.MenuItems.Add("Categories")

        ' Merge to the top level menu
        mnuMain.MergeMenu(mnuNew)
    End Sub

    Private Sub mnuFFont_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFFont.Click
        mnuFFont.Checked = True
        mnuFColor.Checked = False
        mnuFSize.Checked = False
    End Sub

    Private Sub mnuFColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFColor.Click
        mnuFFont.Checked = False
        mnuFColor.Checked = True
        mnuFSize.Checked = False
    End Sub

    Private Sub mnuFSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFSize.Click
        mnuFFont.Checked = False
        mnuFColor.Checked = False
        mnuFSize.Checked = True
    End Sub

    Private Sub frmMain_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim frm As frmLogin

        ' Make sure main form gets drawn
        Me.Show()
        Me.Refresh()

        ' Display the Login form
        frm = New frmLogin()
        frm.TopMost = True

        If frm.ShowDialog() = DialogResult.OK Then
            ' Check user name and password
            MessageBox.Show("Valid Login ID and Password")
        Else
            Me.Close()
        End If
    End Sub
End Class
