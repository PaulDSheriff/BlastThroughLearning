Public Class frmDebugEvents
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()
        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        Debug.WriteLine("frmDebugEvents_New()")

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents btnAssert As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtNumber As System.Windows.Forms.TextBox
    Friend WithEvents btnWriteLineIf As System.Windows.Forms.Button

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtNumber = New System.Windows.Forms.TextBox()
        Me.btnAssert = New System.Windows.Forms.Button()
        Me.btnWriteLineIf = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(8, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(153, 19)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Enter Number (0-5)"
        '
        'txtNumber
        '
        Me.txtNumber.Location = New System.Drawing.Point(176, 16)
        Me.txtNumber.Name = "txtNumber"
        Me.txtNumber.Size = New System.Drawing.Size(56, 26)
        Me.txtNumber.TabIndex = 2
        Me.txtNumber.Text = ""
        '
        'btnAssert
        '
        Me.btnAssert.Location = New System.Drawing.Point(176, 48)
        Me.btnAssert.Name = "btnAssert"
        Me.btnAssert.Size = New System.Drawing.Size(104, 32)
        Me.btnAssert.TabIndex = 0
        Me.btnAssert.Text = "Assert"
        '
        'btnWriteLineIf
        '
        Me.btnWriteLineIf.Location = New System.Drawing.Point(176, 88)
        Me.btnWriteLineIf.Name = "btnWriteLineIf"
        Me.btnWriteLineIf.Size = New System.Drawing.Size(104, 32)
        Me.btnWriteLineIf.TabIndex = 0
        Me.btnWriteLineIf.Text = "WriteLineIf"
        '
        'frmDebugEvents
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(440, 146)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnWriteLineIf, Me.txtNumber, Me.Label1, Me.btnAssert})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmDebugEvents"
        Me.Text = "Show WinForm Events"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub frmDebugEvents_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    Debug.WriteLine("frmDebugEvents_Load()")
  End Sub

  Private Sub frmDebugEvents_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
    Debug.WriteLine("frmDebugEvents_Activated()")
  End Sub

  Private Sub frmDebugEvents_ChangeUICues(ByVal sender As Object, ByVal e As System.Windows.Forms.UICuesEventArgs) Handles MyBase.ChangeUICues
    Debug.WriteLine("frmDebugEvents_ChangeUICues()")
  End Sub

  Private Sub frmDebugEvents_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Click
    Debug.WriteLine("frmDebugEvents_Click()")
  End Sub

  Private Sub frmDebugEvents_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
    Debug.WriteLine("frmDebugEvents_Closing()")
  End Sub

  Private Sub frmDebugEvents_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
    Debug.WriteLine("frmDebugEvents_Closed()")
  End Sub

  Private Sub frmDebugEvents_Deactivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Deactivate
    Debug.WriteLine("frmDebugEvents_Deactivate()")
  End Sub

  Private Sub frmDebugEvents_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.GotFocus
    Debug.WriteLine("frmDebugEvents_GotFocus()")
  End Sub

  Private Sub frmDebugEvents_HandleCreated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.HandleCreated
    Debug.WriteLine("frmDebugEvents_HandleCreated()")
  End Sub

  Private Sub frmDebugEvents_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Enter
    Debug.WriteLine("frmDebugEvents_Enter()")
  End Sub

  Private Sub frmDebugEvents_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Leave
    Debug.WriteLine("frmDebugEvents_Leave()")
  End Sub

  Private Sub frmDebugEvents_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.LostFocus
    Debug.WriteLine("frmDebugEvents_LostFocus()")
  End Sub

  Private Sub frmDebugEvents_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
    Debug.WriteLine("frmDebugEvents_Paint()")
  End Sub

  Private Sub frmDebugEvents_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
    Debug.WriteLine("frmDebugEvents_Resize()")
  End Sub

  Private Sub frmDebugEvents_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.SizeChanged
    Debug.WriteLine("frmDebugEvents_SizeChanged()")
  End Sub

  Private Sub frmDebugEvents_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseDown
    Debug.WriteLine("frmDebugEvents_MouseDown()")
  End Sub

  Private Sub frmDebugEvents_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseUp
    Debug.WriteLine("frmDebugEvents_MouseUp()")
  End Sub

  Private Sub frmDebugEvents_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Disposed
    Debug.WriteLine("frmDebugEvents_Disposed()")
  End Sub

  Private Sub btnAssert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAssert.Click
    Dim intNum As Integer

    intNum = CInt(Val(txtNumber.Text))
    Debug.Assert(intNum >= 0 And intNum <= 5, _
     "Number must be between 0 and 5")
  End Sub

  Private Sub btnWriteLineIf_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles btnWriteLineIf.Click
    Dim intNum As Integer

    intNum = CInt(Val(txtNumber.Text))
    Debug.WriteLineIf(intNum >= 0 And intNum <= 5, _
     "You input a correct number")
  End Sub
End Class
