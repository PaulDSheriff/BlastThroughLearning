#Const conLanguage = 1

Public Class frmDebug
    Inherits System.Windows.Forms.Form

    Private mintModVar As Integer
    Friend WithEvents btnBreakPoints As System.Windows.Forms.Button
    Friend WithEvents btnDebugClass As System.Windows.Forms.Button
        Friend WithEvents btnCond As System.Windows.Forms.Button

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnDebugClass = New System.Windows.Forms.Button()
        Me.btnBreakPoints = New System.Windows.Forms.Button()
        Me.btnCond = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnDebugClass
        '
        Me.btnDebugClass.Location = New System.Drawing.Point(136, 8)
        Me.btnDebugClass.Name = "btnDebugClass"
        Me.btnDebugClass.Size = New System.Drawing.Size(120, 40)
        Me.btnDebugClass.TabIndex = 0
        Me.btnDebugClass.Text = "Debug Class"
        '
        'btnBreakPoints
        '
        Me.btnBreakPoints.Location = New System.Drawing.Point(8, 8)
        Me.btnBreakPoints.Name = "btnBreakPoints"
        Me.btnBreakPoints.Size = New System.Drawing.Size(120, 40)
        Me.btnBreakPoints.TabIndex = 0
        Me.btnBreakPoints.Text = "Breakpoints"
        '
        'btnCond
        '
        Me.btnCond.Location = New System.Drawing.Point(264, 8)
        Me.btnCond.Name = "btnCond"
        Me.btnCond.Size = New System.Drawing.Size(120, 40)
        Me.btnCond.TabIndex = 0
        Me.btnCond.Text = "Conditional"
        '
        'frmDebug
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(392, 58)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnDebugClass, Me.btnCond, Me.btnBreakPoints})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmDebug"
        Me.Text = "Debugger Samples"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnBreakPoints_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBreakPoints.Click
        BreakPointsSample()
    End Sub

    Private Sub BreakPointsSample()
        Dim intValue As Integer

        intValue = 10

        Call Proc1()
    End Sub

    Private Sub Proc1()
        Dim intLoop As Integer
        Dim intValue As Integer

        For intLoop = 1 To 5
            Call Proc2()
            intValue += 10
            mintModVar += 100
        Next
    End Sub

    Private Sub Proc2()
        Dim strValue As String

        strValue = "This is a string"

        Call Proc3()
    End Sub

    Private Sub Proc3()
        Dim intLoop As Integer

        intLoop = 20
    End Sub

    Private Function TestMe() As String
        Return "Hi There"
    End Function

    Private Sub btnCond_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCond.Click
#If conLanguage = 1 Then
        MessageBox.Show("Good Morning, Mr. Gates")
#Else
        MessageBox.Show("Guten Morgen, Herr Gates")
#End If
    End Sub

    Private Sub btnDebugClass_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDebugClass.Click
        Dim frm As frmDebugEvents

        frm = New frmDebugEvents()

        frm.Show()
    End Sub

End Class
