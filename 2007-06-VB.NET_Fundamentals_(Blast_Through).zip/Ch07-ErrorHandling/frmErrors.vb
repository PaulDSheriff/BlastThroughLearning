Imports System.IO
Imports System.Security

Public Class frmErrors
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container
  Friend WithEvents btnErrorHandling As System.Windows.Forms.Button
  Friend WithEvents Label2 As System.Windows.Forms.Label
  Friend WithEvents cboErrorHandling As System.Windows.Forms.ComboBox
  Friend WithEvents Label1 As System.Windows.Forms.Label
  Friend WithEvents txtFileName As System.Windows.Forms.TextBox
  
  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
Me.btnErrorHandling = New System.Windows.Forms.Button()
Me.Label1 = New System.Windows.Forms.Label()
Me.Label2 = New System.Windows.Forms.Label()
Me.txtFileName = New System.Windows.Forms.TextBox()
Me.cboErrorHandling = New System.Windows.Forms.ComboBox()
Me.SuspendLayout()
'
'btnErrorHandling
'
Me.btnErrorHandling.Location = New System.Drawing.Point(152, 96)
Me.btnErrorHandling.Name = "btnErrorHandling"
Me.btnErrorHandling.Size = New System.Drawing.Size(248, 40)
Me.btnErrorHandling.TabIndex = 5
Me.btnErrorHandling.Text = "Try Error Handling"
'
'Label1
'
Me.Label1.Location = New System.Drawing.Point(16, 20)
Me.Label1.Name = "Label1"
Me.Label1.Size = New System.Drawing.Size(128, 24)
Me.Label1.TabIndex = 2
Me.Label1.Text = "File Name:"
'
'Label2
'
Me.Label2.Location = New System.Drawing.Point(16, 60)
Me.Label2.Name = "Label2"
Me.Label2.Size = New System.Drawing.Size(136, 24)
Me.Label2.TabIndex = 4
Me.Label2.Text = "Error Handling:"
'
'txtFileName
'
Me.txtFileName.Location = New System.Drawing.Point(152, 16)
Me.txtFileName.Name = "txtFileName"
Me.txtFileName.Size = New System.Drawing.Size(248, 30)
Me.txtFileName.TabIndex = 1
Me.txtFileName.Text = "a:\autoexec.bat"
'
'cboErrorHandling
'
Me.cboErrorHandling.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
Me.cboErrorHandling.DropDownWidth = 248
Me.cboErrorHandling.Location = New System.Drawing.Point(152, 56)
Me.cboErrorHandling.MaxDropDownItems = 12
Me.cboErrorHandling.Name = "cboErrorHandling"
Me.cboErrorHandling.Size = New System.Drawing.Size(248, 31)
Me.cboErrorHandling.TabIndex = 3
'
'frmErrors
'
Me.AutoScaleBaseSize = New System.Drawing.Size(9, 23)
Me.ClientSize = New System.Drawing.Size(416, 141)
Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cboErrorHandling, Me.txtFileName, Me.btnErrorHandling, Me.Label1, Me.Label2})
Me.Font = New System.Drawing.Font("Tahoma", 14!)
Me.Name = "frmErrors"
Me.Text = "Handling Exceptions"
Me.ResumeLayout(False)

  End Sub

#End Region

  Private Items As String() = _
  {"No Error Handling", _
  "Simple Catch", _
  "Error Bubbling", _
  "Simple Exception", _
  "Which Exception?", _
  "Multiple Exceptions", _
  "Throw Exception", _
  "Test Finally", _
  "User-Defined Exception"}

  Private twtl As TextWriterTraceListener

  Private Sub NoErrorHandling()
    Dim lngSize As Long
    Dim s As FileStream

    ' No error handling? If there's an error, 
    ' you just get an unhandled exception.    
    s = File.Open(txtFileName.Text, FileMode.Open)
    lngSize = s.Length
    s.Close()

  End Sub

  Private Sub SimpleCatch()
    Dim lngSize As Long
    Dim s As FileStream

    ' This is better, but not much. You
    ' don't really have any idea what 
    ' went wrong!
    Try
      s = File.Open(txtFileName.Text, FileMode.Open)
      lngSize = s.Length
      s.Close()
    Catch
      MessageBox.Show("Error occurred!")
    End Try
  End Sub

  Private Sub ErrorBubbling()
    Dim lngSize As Long
    Dim s As FileStream

    ' What happens to unhandled errors?
    Try
      A()
    Catch
      MessageBox.Show("Error occurred!")
    End Try
  End Sub

  Private Sub SimpleException()
    Dim lngSize As Long
    Dim s As FileStream

    ' Display the entire contents of the Exception object.
    Try

      s = File.Open(txtFileName.Text, FileMode.Open)
      lngSize = s.Length
      s.Close()

    Catch exp As Exception
      MessageBox.Show(exp.ToString)

    End Try
  End Sub

  Private Sub WhichException()
    Dim lngSize As Long
    Dim s As FileStream

    ' Now you can at least tell what went wrong!
    Try
      s = File.Open(txtFileName.Text, FileMode.Open)
      lngSize = s.Length
      s.Close()
    Catch e As Exception
      MessageBox.Show("Error occurred: " & e.Message)
    End Try
  End Sub

  Private Sub ThrowException()
    Dim lngSize As Long
    Dim s As FileStream

    ' Catch an exception thrown by the called procedure.
    Try
      TestThrow()
    Catch e As FileNotFoundException
      MessageBox.Show("Error occurred: " & e.Message)
      ' Use e.InnerException to get to error

      ' that triggered this one.
      Try
        MessageBox.Show(e.InnerException.Message)
      Catch
        ' DO nothing at all!
      End Try
    Catch e As Exception

    End Try
  End Sub

  Private Sub TestThrow()
    Dim lngSize As Long
    Dim s As FileStream

    ' No matter what happens, throw back 
    ' a File Not Found exception.
    Try
      s = File.Open(txtFileName.Text, FileMode.Open)
      lngSize = s.Length
      s.Close()
    Catch e As Exception
      Throw (New FileNotFoundException( _
        "Unable to open the specified file."))
    End Try
  End Sub

  Private Sub MultipleExceptions()
    Dim lngSize As Long
    Dim s As FileStream

    ' Use the most specific exception that you can.
    ' To test this, change the file name to be:

    ' 1.) In a good location, but the file doesn't exist.
    ' 2.) On a drive that doesn't exist.
    ' 3.) In a path that doesn't exist.
    ' 4.) On a drive that isn't ready.

    Try
      s = File.Open(txtFileName.Text, FileMode.Open)
      lngSize = s.Length
      s.Close()

      ' The code will match against the most specific error
      ' it can. Both FileNotFoundException and 
      ' DirectoryNotFoundException inherit from 
      ' IOException, and the code will use those first. 
      ' If they weren't here, the code would always fall 
      ' into(IOException) for those errors.        
    Catch e As ArgumentException
      MessageBox.Show( _
       "You specified an invalid filename. " & _
       "Make sure you enter something besides spaces.")
    Catch e As FileNotFoundException
      MessageBox.Show( _
       "The file you specified can't be found. " & _
       "Please try again.")
    Catch e As ArgumentNullException
      MessageBox.Show("You passed in a Null argument.")
    Catch e As UnauthorizedAccessException
      MessageBox.Show( _
       "You specified a folder name, not a file name.")
    Catch e As DirectoryNotFoundException
      MessageBox.Show( _
      "You specified a folder that doesn't exist " & _
       "or can't be found.")
    Catch e As SecurityException
      MessageBox.Show("You don't have sufficient rights " & _
       "to open the selected file.")
    Catch e As IOException
      ' A generic exception handler, for any IO error
      ' that hasn't been caught yet. Here, it ought
      ' to just be that the drive isn't ready.
      MessageBox.Show("The drive you selected is not ready. " & _
       "Make sure the drive contains valid media.")
    Catch e As Exception
      MessageBox.Show("An unknown error occurred.")
    End Try
  End Sub

  Private Function TestFinally() As Integer
    Dim lngSize As Long
    Dim s As FileStream

    ' Use Finally to run code no matter what else happens.
    ' A somewhat meaningless example, but you get the 
    ' idea.

    Try
      s = File.Open(txtFileName.Text, FileMode.Open)
      lngSize = s.Length
      s.Close()
    Catch e As Exception
      MessageBox.Show(e.Message)
      Return 1
    Finally
      ' Run this code no matter what happens.
      s = Nothing
      TestFinally = 2
    End Try
  End Function

  Private Sub UserDefinedException()
    Dim lngSize As Long

    ' Test a user-defined exception.

    Try
      lngSize = GetSize(txtFileName.Text)
    Catch e As FileTooLargeException
      MessageBox.Show( _
       String.Format("Please select a smaller file! The file you selected was {0} bytes.", _
       e.FileSize))

    Catch e As Exception
      MessageBox.Show(e.Message)
    End Try
  End Sub

  Private Function GetSize(ByVal strFileName As String) As Long
    Dim lngSize As Long
    Dim s As FileStream

    ' Return the file size. If it's larger than 100 bytes
    ' (an arbitrary size), throw a FileTooLargeException
    ' (a user-defined exception) to the caller.

    Try
      s = File.Open(txtFileName.Text, FileMode.Open)
      lngSize = s.Length
      s.Close()
      If lngSize > 100 Then
        ' Pass back the new exception. There's no
        ' inner exception to pass back, so pass Nothing.
        Throw (New FileTooLargeException( _
         "The file you selected is too large.", _
         Nothing, lngSize))
      End If
      Return lngSize
    Catch
      ' Throw the exception right back to the caller.
      Throw
    Finally
      ' Run this code no matter what happens.
      s = Nothing
    End Try
  End Function

  Private Sub A()
    B()
  End Sub

  Private Sub B()
    C()
  End Sub

  Private Sub C()
    ' No error handling here!
    Dim lngSize As Long
    Dim s As FileStream

    s = File.Open(txtFileName.Text, FileMode.Open)
    lngSize = s.Length
    s.Close()
  End Sub

  Private Sub btnErrorHandling_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnErrorHandling.Click
    Dim lngIndex As Long

    lngIndex = cboErrorHandling.SelectedIndex
    Select Case lngIndex
      Case 0
        NoErrorHandling()
      Case 1
        SimpleCatch()
      Case 2
        ErrorBubbling()
      Case 3
        SimpleException()
      Case 4
        WhichException()
      Case 5
        MultipleExceptions()
      Case 6
        ThrowException()
      Case 7
        TestFinally()
      Case 8
        UserDefinedException()
      Case Else
    End Select
  End Sub

  Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    With Me.cboErrorHandling
      .Items.AddRange(Items)
      .SelectedIndex = 0
    End With

  End Sub

  Public Class FileTooLargeException
    Inherits Exception

    Private mlngFileSize As Long

    Public Sub New(ByVal Message As String)
      MyBase.New(Message)
    End Sub

    Public Sub New(ByVal Message As String, ByVal Inner As Exception)
      MyBase.New(Message, Inner)
    End Sub

    Public Sub New(ByVal Message As String, _
     ByVal Inner As Exception, _
     ByVal FileSize As Long)
      MyBase.New(Message, Inner)
      mlngFileSize = FileSize
    End Sub

    Public ReadOnly Property FileSize() As Long
      Get
        Return mlngFileSize
      End Get
    End Property
  End Class
End Class