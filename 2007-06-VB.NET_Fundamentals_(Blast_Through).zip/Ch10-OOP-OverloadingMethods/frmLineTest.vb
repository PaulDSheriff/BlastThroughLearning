Public Class frmLineTest
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub

  Private WithEvents txtWord As System.Windows.Forms.TextBox
  Private WithEvents btnGetWord As System.Windows.Forms.Button
  Private WithEvents txtWordNum As System.Windows.Forms.TextBox
  Private WithEvents Label5 As System.Windows.Forms.Label
  Private WithEvents GroupBox3 As System.Windows.Forms.GroupBox
  Private WithEvents txtSearch As System.Windows.Forms.TextBox
  Private WithEvents Label3 As System.Windows.Forms.Label
  Private WithEvents GroupBox1 As System.Windows.Forms.GroupBox
  Private WithEvents txtLine As System.Windows.Forms.TextBox
  Private WithEvents Label2 As System.Windows.Forms.Label

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  Private WithEvents btnGetPos As System.Windows.Forms.Button
  Private WithEvents txtPos As System.Windows.Forms.TextBox
  <System.Diagnostics.DebuggerStepThroughAttribute()> Private Sub InitializeComponent()
    Me.btnGetPos = New System.Windows.Forms.Button()
    Me.GroupBox3 = New System.Windows.Forms.GroupBox()
    Me.txtWord = New System.Windows.Forms.TextBox()
    Me.btnGetWord = New System.Windows.Forms.Button()
    Me.txtWordNum = New System.Windows.Forms.TextBox()
    Me.Label5 = New System.Windows.Forms.Label()
    Me.Label2 = New System.Windows.Forms.Label()
    Me.GroupBox1 = New System.Windows.Forms.GroupBox()
    Me.txtSearch = New System.Windows.Forms.TextBox()
    Me.Label3 = New System.Windows.Forms.Label()
    Me.txtPos = New System.Windows.Forms.TextBox()
    Me.txtLine = New System.Windows.Forms.TextBox()
    Me.GroupBox3.SuspendLayout()
    Me.GroupBox1.SuspendLayout()
    Me.SuspendLayout()
    '
    'btnGetPos
    '
    Me.btnGetPos.Location = New System.Drawing.Point(16, 64)
    Me.btnGetPos.Name = "btnGetPos"
    Me.btnGetPos.Size = New System.Drawing.Size(128, 23)
    Me.btnGetPos.TabIndex = 5
    Me.btnGetPos.Text = "Get Position"
    '
    'GroupBox3
    '
    Me.GroupBox3.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtWord, Me.btnGetWord, Me.txtWordNum, Me.Label5})
    Me.GroupBox3.Location = New System.Drawing.Point(8, 48)
    Me.GroupBox3.Name = "GroupBox3"
    Me.GroupBox3.Size = New System.Drawing.Size(448, 104)
    Me.GroupBox3.TabIndex = 8
    Me.GroupBox3.TabStop = False
    Me.GroupBox3.Text = "Find Occurence of Word"
    '
    'txtWord
    '
    Me.txtWord.Location = New System.Drawing.Point(168, 64)
    Me.txtWord.Name = "txtWord"
    Me.txtWord.ReadOnly = True
    Me.txtWord.Size = New System.Drawing.Size(192, 26)
    Me.txtWord.TabIndex = 3
    Me.txtWord.TabStop = False
    Me.txtWord.Text = ""
    '
    'btnGetWord
    '
    Me.btnGetWord.Location = New System.Drawing.Point(16, 64)
    Me.btnGetWord.Name = "btnGetWord"
    Me.btnGetWord.Size = New System.Drawing.Size(104, 24)
    Me.btnGetWord.TabIndex = 2
    Me.btnGetWord.Text = "Get Word"
    '
    'txtWordNum
    '
    Me.txtWordNum.Location = New System.Drawing.Point(168, 24)
    Me.txtWordNum.Name = "txtWordNum"
    Me.txtWordNum.Size = New System.Drawing.Size(48, 26)
    Me.txtWordNum.TabIndex = 1
    Me.txtWordNum.Text = "1"
    '
    'Label5
    '
    Me.Label5.Location = New System.Drawing.Point(8, 32)
    Me.Label5.Name = "Label5"
    Me.Label5.Size = New System.Drawing.Size(104, 16)
    Me.Label5.TabIndex = 0
    Me.Label5.Text = "Enter Word Number"
    '
    'Label2
    '
    Me.Label2.Location = New System.Drawing.Point(8, 8)
    Me.Label2.Name = "Label2"
    Me.Label2.Size = New System.Drawing.Size(104, 16)
    Me.Label2.TabIndex = 0
    Me.Label2.Text = "Line of Text"
    '
    'GroupBox1
    '
    Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnGetPos, Me.txtSearch, Me.Label3, Me.txtPos})
    Me.GroupBox1.Location = New System.Drawing.Point(8, 160)
    Me.GroupBox1.Name = "GroupBox1"
    Me.GroupBox1.Size = New System.Drawing.Size(448, 104)
    Me.GroupBox1.TabIndex = 9
    Me.GroupBox1.TabStop = False
    Me.GroupBox1.Text = "Find Word"
    '
    'txtSearch
    '
    Me.txtSearch.Location = New System.Drawing.Point(168, 24)
    Me.txtSearch.Name = "txtSearch"
    Me.txtSearch.Size = New System.Drawing.Size(128, 26)
    Me.txtSearch.TabIndex = 4
    Me.txtSearch.Text = "Spain"
    '
    'Label3
    '
    Me.Label3.Location = New System.Drawing.Point(16, 32)
    Me.Label3.Name = "Label3"
    Me.Label3.Size = New System.Drawing.Size(160, 24)
    Me.Label3.TabIndex = 0
    Me.Label3.Text = "Enter Word to Find"
    '
    'txtPos
    '
    Me.txtPos.Location = New System.Drawing.Point(168, 64)
    Me.txtPos.Name = "txtPos"
    Me.txtPos.ReadOnly = True
    Me.txtPos.Size = New System.Drawing.Size(192, 26)
    Me.txtPos.TabIndex = 6
    Me.txtPos.TabStop = False
    Me.txtPos.Text = ""
    '
    'txtLine
    '
    Me.txtLine.Location = New System.Drawing.Point(120, 8)
    Me.txtLine.Name = "txtLine"
    Me.txtLine.Size = New System.Drawing.Size(336, 26)
    Me.txtLine.TabIndex = 0
    Me.txtLine.Text = "The rain in Spain stays mainly in the plain"
    '
    'frmLineTest
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
    Me.ClientSize = New System.Drawing.Size(464, 266)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.GroupBox3, Me.GroupBox1, Me.txtLine, Me.Label2})
    Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
    Me.Name = "frmLineTest"
    Me.Text = "Overloaded Method Test"
    Me.GroupBox3.ResumeLayout(False)
    Me.GroupBox1.ResumeLayout(False)
    Me.ResumeLayout(False)

  End Sub

#End Region

  Private Sub btnGetPos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetPos.Click
    Dim oLine As New LineData()

    oLine.Text = txtLine.Text

    txtPos.Text = oLine.GetWord(txtSearch.Text).ToString()
  End Sub

  Private Sub btnGetWord_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnGetWord.Click
    'Dim oLine As New LineData()

    'oLine.Text = txtLine.Text
    'txtWord.Text = oLine.GetWord(CInt(txtWordNum.Text))

    '** Overloaded New() Constructor
    Dim oLine As New LineData(txtLine.Text)

    txtWord.Text = oLine.GetWord(Convert.ToInt32(txtWordNum.Text))
  End Sub
End Class
