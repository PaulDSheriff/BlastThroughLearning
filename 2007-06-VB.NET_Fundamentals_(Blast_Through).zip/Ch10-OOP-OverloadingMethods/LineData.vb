Public Class LineData
    Private mstrText As String

    Public Sub New()
        ' Do Nothing
    End Sub

    Public Sub New(ByVal strText As String)
        mstrText = strText
    End Sub

    Property Text() As String
        Get
            Return mstrText
        End Get
        Set(ByVal Value As String)
            mstrText = Value
        End Set
    End Property

    ReadOnly Property Length() As Integer
        Get
            Return mstrText.Length
        End Get
    End Property

    Public Function GetWord() As String
        Dim astrWords() As String

        astrWords = Split(mstrText, " ")

        Return astrWords(0)
    End Function

    Public Function GetWord(ByVal intPosition As Integer) As String
        Dim astrWords() As String

        astrWords = Split(mstrText, " ")

        If intPosition > astrWords.Length Then
            Return ""
        Else
            Return astrWords(intPosition - 1)
        End If
    End Function

    Public Function GetWord(ByVal strSearch As String) As Integer
        Dim astrWords() As String
        Dim intPos As Integer

        astrWords = Split(mstrText, " ")

    intPos = Array.IndexOf(astrWords, strSearch)

        If intPos > -1 And intPos < astrWords.Length Then
            Return intPos + 1
        Else
            Return -1
        End If
    End Function
End Class
