Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms

Public Class frmLineTest
    Inherits System.WinForms.Form
    
    Public Sub New()
        MyBase.New()
        
        frmLineTest = Me
        
        'This call is required by the Win Form Designer.
        InitializeComponent()
        
        'TODO: Add any initialization after the InitializeComponent() call
    End Sub
    
    'Form overrides dispose to clean up the component list.
    Public Overrides Sub Dispose()
        MyBase.Dispose()
        components.Dispose()
    End Sub
    
#Region " Windows Form Designer generated code "
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents txtWord As System.WinForms.TextBox
    Private WithEvents btnGetWord As System.WinForms.Button
    Private WithEvents txtWordNum As System.WinForms.TextBox
    Private WithEvents Label5 As System.WinForms.Label
    Private WithEvents GroupBox3 As System.WinForms.GroupBox
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    Private WithEvents btnGetWord2 As System.WinForms.Button
    Private WithEvents txtSearch As System.WinForms.TextBox
    Private WithEvents Label3 As System.WinForms.Label
    Private WithEvents txtWord2 As System.WinForms.TextBox
    Private WithEvents GroupBox1 As System.WinForms.GroupBox
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    Private WithEvents txtLine As System.WinForms.TextBox
    
    
    
    Private WithEvents Label2 As System.WinForms.Label
    
    
    Dim WithEvents frmLineTest As System.WinForms.Form
    
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.txtLine = New System.WinForms.TextBox()
        Me.btnGetWord = New System.WinForms.Button()
        Me.Label3 = New System.WinForms.Label()
        Me.GroupBox3 = New System.WinForms.GroupBox()
        Me.btnGetWord2 = New System.WinForms.Button()
        Me.GroupBox1 = New System.WinForms.GroupBox()
        Me.Label2 = New System.WinForms.Label()
        Me.txtSearch = New System.WinForms.TextBox()
        Me.txtWord = New System.WinForms.TextBox()
        Me.txtWordNum = New System.WinForms.TextBox()
        Me.Label5 = New System.WinForms.Label()
        Me.txtWord2 = New System.WinForms.TextBox()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        txtLine.Location = New System.Drawing.Point(120, 8)
        txtLine.Text = "The rain in Spain stays mainly in the plain"
        txtLine.TabIndex = 0
        txtLine.Size = New System.Drawing.Size(272, 20)
        
        btnGetWord.Location = New System.Drawing.Point(16, 56)
        btnGetWord.Size = New System.Drawing.Size(104, 24)
        btnGetWord.TabIndex = 2
        btnGetWord.Text = "Get Word"
        
        Label3.Location = New System.Drawing.Point(16, 32)
        Label3.Text = "Enter Word to Find"
        Label3.Size = New System.Drawing.Size(104, 16)
        Label3.TabIndex = 1
        
        GroupBox3.Location = New System.Drawing.Point(8, 32)
        GroupBox3.TabIndex = 10
        GroupBox3.TabStop = False
        GroupBox3.Text = "Find Occurence of Word"
        GroupBox3.Size = New System.Drawing.Size(384, 96)
        
        btnGetWord2.Location = New System.Drawing.Point(16, 56)
        btnGetWord2.Size = New System.Drawing.Size(104, 23)
        btnGetWord2.TabIndex = 0
        btnGetWord2.Text = "Get Word"
        
        GroupBox1.Location = New System.Drawing.Point(8, 136)
        GroupBox1.TabIndex = 4
        GroupBox1.TabStop = False
        GroupBox1.Text = "Find Word"
        GroupBox1.Size = New System.Drawing.Size(384, 96)
        
        Label2.Location = New System.Drawing.Point(8, 8)
        Label2.Text = "Line of Text"
        Label2.Size = New System.Drawing.Size(64, 16)
        Label2.TabIndex = 2
        
        txtSearch.Location = New System.Drawing.Point(128, 24)
        txtSearch.Text = "Spain"
        txtSearch.TabIndex = 0
        txtSearch.Size = New System.Drawing.Size(128, 20)
        
        txtWord.Location = New System.Drawing.Point(128, 56)
        txtWord.ReadOnly = True
        txtWord.TabIndex = 3
        txtWord.Size = New System.Drawing.Size(192, 20)
        
        txtWordNum.Location = New System.Drawing.Point(128, 16)
        txtWordNum.Text = "1"
        txtWordNum.TabIndex = 1
        txtWordNum.Size = New System.Drawing.Size(48, 20)
        
        Label5.Location = New System.Drawing.Point(8, 24)
        Label5.Text = "Enter Word Number"
        Label5.Size = New System.Drawing.Size(104, 16)
        Label5.TabIndex = 0
        
        txtWord2.Location = New System.Drawing.Point(128, 56)
        txtWord2.ReadOnly = True
        txtWord2.TabIndex = 0
        txtWord2.Size = New System.Drawing.Size(192, 20)
        Me.Text = "Overloaded Method Test"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(400, 242)
        
        Me.Controls.Add(GroupBox3)
        Me.Controls.Add(GroupBox1)
        Me.Controls.Add(txtLine)
        Me.Controls.Add(Label2)
        GroupBox1.Controls.Add(btnGetWord2)
        GroupBox1.Controls.Add(txtSearch)
        GroupBox1.Controls.Add(Label3)
        GroupBox1.Controls.Add(txtWord2)
        GroupBox3.Controls.Add(txtWord)
        GroupBox3.Controls.Add(btnGetWord)
        GroupBox3.Controls.Add(txtWordNum)
        GroupBox3.Controls.Add(Label5)
    End Sub
    
#End Region
    
 
End Class
