Public Class Line
    Private mstrLine As String
    
    Property Line() As String
        Get
            Return mstrLine
        End Get
        Set
            mstrLine = Value
        End Set
    End Property
    
    ReadOnly Property Length() As Integer
        Get
            Return Len(mstrLine)
        End Get
    End Property
    
    Public Function GetWord() As String
        Dim astrWords() As String
        
        astrWords = Split(mstrLine, " ")
        
        Return astrWords(0)
    End Function
    
End Class
