Public MustInherit Class Person
  Public FirstName As String
  Public LastName As String

  Public MustOverride Sub Print()
  Public MustOverride Function Talk() As String
End Class

Public Class Employee
  Inherits Person

  Public Overrides Sub Print()
    Debug.WriteLine("Employee")
  End Sub

  Public Overrides Function Talk() As String
    Return "Employee"
  End Function
End Class

Public Class Manager
  Inherits Person

  Public Overrides Sub Print()
    Debug.WriteLine("Manager")
  End Sub

  Public Overrides Function Talk() As String
    Return "Manager"
  End Function
End Class
