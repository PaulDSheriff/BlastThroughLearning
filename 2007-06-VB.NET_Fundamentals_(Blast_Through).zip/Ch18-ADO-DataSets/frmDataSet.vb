Public Class frmDataSet
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Win Form Designer.
        InitializeComponent()

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    Private WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnLoadDataSet As System.Windows.Forms.Button
    Private WithEvents btnLoadTable As System.Windows.Forms.Button

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lstProducts As System.Windows.Forms.ListBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnLoadDataSet = New System.Windows.Forms.Button()
        Me.btnLoadTable = New System.Windows.Forms.Button()
        Me.lstProducts = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(168, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Products"
        '
        'btnLoadDataSet
        '
        Me.btnLoadDataSet.Location = New System.Drawing.Point(80, 240)
        Me.btnLoadDataSet.Name = "btnLoadDataSet"
        Me.btnLoadDataSet.Size = New System.Drawing.Size(128, 48)
        Me.btnLoadDataSet.TabIndex = 2
        Me.btnLoadDataSet.Text = "Load Using DataSet"
        '
        'btnLoadTable
        '
        Me.btnLoadTable.Location = New System.Drawing.Point(216, 240)
        Me.btnLoadTable.Name = "btnLoadTable"
        Me.btnLoadTable.Size = New System.Drawing.Size(136, 48)
        Me.btnLoadTable.TabIndex = 3
        Me.btnLoadTable.Text = "Load Using DataTable"
        '
        'lstProducts
        '
        Me.lstProducts.ItemHeight = 20
        Me.lstProducts.Location = New System.Drawing.Point(8, 40)
        Me.lstProducts.Name = "lstProducts"
        Me.lstProducts.Size = New System.Drawing.Size(344, 184)
        Me.lstProducts.TabIndex = 4
        '
        'frmDataSet
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(362, 292)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lstProducts, Me.btnLoadDataSet, Me.Label1, Me.btnLoadTable})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "frmDataSet"
        Me.Text = "Load Data Using DataSet Object"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnLoadTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoadTable.Click
        Dim cmd As OleDb.OleDbCommand
        Dim da As OleDb.OleDbDataAdapter
        Dim dt As New DataTable()
        Dim strSQL As String
        Dim strConn As String
        Dim intLoop As Integer

        ' Get Connection String
        strConn = ConnectStringBuild()

        ' Build SQL String
        strSQL = "SELECT * "
        strSQL &= "FROM Products "
        strSQL &= "ORDER BY ProductName"

        Try
            ' Create the Command Text
            cmd = New OleDb.OleDbCommand()
            With cmd
                .Connection = New OleDb.OleDbConnection(strConn)
                .CommandText = strSQL
                .Connection.Open()
            End With

            da = New OleDb.OleDbDataAdapter()
            With da
                .SelectCommand = cmd
                .Fill(dt)
            End With
            cmd.Connection.Close()

            With lstProducts
                .DisplayMember = "ProductName"
                .ValueMember = "ProductID"

                .DataSource = dt
            End With

        Catch oExcept As Exception
            MessageBox.Show(oExcept.Message)

        End Try
    End Sub

    Private Sub btnLoadDataSet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoadDataSet.Click
        DataSetLoad()
    End Sub

    Private Sub DataSetLoad()
        Dim da As OleDb.OleDbDataAdapter
        Dim ds As DataSet
        Dim strSQL As String
        Dim strConn As String

        ' Get Connection String
        strConn = ConnectStringBuild()

        ' Build SQL String
        strSQL = "SELECT ProductID, ProductName "
        strSQL &= "FROM Products "
        strSQL &= "ORDER BY ProductName"

        ds = New DataSet()
        Try
            ' Create New Data Adapter
            da = New OleDb.OleDbDataAdapter(strSQL, strConn)
            ' Fill Data Set From Adapter
            ' and assign table name
            da.Fill(ds, "Products")

            With lstProducts
                .Items.Clear()

                .DisplayMember = "ProductName"
                .ValueMember = "ProductID"

                .DataSource = ds.Tables("Products")
            End With

        Catch oExcept As Exception
            MessageBox.Show(oExcept.Message)

        End Try
    End Sub

    Private Function ConnectStringBuild() As String
        Dim strConn As String

        strConn = "Provider=sqloledb;"
        strConn &= "Data Source=(local);"
        strConn &= "Initial Catalog=Northwind;"
        strConn &= "User ID=sa"

        Return strConn
    End Function
End Class
