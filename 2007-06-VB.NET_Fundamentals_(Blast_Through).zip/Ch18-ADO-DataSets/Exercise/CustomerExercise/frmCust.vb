Public Class frmCust
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtCustID As System.Windows.Forms.TextBox
    Friend WithEvents txtCustName As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtContactName As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtContactTitle As System.Windows.Forms.TextBox

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents grdCustomers As System.Windows.Forms.DataGrid
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtCustID = New System.Windows.Forms.TextBox()
        Me.txtCustName = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtContactName = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtContactTitle = New System.Windows.Forms.TextBox()
        Me.grdCustomers = New System.Windows.Forms.DataGrid()
        CType(Me.grdCustomers, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 208)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(96, 24)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Customer ID"
        '
        'txtCustID
        '
        Me.txtCustID.Location = New System.Drawing.Point(112, 208)
        Me.txtCustID.Name = "txtCustID"
        Me.txtCustID.Size = New System.Drawing.Size(104, 20)
        Me.txtCustID.TabIndex = 2
        Me.txtCustID.Text = ""
        '
        'txtCustName
        '
        Me.txtCustName.Location = New System.Drawing.Point(112, 240)
        Me.txtCustName.Name = "txtCustName"
        Me.txtCustName.Size = New System.Drawing.Size(240, 20)
        Me.txtCustName.TabIndex = 2
        Me.txtCustName.Text = ""
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 240)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 24)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Customer Name"
        '
        'txtContactName
        '
        Me.txtContactName.Location = New System.Drawing.Point(112, 272)
        Me.txtContactName.Name = "txtContactName"
        Me.txtContactName.Size = New System.Drawing.Size(240, 20)
        Me.txtContactName.TabIndex = 2
        Me.txtContactName.Text = ""
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(8, 272)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(96, 24)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Contact Name"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(8, 304)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(96, 24)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Contact Title"
        '
        'txtContactTitle
        '
        Me.txtContactTitle.Location = New System.Drawing.Point(112, 304)
        Me.txtContactTitle.Name = "txtContactTitle"
        Me.txtContactTitle.Size = New System.Drawing.Size(240, 20)
        Me.txtContactTitle.TabIndex = 2
        Me.txtContactTitle.Text = ""
        '
        'grdCustomers
        '
        Me.grdCustomers.DataMember = ""
        Me.grdCustomers.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdCustomers.Location = New System.Drawing.Point(8, 8)
        Me.grdCustomers.Name = "grdCustomers"
        Me.grdCustomers.Size = New System.Drawing.Size(456, 184)
        Me.grdCustomers.TabIndex = 3
        '
        'frmCust
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(472, 338)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.grdCustomers, Me.Label4, Me.txtContactTitle, Me.txtContactName, Me.Label3, Me.txtCustName, Me.Label2, Me.txtCustID, Me.Label1})
        Me.Name = "frmCust"
        Me.Text = "Customer Information"
        CType(Me.grdCustomers, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

End Class
