Public Class frmProduct
  Inherits System.Windows.Forms.Form

  Private mdt As DataTable
  Private mda As OleDb.OleDbDataAdapter

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Win Form Designer.
    InitializeComponent()
  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub

  Private WithEvents Label8 As System.Windows.Forms.Label
  Private WithEvents txtReorder As System.Windows.Forms.TextBox
  Private WithEvents Label7 As System.Windows.Forms.Label
  Private WithEvents txtOnOrder As System.Windows.Forms.TextBox
  Private WithEvents Label6 As System.Windows.Forms.Label
  Private WithEvents txtInStock As System.Windows.Forms.TextBox
  Private WithEvents Label5 As System.Windows.Forms.Label
  Private WithEvents Label4 As System.Windows.Forms.Label
  Private WithEvents cboCategory As System.Windows.Forms.ComboBox
  Private WithEvents cboSupplier As System.Windows.Forms.ComboBox
  Private WithEvents btnClear As System.Windows.Forms.Button
  Private WithEvents btnDelete As System.Windows.Forms.Button
  Private WithEvents btnUpdate As System.Windows.Forms.Button
  Private WithEvents txtID As System.Windows.Forms.TextBox
  Private WithEvents Label3 As System.Windows.Forms.Label
  Private WithEvents chkDisc As System.Windows.Forms.CheckBox
  Private WithEvents txtPrice As System.Windows.Forms.TextBox
  Private WithEvents Label2 As System.Windows.Forms.Label
  Private WithEvents txtQty As System.Windows.Forms.TextBox
  Private WithEvents Label1 As System.Windows.Forms.Label
  Private WithEvents txtName As System.Windows.Forms.TextBox
  Private WithEvents lblFirst As System.Windows.Forms.Label
  Private WithEvents btnAdd As System.Windows.Forms.Button

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  Friend WithEvents lstProducts As System.Windows.Forms.ListBox
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.btnUpdate = New System.Windows.Forms.Button()
    Me.chkDisc = New System.Windows.Forms.CheckBox()
    Me.txtOnOrder = New System.Windows.Forms.TextBox()
    Me.txtPrice = New System.Windows.Forms.TextBox()
    Me.cboSupplier = New System.Windows.Forms.ComboBox()
    Me.Label8 = New System.Windows.Forms.Label()
    Me.txtReorder = New System.Windows.Forms.TextBox()
    Me.txtName = New System.Windows.Forms.TextBox()
    Me.txtQty = New System.Windows.Forms.TextBox()
    Me.Label5 = New System.Windows.Forms.Label()
    Me.Label6 = New System.Windows.Forms.Label()
    Me.Label7 = New System.Windows.Forms.Label()
    Me.btnDelete = New System.Windows.Forms.Button()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.Label4 = New System.Windows.Forms.Label()
    Me.Label3 = New System.Windows.Forms.Label()
    Me.lblFirst = New System.Windows.Forms.Label()
    Me.Label2 = New System.Windows.Forms.Label()
    Me.cboCategory = New System.Windows.Forms.ComboBox()
    Me.txtID = New System.Windows.Forms.TextBox()
    Me.txtInStock = New System.Windows.Forms.TextBox()
    Me.btnClear = New System.Windows.Forms.Button()
    Me.btnAdd = New System.Windows.Forms.Button()
    Me.lstProducts = New System.Windows.Forms.ListBox()
    Me.SuspendLayout()
    '
    'btnUpdate
    '
    Me.btnUpdate.Location = New System.Drawing.Point(216, 400)
    Me.btnUpdate.Name = "btnUpdate"
    Me.btnUpdate.Size = New System.Drawing.Size(120, 48)
    Me.btnUpdate.TabIndex = 21
    Me.btnUpdate.Text = "Update"
    '
    'chkDisc
    '
    Me.chkDisc.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
    Me.chkDisc.Location = New System.Drawing.Point(264, 368)
    Me.chkDisc.Name = "chkDisc"
    Me.chkDisc.Size = New System.Drawing.Size(144, 16)
    Me.chkDisc.TabIndex = 19
    Me.chkDisc.Text = "Discontinued"
    '
    'txtOnOrder
    '
    Me.txtOnOrder.Location = New System.Drawing.Point(392, 288)
    Me.txtOnOrder.MaxLength = 12
    Me.txtOnOrder.Name = "txtOnOrder"
    Me.txtOnOrder.Size = New System.Drawing.Size(88, 26)
    Me.txtOnOrder.TabIndex = 16
    Me.txtOnOrder.Text = ""
    '
    'txtPrice
    '
    Me.txtPrice.Location = New System.Drawing.Point(392, 208)
    Me.txtPrice.MaxLength = 12
    Me.txtPrice.Name = "txtPrice"
    Me.txtPrice.Size = New System.Drawing.Size(88, 26)
    Me.txtPrice.TabIndex = 12
    Me.txtPrice.Text = ""
    '
    'cboSupplier
    '
    Me.cboSupplier.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
    Me.cboSupplier.DropDownWidth = 200
    Me.cboSupplier.Location = New System.Drawing.Point(392, 88)
    Me.cboSupplier.Name = "cboSupplier"
    Me.cboSupplier.Size = New System.Drawing.Size(200, 28)
    Me.cboSupplier.Sorted = True
    Me.cboSupplier.TabIndex = 6
    '
    'Label8
    '
    Me.Label8.Location = New System.Drawing.Point(264, 328)
    Me.Label8.Name = "Label8"
    Me.Label8.Size = New System.Drawing.Size(128, 24)
    Me.Label8.TabIndex = 17
    Me.Label8.Text = "Reorder Level"
    '
    'txtReorder
    '
    Me.txtReorder.Location = New System.Drawing.Point(392, 328)
    Me.txtReorder.MaxLength = 12
    Me.txtReorder.Name = "txtReorder"
    Me.txtReorder.Size = New System.Drawing.Size(88, 26)
    Me.txtReorder.TabIndex = 18
    Me.txtReorder.Text = ""
    '
    'txtName
    '
    Me.txtName.Location = New System.Drawing.Point(392, 48)
    Me.txtName.MaxLength = 20
    Me.txtName.Name = "txtName"
    Me.txtName.Size = New System.Drawing.Size(200, 26)
    Me.txtName.TabIndex = 4
    Me.txtName.Text = ""
    '
    'txtQty
    '
    Me.txtQty.Location = New System.Drawing.Point(392, 168)
    Me.txtQty.MaxLength = 40
    Me.txtQty.Name = "txtQty"
    Me.txtQty.Size = New System.Drawing.Size(200, 26)
    Me.txtQty.TabIndex = 10
    Me.txtQty.Text = ""
    '
    'Label5
    '
    Me.Label5.Location = New System.Drawing.Point(264, 208)
    Me.Label5.Name = "Label5"
    Me.Label5.Size = New System.Drawing.Size(112, 24)
    Me.Label5.TabIndex = 11
    Me.Label5.Text = "Unit Price"
    '
    'Label6
    '
    Me.Label6.Location = New System.Drawing.Point(264, 248)
    Me.Label6.Name = "Label6"
    Me.Label6.Size = New System.Drawing.Size(112, 24)
    Me.Label6.TabIndex = 13
    Me.Label6.Text = "Units In Stock"
    '
    'Label7
    '
    Me.Label7.Location = New System.Drawing.Point(264, 288)
    Me.Label7.Name = "Label7"
    Me.Label7.Size = New System.Drawing.Size(128, 24)
    Me.Label7.TabIndex = 15
    Me.Label7.Text = "Units On Order"
    '
    'btnDelete
    '
    Me.btnDelete.Location = New System.Drawing.Point(344, 400)
    Me.btnDelete.Name = "btnDelete"
    Me.btnDelete.Size = New System.Drawing.Size(120, 48)
    Me.btnDelete.TabIndex = 22
    Me.btnDelete.Text = "Delete"
    '
    'Label1
    '
    Me.Label1.Location = New System.Drawing.Point(264, 88)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(112, 24)
    Me.Label1.TabIndex = 5
    Me.Label1.Text = "Suppliers"
    '
    'Label4
    '
    Me.Label4.Location = New System.Drawing.Point(264, 168)
    Me.Label4.Name = "Label4"
    Me.Label4.Size = New System.Drawing.Size(112, 24)
    Me.Label4.TabIndex = 9
    Me.Label4.Text = "Qty Per Unit"
    '
    'Label3
    '
    Me.Label3.Location = New System.Drawing.Point(264, 8)
    Me.Label3.Name = "Label3"
    Me.Label3.Size = New System.Drawing.Size(112, 24)
    Me.Label3.TabIndex = 1
    Me.Label3.Text = "Product ID"
    '
    'lblFirst
    '
    Me.lblFirst.Location = New System.Drawing.Point(264, 48)
    Me.lblFirst.Name = "lblFirst"
    Me.lblFirst.Size = New System.Drawing.Size(120, 24)
    Me.lblFirst.TabIndex = 3
    Me.lblFirst.Text = "Product Name"
    '
    'Label2
    '
    Me.Label2.Location = New System.Drawing.Point(264, 128)
    Me.Label2.Name = "Label2"
    Me.Label2.Size = New System.Drawing.Size(112, 24)
    Me.Label2.TabIndex = 7
    Me.Label2.Text = "Categories"
    '
    'cboCategory
    '
    Me.cboCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
    Me.cboCategory.DropDownWidth = 200
    Me.cboCategory.Location = New System.Drawing.Point(392, 128)
    Me.cboCategory.Name = "cboCategory"
    Me.cboCategory.Size = New System.Drawing.Size(200, 28)
    Me.cboCategory.TabIndex = 8
    '
    'txtID
    '
    Me.txtID.Location = New System.Drawing.Point(392, 8)
    Me.txtID.MaxLength = 20
    Me.txtID.Name = "txtID"
    Me.txtID.Size = New System.Drawing.Size(64, 26)
    Me.txtID.TabIndex = 2
    Me.txtID.Text = ""
    '
    'txtInStock
    '
    Me.txtInStock.Location = New System.Drawing.Point(392, 248)
    Me.txtInStock.MaxLength = 12
    Me.txtInStock.Name = "txtInStock"
    Me.txtInStock.Size = New System.Drawing.Size(88, 26)
    Me.txtInStock.TabIndex = 14
    Me.txtInStock.Text = ""
    '
    'btnClear
    '
    Me.btnClear.Location = New System.Drawing.Point(472, 400)
    Me.btnClear.Name = "btnClear"
    Me.btnClear.Size = New System.Drawing.Size(120, 48)
    Me.btnClear.TabIndex = 23
    Me.btnClear.Text = "Clear"
    '
    'btnAdd
    '
    Me.btnAdd.Location = New System.Drawing.Point(88, 400)
    Me.btnAdd.Name = "btnAdd"
    Me.btnAdd.Size = New System.Drawing.Size(120, 48)
    Me.btnAdd.TabIndex = 20
    Me.btnAdd.Text = "Add"
    '
    'lstProducts
    '
    Me.lstProducts.ItemHeight = 20
    Me.lstProducts.Location = New System.Drawing.Point(8, 16)
    Me.lstProducts.Name = "lstProducts"
    Me.lstProducts.Size = New System.Drawing.Size(240, 364)
    Me.lstProducts.TabIndex = 0
    '
    'frmProduct
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
    Me.ClientSize = New System.Drawing.Size(600, 458)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lstProducts, Me.Label8, Me.txtReorder, Me.Label7, Me.txtOnOrder, Me.Label6, Me.txtInStock, Me.Label5, Me.Label4, Me.cboCategory, Me.cboSupplier, Me.btnClear, Me.btnDelete, Me.btnUpdate, Me.txtID, Me.Label3, Me.chkDisc, Me.txtPrice, Me.Label2, Me.txtQty, Me.Label1, Me.txtName, Me.lblFirst, Me.btnAdd})
    Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
    Me.Name = "frmProduct"
    Me.Text = "Product Information"
    Me.ResumeLayout(False)

  End Sub

#End Region

  Private Sub frmProduct_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    ' Load Suppliers
    SupplierLoad()
    ' Load Categories
    CategoryLoad()

    ' Initialize the DataTable member variable
    DataTableCreate()
    ' Load List Box of Products
    ListLoad()
    ' Select the First Row, if data in list box
    If lstProducts.Items.Count > 0 Then
      lstProducts.SetSelected(0, True)
    End If
  End Sub

  Private Sub SupplierLoad()
    Dim da As OleDb.OleDbDataAdapter
    Dim dt As DataTable = New DataTable()
    Dim strSQL As String
    Dim strConn As String

    strConn = ConnectStringBuild()

    strSQL = "SELECT SupplierID, CompanyName "
    strSQL &= "FROM Suppliers"

    Try
      da = New OleDb.OleDbDataAdapter(strSQL, strConn)
      da.Fill(dt)

      With cboSupplier
        ' Turn off Redraw
        .BeginUpdate()

        .DisplayMember = "CompanyName"
        .ValueMember = "SupplierID"

        .DataSource = dt

        ' Turn on Redraw
        .EndUpdate()
      End With

    Catch oExcept As Exception
      MessageBox.Show(oExcept.Message)

    End Try
  End Sub

  Private Sub CategoryLoad()
    Dim da As OleDb.OleDbDataAdapter
    Dim dt As DataTable = New DataTable()
    Dim strSQL As String
    Dim strConn As String

    strConn = ConnectStringBuild()

    strSQL = "SELECT CategoryID, CategoryName "
    strSQL &= "FROM Categories"

    Try
      da = New OleDb.OleDbDataAdapter(strSQL, strConn)
      da.Fill(dt)

      With cboCategory
        ' Turn off Redraw
        .BeginUpdate()

        .DisplayMember = "CategoryName"
        .ValueMember = "CategoryID"

        .DataSource = dt

        ' Turn on Redraw
        .EndUpdate()
      End With

    Catch oExcept As Exception
      MessageBox.Show(oExcept.Message)

    End Try
  End Sub

  Private Sub DataTableCreate()
    Dim strSQL As String
    Dim strConn As String

    ' Get Connection String
    strConn = ConnectStringBuild()

    ' Build SQL String
    strSQL = "SELECT * "
    strSQL &= "FROM Products ORDER BY ProductName"

    mdt = New DataTable()
    Try
      ' Create New DataAdapter
      mda = New OleDb.OleDbDataAdapter(strSQL, strConn)
      ' Fill DataTable From Adapter and give it a name
      mda.Fill(mdt)
      ' Create a Primary Key
      With mdt
        .PrimaryKey = New DataColumn() _
          {.Columns("ProductID")}
      End With

    Catch oExcept As Exception
      MessageBox.Show(oExcept.Message)

    End Try
  End Sub

  Private Sub ListLoad()
    With lstProducts
      .Enabled = True

      ' Turn off Redraw
      .BeginUpdate()

      .DisplayMember = "ProductName"
      .ValueMember = "ProductID"

      .DataSource = mdt

      ' Turn on Redraw
      .EndUpdate()
    End With
  End Sub

  Private Sub DataAdd()
    Dim bld As OleDb.OleDbCommandBuilder
    Dim dr As DataRow

    ' Create New DataRow Object From DataTable
    dr = mdt.NewRow()

    ' Tell Data Row new data is coming in
    dr.BeginEdit()

    ' Load new data into row
    dr("ProductID") = -1  ' Need a dummy value here
    dr("ProductName") = txtName.Text
    dr("SupplierID") = CInt(cboSupplier.SelectedValue)
    dr("CategoryID") = CInt(cboCategory.SelectedValue)
    dr("QuantityPerUnit") = txtQty.Text
    dr("UnitPrice") = CDec(txtPrice.Text)
    dr("UnitsInStock") = CShort(txtInStock.Text)
    dr("UnitsOnOrder") = CShort(txtOnOrder.Text)
    dr("ReorderLevel") = CShort(txtReorder.Text)
    dr("Discontinued") = CBool(chkDisc.Checked)

    ' Add DataRow to DataTable
    mdt.Rows.Add(dr)

    Try
      ' Create CommandBuilder from Adapter
      bld = New OleDb.OleDbCommandBuilder(mda)

      ' Get Insert Command Object
      mda.InsertCommand = bld.GetInsertCommand()

      ' Submit INSERT statement through Adapter
      mda.Update(mdt)
      ' Tell DataTable changes to data source are done
      mdt.AcceptChanges()

      ' Recreate the DataTable
      DataTableCreate()
      ' Reload the list box
      ListLoad()

    Catch oException As Exception
      MessageBox.Show(oException.Message)

    End Try
  End Sub

  Private Sub DataUpdate()
    Dim bld As OleDb.OleDbCommandBuilder
    Dim dr As DataRow
    Dim intID As Integer

    ' Get Primary Key From List Box
    intID = CInt(lstProducts.SelectedValue)

    ' Find Row To Update
    dr = mdt.Rows.Find(intID)

    ' Begin the editing process
    dr.BeginEdit()

    ' Load new data into row
    dr("ProductName") = txtName.Text
    dr("SupplierID") = CInt(cboSupplier.SelectedValue)
    dr("CategoryID") = CInt(cboCategory.SelectedValue)
    dr("QuantityPerUnit") = txtQty.Text
    dr("UnitPrice") = CDec(Val(txtPrice.Text))
    dr("UnitsInStock") = CShort(Val(txtInStock.Text))
    dr("UnitsOnOrder") = CShort(Val(txtOnOrder.Text))
    dr("ReorderLevel") = CShort(Val(txtReorder.Text))
    dr("Discontinued") = CBool(chkDisc.Checked)

    Try
      ' Create CommandBuilder from Adapter
      bld = New OleDb.OleDbCommandBuilder(mda)

      ' Get Update Command Object
      mda.UpdateCommand = bld.GetUpdateCommand()

      ' Submit UPDATE through Adapter
      mda.Update(mdt)
      ' Tell DataTable changes to data source are done
      mdt.AcceptChanges()

      ' Reload the list box
      ListLoad()

    Catch oException As Exception
      MessageBox.Show(oException.Message)

    End Try
  End Sub

  Private Sub DataDelete()
    Dim bld As OleDb.OleDbCommandBuilder
    Dim dr As DataRow
    Dim intID As Integer

    ' Get Primary Key From List Box
    intID = CInt(lstProducts.SelectedValue)

    ' Find DataRow To Delete
    dr = mdt.Rows.Find(intID)

    ' Mark DataRow for deletion
    dr.Delete()

    Try
      ' Create CommandBuilder from Adapter
      bld = New OleDb.OleDbCommandBuilder(mda)

      ' Get Delete Command Object
      mda.DeleteCommand = bld.GetDeleteCommand()

      ' Submit DELETE through Adapter
      mda.Update(mdt)
      ' Tell DataTable changes to data source are done
      mdt.AcceptChanges()

      ' Reload the list box
      ListLoad()

    Catch oException As Exception
      MessageBox.Show(oException.Message)

    End Try
  End Sub

  Private Sub FormShow()
    Dim dr As DataRow
    Dim strID As String

    ' Get Primary Key From List Box
    strID = CStr(lstProducts.SelectedValue)

    Try
      ' Find row in DataTable
      dr = mdt.Rows.Find(CInt(strID))

      ' Display the Data
      txtID.Text = dr("ProductID").ToString()
      txtName.Text = dr("ProductName").ToString()
      strID = dr("SupplierID").ToString()
      Call FindItem(cboSupplier, strID)
      strID = dr("CategoryID").ToString()
      Call FindItem(cboCategory, strID)
      txtQty.Text = dr("QuantityPerUnit").ToString()
      txtPrice.Text = dr("UnitPrice").ToString()
      txtInStock.Text = dr("UnitsInStock").ToString()
      txtOnOrder.Text = dr("UnitsOnOrder").ToString()
      txtReorder.Text = dr("ReorderLevel").ToString()
      chkDisc.Checked = CType(dr("Discontinued"), Boolean)

    Catch e As Exception
      MessageBox.Show(e.Message)

    End Try
  End Sub

  Private Sub FormClear()
    lstProducts.Enabled = False
    txtID.Text = ""
    txtName.Text = ""
    cboSupplier.SelectedIndex = -1
    cboCategory.SelectedIndex = -1
    txtQty.Text = ""
    txtPrice.Text = "0"
    txtInStock.Text = "0"
    txtOnOrder.Text = "0"
    txtReorder.Text = "0"
    chkDisc.Checked = False
  End Sub


  Private Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
    DataAdd()
  End Sub

  Private Sub btnClear_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClear.Click
    FormClear()
  End Sub

  Private Sub btnDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelete.Click
    DataDelete()
  End Sub

  Private Sub btnUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
    DataUpdate()
  End Sub

  Private Sub lstProducts_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstProducts.SelectedIndexChanged
    FormShow()
  End Sub

  Private Sub FindItem(ByVal cboCombo As ComboBox, _
    ByVal strID As String)
    Dim intPos As Integer
    Dim intLoop As Integer
    Dim boolFound As Boolean

    With cboCombo
      ' Turn off Redraw
      .BeginUpdate()

      intPos = .SelectedIndex
      For intLoop = 0 To .Items.Count - 1
        .SelectedIndex = intLoop
        If CInt(.SelectedValue) = CInt(strID) Then
          boolFound = True
          Exit For
        End If
      Next
      If Not boolFound Then
        .SelectedIndex = intPos
      End If

      ' Turn on Redraw
      .EndUpdate()
    End With
  End Sub

  Private Function ConnectStringBuild() As String
    Dim strConn As String

    strConn = "Provider=sqloledb;"
    strConn &= "Data Source=(local);"
    strConn &= "Initial Catalog=Northwind;"
    strConn &= "User ID=sa"

    Return strConn
  End Function
End Class
