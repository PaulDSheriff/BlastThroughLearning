Public Class frmMultiple
    Inherits System.Windows.Forms.Form
    
    ' Module Variables
    Dim mds As New DataSet()

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Win Form Designer.
        InitializeComponent()

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    Private WithEvents Label2 As System.Windows.Forms.Label
    Private WithEvents Label1 As System.Windows.Forms.Label
    Private WithEvents btnLoad As System.Windows.Forms.Button
    Private WithEvents lstOrders As System.Windows.Forms.ListBox
    Private WithEvents lstCustomers As System.Windows.Forms.ListBox

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.lstOrders = New System.Windows.Forms.ListBox()
        Me.btnLoad = New System.Windows.Forms.Button()
        Me.lstCustomers = New System.Windows.Forms.ListBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lstOrders
        '
        Me.lstOrders.ItemHeight = 20
        Me.lstOrders.Location = New System.Drawing.Point(240, 32)
        Me.lstOrders.Name = "lstOrders"
        Me.lstOrders.Size = New System.Drawing.Size(216, 224)
        Me.lstOrders.TabIndex = 2
        '
        'btnLoad
        '
        Me.btnLoad.Location = New System.Drawing.Point(128, 264)
        Me.btnLoad.Name = "btnLoad"
        Me.btnLoad.Size = New System.Drawing.Size(96, 32)
        Me.btnLoad.TabIndex = 0
        Me.btnLoad.Text = "Load"
        '
        'lstCustomers
        '
        Me.lstCustomers.ItemHeight = 20
        Me.lstCustomers.Location = New System.Drawing.Point(8, 32)
        Me.lstCustomers.Name = "lstCustomers"
        Me.lstCustomers.Size = New System.Drawing.Size(216, 224)
        Me.lstCustomers.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(192, 16)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Customers"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(248, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(160, 16)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Orders"
        '
        'frmMultiple
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(466, 308)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label2, Me.Label1, Me.btnLoad, Me.lstOrders, Me.lstCustomers})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "frmMultiple"
        Me.Text = "Set DataSet Relationships"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub DataSetCreate()
        Dim daCust As OleDb.OleDbDataAdapter
        Dim daOrders As OleDb.OleDbDataAdapter
        Dim dr As DataRelation
        Dim dcCust As DataColumn
        Dim dcOrders As DataColumn
        Dim strSQLCust As String
        Dim strSQLOrders As String
        Dim strConn As String

        strConn = "Provider=sqloledb;"
        strConn &= "Data Source=(local);"
        strConn &= "Initial Catalog=Northwind;"
        strConn &= "User ID=sa"

        strSQLCust = "SELECT CustomerID, CompanyName, "
        strSQLCust &= "ContactName FROM Customers"

        strSQLOrders = "SELECT CustomerID, OrderID, "
        strSQLOrders &= "OrderDate FROM Orders"

        daCust = New _
         OleDb.OleDbDataAdapter(strSQLCust, strConn)
        daOrders = New _
         OleDb.OleDbDataAdapter(strSQLOrders, strConn)
        Try
            daCust.Fill(mds, "Customers")
            daOrders.Fill(mds, "Orders")

            ' Get the PK & FK Columns
            dcCust = mds.Tables("Customers").Columns("CustomerID")
            dcOrders = mds.Tables("Orders").Columns("CustomerID")

            ' Create the Data Relation Between the Two Tables
            dr = New DataRelation("CustOrders", _
                 dcCust, _
                 dcOrders)

            ' Add the relation
            mds.Relations.Add(dr)
            ' Set the Customers Primary Key Field
            mds.Tables("Customers").PrimaryKey = _
             New DataColumn() {dcCust}
            ' Set the Orders Primary Key Field
            With mds.Tables("Orders")
                .PrimaryKey = _
                 New DataColumn() {.Columns("OrderID")}
            End With

        Catch oExcept As Exception
            MessageBox.Show(oExcept.Message.ToString)

        End Try

    End Sub

    Private Sub btnLoad_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnLoad.Click
        Dim dr As DataRow

        Call DataSetCreate()

        For Each dr In mds.Tables("Customers").Rows
            lstCustomers.Items.Add(dr.Item("CustomerID"))
        Next
    End Sub

    Private Sub lstCustomers_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstCustomers.SelectedIndexChanged
        Dim daCust As DataRow
        Dim dr As DataRow

        ' Find the Row in the Customer Table
        daCust = mds.Tables("Customers").Rows.Find(lstCustomers.Text)

        lstOrders.Items.Clear()
        For Each dr In daCust.GetChildRows("CustOrders")
            lstOrders.Items.Add(dr.Item("OrderDate"))
        Next

    End Sub
End Class
