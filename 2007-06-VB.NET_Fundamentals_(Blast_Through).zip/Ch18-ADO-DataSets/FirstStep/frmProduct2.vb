Public Class frmProduct
    Inherits System.Windows.Forms.Form

    Private moDS As DataSet

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Win Form Designer.
        InitializeComponent()
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If Disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub

    Private WithEvents Label8 As System.Windows.Forms.Label
    Private WithEvents txtReorder As System.Windows.Forms.TextBox
    Private WithEvents Label7 As System.Windows.Forms.Label
    Private WithEvents txtOnOrder As System.Windows.Forms.TextBox
    Private WithEvents Label6 As System.Windows.Forms.Label
    Private WithEvents txtInStock As System.Windows.Forms.TextBox
    Private WithEvents Label5 As System.Windows.Forms.Label
    Private WithEvents Label4 As System.Windows.Forms.Label
    Private WithEvents cboCategory As System.Windows.Forms.ComboBox
    Private WithEvents cboSupplier As System.Windows.Forms.ComboBox
    Private WithEvents btnClear As System.Windows.Forms.Button
    Private WithEvents btnDelete As System.Windows.Forms.Button
    Private WithEvents btnUpdate As System.Windows.Forms.Button
    Private WithEvents txtID As System.Windows.Forms.TextBox
    Private WithEvents Label3 As System.Windows.Forms.Label
    Private WithEvents chkDisc As System.Windows.Forms.CheckBox
    Private WithEvents txtPrice As System.Windows.Forms.TextBox
    Private WithEvents Label2 As System.Windows.Forms.Label
    Private WithEvents txtQty As System.Windows.Forms.TextBox
    Private WithEvents Label1 As System.Windows.Forms.Label
    Private WithEvents txtName As System.Windows.Forms.TextBox
    Private WithEvents lblFirst As System.Windows.Forms.Label
    Private WithEvents lstProducts As System.Windows.Forms.ListBox
    Private WithEvents btnAdd As System.Windows.Forms.Button

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.chkDisc = New System.Windows.Forms.CheckBox()
        Me.txtOnOrder = New System.Windows.Forms.TextBox()
        Me.txtPrice = New System.Windows.Forms.TextBox()
        Me.cboSupplier = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtReorder = New System.Windows.Forms.TextBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtQty = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblFirst = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cboCategory = New System.Windows.Forms.ComboBox()
        Me.lstProducts = New System.Windows.Forms.ListBox()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.txtInStock = New System.Windows.Forms.TextBox()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(216, 400)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(120, 48)
        Me.btnUpdate.TabIndex = 21
        Me.btnUpdate.Text = "Update"
        '
        'chkDisc
        '
        Me.chkDisc.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkDisc.Location = New System.Drawing.Point(264, 368)
        Me.chkDisc.Name = "chkDisc"
        Me.chkDisc.Size = New System.Drawing.Size(144, 16)
        Me.chkDisc.TabIndex = 19
        Me.chkDisc.Text = "Discontinued"
        '
        'txtOnOrder
        '
        Me.txtOnOrder.Location = New System.Drawing.Point(392, 288)
        Me.txtOnOrder.MaxLength = 12
        Me.txtOnOrder.Name = "txtOnOrder"
        Me.txtOnOrder.Size = New System.Drawing.Size(88, 26)
        Me.txtOnOrder.TabIndex = 16
        Me.txtOnOrder.Text = ""
        '
        'txtPrice
        '
        Me.txtPrice.Location = New System.Drawing.Point(392, 208)
        Me.txtPrice.MaxLength = 12
        Me.txtPrice.Name = "txtPrice"
        Me.txtPrice.Size = New System.Drawing.Size(88, 26)
        Me.txtPrice.TabIndex = 12
        Me.txtPrice.Text = ""
        '
        'cboSupplier
        '
        Me.cboSupplier.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSupplier.DropDownWidth = 200
        Me.cboSupplier.Location = New System.Drawing.Point(392, 88)
        Me.cboSupplier.Name = "cboSupplier"
        Me.cboSupplier.Size = New System.Drawing.Size(200, 28)
        Me.cboSupplier.Sorted = True
        Me.cboSupplier.TabIndex = 6
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(264, 328)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(128, 24)
        Me.Label8.TabIndex = 18
        Me.Label8.Text = "Reorder Level"
        '
        'txtReorder
        '
        Me.txtReorder.Location = New System.Drawing.Point(392, 328)
        Me.txtReorder.MaxLength = 12
        Me.txtReorder.Name = "txtReorder"
        Me.txtReorder.Size = New System.Drawing.Size(88, 26)
        Me.txtReorder.TabIndex = 22
        Me.txtReorder.Text = ""
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(392, 48)
        Me.txtName.MaxLength = 20
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(200, 26)
        Me.txtName.TabIndex = 3
        Me.txtName.Text = ""
        '
        'txtQty
        '
        Me.txtQty.Location = New System.Drawing.Point(392, 168)
        Me.txtQty.MaxLength = 40
        Me.txtQty.Name = "txtQty"
        Me.txtQty.Size = New System.Drawing.Size(200, 26)
        Me.txtQty.TabIndex = 10
        Me.txtQty.Text = ""
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(264, 208)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(112, 24)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Unit Price"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(264, 248)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(112, 24)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Units In Stock"
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(264, 288)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(128, 24)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "Units On Order"
        '
        'btnDelete
        '
        Me.btnDelete.Location = New System.Drawing.Point(344, 400)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(120, 48)
        Me.btnDelete.TabIndex = 22
        Me.btnDelete.Text = "Delete"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(264, 88)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 24)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Suppliers"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(264, 168)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(112, 24)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Qty Per Unit"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(264, 8)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(112, 24)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Product ID"
        '
        'lblFirst
        '
        Me.lblFirst.Location = New System.Drawing.Point(264, 48)
        Me.lblFirst.Name = "lblFirst"
        Me.lblFirst.Size = New System.Drawing.Size(120, 24)
        Me.lblFirst.TabIndex = 4
        Me.lblFirst.Text = "Product Name"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(264, 128)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(112, 24)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Categories"
        '
        'cboCategory
        '
        Me.cboCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCategory.DropDownWidth = 200
        Me.cboCategory.Location = New System.Drawing.Point(392, 128)
        Me.cboCategory.Name = "cboCategory"
        Me.cboCategory.Size = New System.Drawing.Size(200, 28)
        Me.cboCategory.TabIndex = 8
        '
        'lstProducts
        '
        Me.lstProducts.ItemHeight = 20
        Me.lstProducts.Location = New System.Drawing.Point(8, 8)
        Me.lstProducts.Name = "lstProducts"
        Me.lstProducts.Size = New System.Drawing.Size(248, 384)
        Me.lstProducts.Sorted = True
        Me.lstProducts.TabIndex = 0
        '
        'txtID
        '
        Me.txtID.Location = New System.Drawing.Point(392, 8)
        Me.txtID.MaxLength = 20
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(64, 26)
        Me.txtID.TabIndex = 2
        Me.txtID.Text = ""
        '
        'txtInStock
        '
        Me.txtInStock.Location = New System.Drawing.Point(392, 248)
        Me.txtInStock.MaxLength = 12
        Me.txtInStock.Name = "txtInStock"
        Me.txtInStock.Size = New System.Drawing.Size(88, 26)
        Me.txtInStock.TabIndex = 14
        Me.txtInStock.Text = ""
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(472, 400)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(120, 48)
        Me.btnClear.TabIndex = 23
        Me.btnClear.Text = "Clear"
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(88, 400)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(120, 48)
        Me.btnAdd.TabIndex = 20
        Me.btnAdd.Text = "Add"
        '
        'frmProduct
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(600, 458)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label8, Me.txtReorder, Me.Label7, Me.txtOnOrder, Me.Label6, Me.txtInStock, Me.Label5, Me.Label4, Me.cboCategory, Me.cboSupplier, Me.btnClear, Me.btnDelete, Me.btnUpdate, Me.txtID, Me.Label3, Me.chkDisc, Me.txtPrice, Me.Label2, Me.txtQty, Me.Label1, Me.txtName, Me.lblFirst, Me.lstProducts, Me.btnAdd})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold)
        Me.Name = "frmProduct"
        Me.Text = "Product Information"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub SupplierLoad()
        Dim oAdapter As OleDb.OleDbDataAdapter
        Dim oTable As DataTable = New DataTable()
        Dim oItem As PDSAListItemNumeric
        Dim strSQL As String
        Dim strConn As String
        Dim intLoop As Integer

        strConn = ConnectStringBuild()

        strSQL = "SELECT SupplierID, CompanyName "
        strSQL &= "FROM Suppliers"

        Try
            oAdapter = New OleDb.OleDbDataAdapter(strSQL, strConn)
            oAdapter.Fill(oTable)

            For intLoop = 0 To oTable.Rows.Count - 1
                oItem = New PDSAListItemNumeric()
                With oTable.Rows(intLoop)
                    oItem.Value = .Item("CompanyName").ToString()
                    oItem.ID = CInt(.Item("SupplierID"))
                End With

                cboSupplier.Items.Add(oItem)
            Next

        Catch oExcept As Exception
            MessageBox.Show(oExcept.Message)

        End Try
    End Sub

    Private Sub CategoryLoad()
        Dim oAdapter As OleDb.OleDbDataAdapter
        Dim oTable As DataTable = New DataTable()
        Dim oItem As PDSAListItemNumeric
        Dim strSQL As String
        Dim strConn As String
        Dim intLoop As Integer

        strConn = ConnectStringBuild()

        strSQL = "SELECT CategoryID, CategoryName "
        strSQL &= "FROM Categories"

        Try
            oAdapter = New OleDb.OleDbDataAdapter(strSQL, strConn)
            oAdapter.Fill(oTable)

            For intLoop = 0 To oTable.Rows.Count - 1
                oItem = New PDSAListItemNumeric()
                With oTable.Rows(intLoop)
                    oItem.Value = .Item("CategoryName").ToString()
                    oItem.ID = CInt(.Item("CategoryID"))
                End With

                cboCategory.Items.Add(oItem)
            Next

        Catch oExcept As Exception
            MessageBox.Show(oExcept.Message)

        End Try
    End Sub

    Private Sub DataAdd()
        Dim oAdapter As OleDb.OleDbDataAdapter
        Dim oBuild As OleDb.OleDbCommandBuilder
        Dim oDR As DataRow
        Dim strSQL As String
        Dim strConn As String

        ' Create New DataRow Object From DataSet
        oDR = moDS.Tables("Products").NewRow()
        ' Tell Data Row new data is coming in
        oDR.BeginEdit()

        ' Load new data into row
        oDR("ProductName") = txtName.Text
        oDR("SupplierID") = _
         CType(cboSupplier.SelectedItem, _
         PDSAListItemNumeric).ID
        oDR("CategoryID") = _
         CType(cboCategory.SelectedItem, _
         PDSAListItemNumeric).ID
        oDR("QuantityPerUnit") = txtQty.Text
        oDR("UnitPrice") = CDec(txtPrice.Text)
        oDR("UnitsInStock") = CShort(txtInStock.Text)
        oDR("UnitsOnOrder") = CShort(txtOnOrder.Text)
        oDR("ReorderLevel") = CShort(txtReorder.Text)
        oDR("Discontinued") = CBool(chkDisc.Checked)

        ' Tell DataRow you are done adding data
        oDR.EndEdit()
        ' Add DataRow to DataSet
        moDS.Tables("Products").Rows.Add(oDR)

        Try
            ' Get Connection String
            strConn = ConnectStringBuild()

            ' Build SQL String
            strSQL = "SELECT * FROM Products "
            ' Create New DataAdapter
            oAdapter = New OleDb.OleDbDataAdapter(strSQL, strConn)
            ' Create CommandBuild from Adapter
            ' This will build INSERT, UPDATE and DELETE SQL
            oBuild = New OleDb.OleDbCommandBuilder(oAdapter)

            ' Get Insert Command Object
            oAdapter.InsertCommand = oBuild.GetInsertCommand()

            ' Submit INSERT statement through Adapter
            oAdapter.Update(moDS, "Products")
            ' Tell DataSet changes to data source are complete
            moDS.AcceptChanges()
            ' Close the Connection
            oAdapter.InsertCommand.Connection.Close()

            ' Recreate the DataSet
            DataSetCreate()
            ' Reload the list box
            ListLoad()
        Catch oException As Exception
            MessageBox.Show(oException.Message)

        End Try
    End Sub

    Private Sub DataUpdate()
        Dim oAdapter As OleDb.OleDbDataAdapter
        Dim oBuild As OleDb.OleDbCommandBuilder
        Dim oDR As DataRow
        Dim strSQL As String
        Dim intID As Integer
        Dim strConn As String

        ' Get Primary Key From List Box
        intID = CType(lstProducts.SelectedItem, _
         PDSAListItemNumeric).ID

        ' Find Row To Update
        oDR = moDS.Tables("Products").Rows.Find(intID)

        ' Begin the editing process
        oDR.BeginEdit()

        ' Load new data into row
        oDR("ProductName") = txtName.Text
        oDR("SupplierID") = CType(cboSupplier.SelectedItem, _
         PDSAListItemNumeric).ID
        oDR("CategoryID") = CType(cboCategory.SelectedItem, _
         PDSAListItemNumeric).ID
        oDR("QuantityPerUnit") = txtQty.Text
        oDR("UnitPrice") = CDec(txtPrice.Text)
        oDR("UnitsInStock") = CShort(txtInStock.Text)
        oDR("UnitsOnOrder") = CShort(txtOnOrder.Text)
        oDR("ReorderLevel") = CShort(txtReorder.Text)
        oDR("Discontinued") = CBool(chkDisc.Checked)

        ' End the editing process
        oDR.EndEdit()

        Try
            ' Get Connection String
            strConn = ConnectStringBuild()
            ' Build SQL String
            strSQL = "SELECT * FROM Products "
            ' Create New DataAdapter
            oAdapter = New OleDb.OleDbDataAdapter(strSQL, strConn)
            ' Create CommandBuild from Adapter
            ' This will build INSERT, UPDATE and DELETE SQL
            oBuild = New OleDb.OleDbCommandBuilder(oAdapter)

            ' Get Update Command Object
            oAdapter.UpdateCommand = oBuild.GetUpdateCommand()

            ' Submit UPDATE through Adapter
            oAdapter.Update(moDS, "Products")
            ' Tell DataSet changes to data source are complete
            moDS.AcceptChanges()
            ' Close the Connection
            oAdapter.UpdateCommand.Connection.Close()

            ' Reload the list box
            ListLoad()

        Catch oException As Exception
            MessageBox.Show(oException.Message)

        End Try
    End Sub

    Private Sub DataDelete()
        Dim oAdapter As OleDb.OleDbDataAdapter
        Dim oBuild As OleDb.OleDbCommandBuilder
        Dim oDR As DataRow
        Dim strSQL As String
        Dim strConn As String
        Dim intID As Integer

        ' Get Connection String
        strConn = ConnectStringBuild()

        ' Get Primary Key From List Box
        intID = CType(lstProducts.SelectedItem, _
         PDSAListItemNumeric).ID

        ' Find DataRow To Delete
        oDR = moDS.Tables("Products").Rows.Find(intID)
        ' Mark DataRow for deletion
        oDR.Delete()

        Try
            ' Build SQL String
            strSQL = "SELECT * FROM Products "
            ' Create New DataAdapter
            oAdapter = New _
             OleDb.OleDbDataAdapter(strSQL, strConn)
            ' Create CommandBuild from Adapter
            ' This will build INSERT, UPDATE and DELETE SQL
            oBuild = New OleDb.OleDbCommandBuilder(oAdapter)

            ' Get Delete Command Object
            oAdapter.DeleteCommand = oBuild.GetDeleteCommand()

            ' Submit DELETE through Adapter
            oAdapter.Update(moDS, "Products")
            ' Tell DataSet changes to data source are complete
            moDS.AcceptChanges()
            ' Close the Connection
            oAdapter.DeleteCommand.Connection.Close()

            ' Reload the list box
            ListLoad()
        Catch oException As Exception
            MessageBox.Show(oException.Message)

        End Try
    End Sub

    Private Sub FormShow()
        Dim oDR As DataRow
        Dim oItem As PDSAListItemNumeric
        Dim strID As String

        ' Get Primary Key From List Box
        oItem = CType(lstProducts.SelectedItem, _
         PDSAListItemNumeric)

        ' Find row in DataSet
        With moDS.Tables("Products").Rows
            oDR = .Find(oItem.ID)
        End With

        ' Display the Data
        txtID.Text = oDR("ProductID").ToString()
        txtName.Text = oDR("ProductName").ToString()
        strID = oDR("SupplierID").ToString()
        Call FindItem(cboSupplier, strID)
        strID = oDR("CategoryID").ToString()
        Call FindItem(cboCategory, strID)
        txtQty.Text = oDR("QuantityPerUnit").ToString()
        txtPrice.Text = oDR("UnitPrice").ToString()
        txtInStock.Text = oDR("UnitsInStock").ToString()
        txtOnOrder.Text = oDR("UnitsOnOrder").ToString()
        txtReorder.Text = oDR("ReorderLevel").ToString()
        chkDisc.Checked = CType(oDR("Discontinued"), Boolean)

    End Sub

    Private Sub DataSetCreate()
        Dim oAdapter As OleDb.OleDbDataAdapter
        Dim strSQL As String
        Dim strConn As String

        ' Get Connection String
        strConn = ConnectStringBuild()

        ' Build SQL String
        strSQL = "SELECT * "
        strSQL &= "FROM Products"

        moDS = New DataSet()
        Try
            ' Create New Data Adapter
            oAdapter = New OleDb.OleDbDataAdapter(strSQL, strConn)
            ' Fill DataSet From Adapter and give it a name
            oAdapter.Fill(moDS, "Products")
            ' Create a Primary Key
            With moDS.Tables("Products")
                .PrimaryKey = New DataColumn() _
                 {.Columns("ProductID")}
            End With

        Catch oExcept As Exception
            MessageBox.Show(oExcept.Message)

        End Try
    End Sub

    Private Sub ListLoad()
        Dim oItem As PDSAListItemNumeric
        Dim oRow As DataRow

        lstProducts.Items.Clear()
        ' Loop through each row and get a DataRow
        For Each oRow In moDS.Tables("Products").Rows
            ' Create New Item to hold PK and Description
            oItem = New PDSAListItemNumeric()
            With oItem
                .ID = CInt(oRow.Item("ProductID"))
                .Value = oRow.Item("ProductName").ToString()
            End With

            ' Add Item to list box
            lstProducts.Items.Add(oItem)
        Next

        lstProducts.SetSelected(0, True)
    End Sub

    Private Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        DataAdd()
    End Sub

    Private Sub btnClear_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtID.Text = ""
        txtName.Text = ""
        cboSupplier.SelectedIndex = -1
        cboCategory.SelectedIndex = -1
        txtQty.Text = ""
        txtPrice.Text = "0"
        txtInStock.Text = "0"
        txtOnOrder.Text = "0"
        txtReorder.Text = "0"
        chkDisc.Checked = False
    End Sub

    Private Sub btnDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        DataDelete()
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        DataUpdate()
    End Sub

    Private Sub lstProducts_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstProducts.SelectedIndexChanged
        FormShow()
    End Sub

    Private Sub frmProduct_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Load Suppliers
        SupplierLoad()
        ' Load Categories
        CategoryLoad()

        ' Initialize the DataSet
        DataSetCreate()
        ' Load List Box of Products
        ListLoad()
    End Sub

    Private Sub FindItem(ByVal cboCombo As ComboBox, _
     ByVal strID As String)
        Dim intLoop As Integer
        Dim boolFound As Boolean
        Dim oItem As PDSAListItemNumeric

        oItem = New PDSAListItemNumeric()
        For intLoop = 0 To cboCombo.Items.Count - 1
            oItem = CType(cboCombo.Items(intLoop), PDSAListItemNumeric)
            If oItem.ID = CInt(strID) Then
                cboCombo.SelectedIndex = intLoop
                boolFound = True
                Exit For
            End If
        Next
        If Not boolFound Then
            cboCombo.SelectedIndex = -1
        End If
    End Sub

    Private Function ConnectStringBuild() As String
        Dim strConn As String

        strConn = "Provider=sqloledb;"
        strConn &= "Data Source=(local);"
        strConn &= "Initial Catalog=Northwind;"
        strConn &= "User ID=sa"

        Return strConn
    End Function
End Class
