Public Class frmMain
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()
        
        'This call is required by the Win Form Designer.
        InitializeComponent()
        
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    
    Private WithEvents cmdEdit As System.Windows.Forms.Button
    Private WithEvents btnMultiple As System.Windows.Forms.Button
    Private WithEvents btnDS As System.Windows.Forms.Button
        
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cmdEdit = New System.Windows.Forms.Button()
        Me.btnMultiple = New System.Windows.Forms.Button()
        Me.btnDS = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'cmdEdit
        '
        Me.cmdEdit.Location = New System.Drawing.Point(8, 8)
        Me.cmdEdit.Name = "cmdEdit"
        Me.cmdEdit.Size = New System.Drawing.Size(128, 48)
        Me.cmdEdit.TabIndex = 0
        Me.cmdEdit.Text = "Products"
        '
        'btnMultiple
        '
        Me.btnMultiple.Location = New System.Drawing.Point(280, 8)
        Me.btnMultiple.Name = "btnMultiple"
        Me.btnMultiple.Size = New System.Drawing.Size(128, 48)
        Me.btnMultiple.TabIndex = 2
        Me.btnMultiple.Text = "DataTables in DataSet"
        '
        'btnDS
        '
        Me.btnDS.Location = New System.Drawing.Point(144, 8)
        Me.btnDS.Name = "btnDS"
        Me.btnDS.Size = New System.Drawing.Size(128, 48)
        Me.btnDS.TabIndex = 1
        Me.btnDS.Text = "Data Set"
        '
        'frmMain
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(418, 68)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdEdit, Me.btnMultiple, Me.btnDS})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Data Set Examples"
        Me.ResumeLayout(False)

    End Sub

#End Region
    
    Private Sub cmdEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEdit.Click
        Dim frm As frmProduct

        frm = New frmProduct()

        frm.Show()
    End Sub

    Private Sub btnMultiple_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnMultiple.Click
        Dim frm As frmMultiple

        frm = New frmMultiple()

        frm.Show()
    End Sub

    Private Sub btnDS_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDS.Click
        Dim frm As frmDataSet

        frm = New frmDataSet()

        frm.Show()
    End Sub

End Class
