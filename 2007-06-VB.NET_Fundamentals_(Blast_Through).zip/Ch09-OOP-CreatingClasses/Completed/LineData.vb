Public Class LineData
    Private mstrText As String

    Public Sub New(ByVal Text As String)
        mstrText = Text
    End Sub

    Public Function GetWord() As String
        Dim astrWords() As String

        astrWords = Split(mstrText, " ")

        Return astrWords(0)
    End Function

    Public Property Text() As String
        Get
            Return mstrText
        End Get
        Set(ByVal Value As String)
            mstrText = Value
        End Set
    End Property

    Public ReadOnly Property Length() As Integer
        Get
            Return mstrText.Length
        End Get
    End Property
End Class

