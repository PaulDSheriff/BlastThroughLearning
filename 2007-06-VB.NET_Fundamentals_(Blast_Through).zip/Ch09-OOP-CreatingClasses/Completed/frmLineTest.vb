Public Class frmLineTest
    Inherits Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    Private WithEvents btnGetWord As System.Windows.Forms.Button
    Private WithEvents txtLength As System.Windows.Forms.TextBox
    Private WithEvents txtWord As System.Windows.Forms.TextBox
    Private WithEvents btnDisplay As System.Windows.Forms.Button
    Private WithEvents txtLine As System.Windows.Forms.TextBox
    Private WithEvents Label2 As System.Windows.Forms.Label

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThroughAttribute()> Private Sub InitializeComponent()
        Me.txtLength = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtWord = New System.Windows.Forms.TextBox()
        Me.btnDisplay = New System.Windows.Forms.Button()
        Me.txtLine = New System.Windows.Forms.TextBox()
        Me.btnGetWord = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtLength
        '
        Me.txtLength.Location = New System.Drawing.Point(152, 50)
        Me.txtLength.Name = "txtLength"
        Me.txtLength.ReadOnly = True
        Me.txtLength.Size = New System.Drawing.Size(48, 26)
        Me.txtLength.TabIndex = 17
        Me.txtLength.Text = ""
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(128, 24)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Line of Text"
        '
        'txtWord
        '
        Me.txtWord.Location = New System.Drawing.Point(152, 98)
        Me.txtWord.Name = "txtWord"
        Me.txtWord.ReadOnly = True
        Me.txtWord.Size = New System.Drawing.Size(120, 26)
        Me.txtWord.TabIndex = 16
        Me.txtWord.Text = ""
        '
        'btnDisplay
        '
        Me.btnDisplay.Location = New System.Drawing.Point(8, 48)
        Me.btnDisplay.Name = "btnDisplay"
        Me.btnDisplay.Size = New System.Drawing.Size(136, 32)
        Me.btnDisplay.TabIndex = 10
        Me.btnDisplay.Text = "Display Length"
        '
        'txtLine
        '
        Me.txtLine.Location = New System.Drawing.Point(152, 8)
        Me.txtLine.Name = "txtLine"
        Me.txtLine.Size = New System.Drawing.Size(344, 26)
        Me.txtLine.TabIndex = 3
        Me.txtLine.Text = "The rain in Spain stays mainly in the plain"
        '
        'btnGetWord
        '
        Me.btnGetWord.Location = New System.Drawing.Point(8, 96)
        Me.btnGetWord.Name = "btnGetWord"
        Me.btnGetWord.Size = New System.Drawing.Size(136, 32)
        Me.btnGetWord.TabIndex = 22
        Me.btnGetWord.Text = "Get Word"
        '
        'frmLineTest
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(504, 146)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnGetWord, Me.txtLength, Me.txtWord, Me.btnDisplay, Me.txtLine, Me.Label2})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Name = "frmLineTest"
        Me.Text = "Line Class Test"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnDisplay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDisplay.Click
        Dim oLine As New LineData(Me.txtLine.Text)

        Me.txtLength.Text = CType(oLine.Length, String)
    End Sub

    Private Sub btnGetWord_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetWord.Click
        Dim oLine As New LineData("")

        oLine.Text = Me.txtLine.Text

        Me.txtWord.Text = oLine.GetWord()
    End Sub
End Class
