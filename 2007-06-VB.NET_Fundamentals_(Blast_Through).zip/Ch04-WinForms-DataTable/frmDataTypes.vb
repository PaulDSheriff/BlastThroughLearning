Public Class frmDataTypes
    Inherits System.Windows.Forms.Form

    Private mdt As DataTable

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtUnitPrice As System.Windows.Forms.TextBox
    Friend WithEvents txtProductID As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents grdProducts As System.Windows.Forms.DataGrid
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtProductName As System.Windows.Forms.TextBox
    Friend WithEvents txtUnitsInStock As System.Windows.Forms.TextBox

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.txtProductName = New System.Windows.Forms.TextBox()
        Me.txtUnitPrice = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.grdProducts = New System.Windows.Forms.DataGrid()
        Me.txtUnitsInStock = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtProductID = New System.Windows.Forms.TextBox()
        CType(Me.grdProducts, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtProductName
        '
        Me.txtProductName.Location = New System.Drawing.Point(152, 232)
        Me.txtProductName.Name = "txtProductName"
        Me.txtProductName.Size = New System.Drawing.Size(176, 26)
        Me.txtProductName.TabIndex = 2
        Me.txtProductName.Text = ""
        '
        'txtUnitPrice
        '
        Me.txtUnitPrice.Location = New System.Drawing.Point(152, 264)
        Me.txtUnitPrice.Name = "txtUnitPrice"
        Me.txtUnitPrice.Size = New System.Drawing.Size(176, 26)
        Me.txtUnitPrice.TabIndex = 3
        Me.txtUnitPrice.Text = ""
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(8, 296)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(136, 24)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Units In Stock"
        '
        'grdProducts
        '
        Me.grdProducts.DataMember = ""
        Me.grdProducts.Location = New System.Drawing.Point(8, 8)
        Me.grdProducts.Name = "grdProducts"
        Me.grdProducts.Size = New System.Drawing.Size(320, 176)
        Me.grdProducts.TabIndex = 9
        '
        'txtUnitsInStock
        '
        Me.txtUnitsInStock.Location = New System.Drawing.Point(152, 296)
        Me.txtUnitsInStock.Name = "txtUnitsInStock"
        Me.txtUnitsInStock.Size = New System.Drawing.Size(176, 26)
        Me.txtUnitsInStock.TabIndex = 7
        Me.txtUnitsInStock.Text = ""
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 200)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(128, 24)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Product ID"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 232)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(128, 24)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Product Name"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(8, 264)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(112, 24)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Unit Price"
        '
        'txtProductID
        '
        Me.txtProductID.Location = New System.Drawing.Point(152, 200)
        Me.txtProductID.Name = "txtProductID"
        Me.txtProductID.Size = New System.Drawing.Size(176, 26)
        Me.txtProductID.TabIndex = 1
        Me.txtProductID.Text = ""
        '
        'frmDataTypes
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(336, 322)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label1, Me.Label2, Me.txtUnitPrice, Me.txtProductID, Me.Label3, Me.grdProducts, Me.Label4, Me.txtProductName, Me.txtUnitsInStock})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmDataTypes"
        Me.Text = "frmDataTypes"
        CType(Me.grdProducts, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub frmDataTypes_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call GridLoad()
    End Sub

    Private Sub GridLoad()
        Dim dr As DataRow
        Dim dc As DataColumn
        Dim intLoop As Integer

        Me.Cursor = Cursors.WaitCursor

        ' Create New DataTable object
        mdt = New DataTable()

        ' Create ProductID DataColumn object
        dc = New DataColumn("ProductID")
        dc.AutoIncrement = True
        dc.AutoIncrementSeed = 1
        dc.AutoIncrementStep = 1
        dc.Caption = "Product ID"
        dc.DataType = _
            System.Type.GetType("System.Int32")
        mdt.Columns.Add(dc)

        ' Create ProductName DataColumn object
        dc = New DataColumn("ProductName")
        dc.DataType = _
            System.Type.GetType("System.String")
        dc.Caption = "Product Name"
        mdt.Columns.Add(dc)

        ' Create UnitPrice DataColumn object
        dc = New DataColumn("UnitPrice")
        dc.DataType = _
            System.Type.GetType("System.Decimal")
        dc.Caption = "Unit Price $"
        mdt.Columns.Add(dc)

        ' Create UnitsInStock DataColumn object
        dc = New DataColumn("UnitsInStock")
        dc.DataType = _
            System.Type.GetType("System.Decimal")
        dc.Caption = "Units in Stock"
        mdt.Columns.Add(dc)

        ' Create StockCost DataColumn object
        ' Expression calculates the cost from other columns
        dc = New DataColumn("StockCost")
        dc.DataType = System.Type.GetType("System.Decimal")
        dc.Caption = "Cost of Stock"
        dc.Expression = "UnitsInStock*UnitPrice"
        mdt.Columns.Add(dc)

        ' Load data into DataTable
        For intLoop = 1 To 10
            ' Create a New Row
            dr = mdt.NewRow

            ' Load columns in new row with Data
            dr("ProductName") = "Product " & _
                intLoop.ToString()
            dr("UnitPrice") = intLoop * 10
            dr("UnitsInStock") = intLoop * 20

            ' Add New Row to DataTable
            mdt.Rows.Add(dr)
        Next

        ' Load Grid with Data
        grdProducts.DataSource = mdt

        Me.Cursor = Cursors.Default

    End Sub

    Private Sub grdProducts_Click(ByVal sender As Object, _
     ByVal e As System.EventArgs) Handles grdProducts.Click
        Dim dr As DataRow
        Dim intRow As Integer

        ' Get current row number
        intRow = grdProducts.CurrentCell.RowNumber
        ' Get DataRow from DataTable
        dr = mdt.Rows(intRow)

        txtProductID.Text = dr("ProductID").ToString
        txtProductName.Text = dr("ProductName").ToString
        txtUnitPrice.Text = dr("UnitPrice").ToString
        txtUnitsInStock.Text = dr("UnitsInStock").ToString
    End Sub
End Class
