Public Class PDSAListItemString
    Private mstrValue As String
    Private mstrID As String
    
    Public Sub New()

    End Sub

    Public Sub New(ByVal strValue As String, ByVal strID As String)
        mstrValue = strValue
        mstrID = strID
    End Sub

    Property Value() As String
        Get
            Return mstrValue
        End Get
        Set(ByVal Value As String)
            mstrValue = Value
        End Set
    End Property

    Property ID() As String
        Get
            Return mstrID
        End Get
        Set(ByVal Value As String)
            mstrID = Value
        End Set
    End Property

    Public Overrides Function ToString() As String
        Return mstrValue
    End Function
End Class

Public Class PDSAListItemNumeric
    Private mstrValue As String
    Private mintID As Integer
    
    Public Sub New()

    End Sub

    Public Sub New(ByVal strValue As String, _
     ByVal intID As Integer)
        mstrValue = strValue
        mintID = intID
    End Sub

    Property Value() As String
        Get
            Return mstrValue
        End Get
        Set(ByVal Value As String)
            mstrValue = Value
        End Set
    End Property

    Property ID() As Integer
        Get
            Return mintID
        End Get
        Set(ByVal Value As Integer)
            mintID = Value
        End Set
    End Property

    Public Overrides Function ToString() As String
        Return mstrValue
    End Function
End Class
