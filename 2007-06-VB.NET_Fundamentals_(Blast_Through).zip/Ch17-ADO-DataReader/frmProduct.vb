Public Class frmProduct
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Win Form Designer.
    InitializeComponent()

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub

  Private WithEvents Label8 As System.Windows.Forms.Label
  Private WithEvents txtReorder As System.Windows.Forms.TextBox
  Private WithEvents Label7 As System.Windows.Forms.Label
  Private WithEvents txtOnOrder As System.Windows.Forms.TextBox
  Private WithEvents Label6 As System.Windows.Forms.Label
  Private WithEvents txtInStock As System.Windows.Forms.TextBox
  Private WithEvents Label5 As System.Windows.Forms.Label
  Private WithEvents Label4 As System.Windows.Forms.Label
  Private WithEvents cboCategory As System.Windows.Forms.ComboBox
  Private WithEvents cboSupplier As System.Windows.Forms.ComboBox
  Private WithEvents btnClear As System.Windows.Forms.Button
  Private WithEvents btnDelete As System.Windows.Forms.Button
  Private WithEvents btnUpdate As System.Windows.Forms.Button
  Private WithEvents txtID As System.Windows.Forms.TextBox
  Private WithEvents Label3 As System.Windows.Forms.Label
  Private WithEvents chkDisc As System.Windows.Forms.CheckBox
  Private WithEvents txtPrice As System.Windows.Forms.TextBox
  Private WithEvents Label2 As System.Windows.Forms.Label
  Private WithEvents txtQty As System.Windows.Forms.TextBox
  Private WithEvents Label1 As System.Windows.Forms.Label
  Private WithEvents txtName As System.Windows.Forms.TextBox
  Private WithEvents lblFirst As System.Windows.Forms.Label
  Private WithEvents lstProducts As System.Windows.Forms.ListBox
  Private WithEvents btnAdd As System.Windows.Forms.Button

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.btnUpdate = New System.Windows.Forms.Button()
    Me.txtOnOrder = New System.Windows.Forms.TextBox()
    Me.txtPrice = New System.Windows.Forms.TextBox()
    Me.cboSupplier = New System.Windows.Forms.ComboBox()
    Me.txtInStock = New System.Windows.Forms.TextBox()
    Me.Label8 = New System.Windows.Forms.Label()
    Me.txtReorder = New System.Windows.Forms.TextBox()
    Me.txtName = New System.Windows.Forms.TextBox()
    Me.txtQty = New System.Windows.Forms.TextBox()
    Me.Label5 = New System.Windows.Forms.Label()
    Me.Label6 = New System.Windows.Forms.Label()
    Me.Label7 = New System.Windows.Forms.Label()
    Me.btnDelete = New System.Windows.Forms.Button()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.Label4 = New System.Windows.Forms.Label()
    Me.Label3 = New System.Windows.Forms.Label()
    Me.lblFirst = New System.Windows.Forms.Label()
    Me.Label2 = New System.Windows.Forms.Label()
    Me.cboCategory = New System.Windows.Forms.ComboBox()
    Me.lstProducts = New System.Windows.Forms.ListBox()
    Me.txtID = New System.Windows.Forms.TextBox()
    Me.chkDisc = New System.Windows.Forms.CheckBox()
    Me.btnClear = New System.Windows.Forms.Button()
    Me.btnAdd = New System.Windows.Forms.Button()
    Me.SuspendLayout()
    '
    'btnUpdate
    '
    Me.btnUpdate.Location = New System.Drawing.Point(216, 400)
    Me.btnUpdate.Name = "btnUpdate"
    Me.btnUpdate.Size = New System.Drawing.Size(120, 48)
    Me.btnUpdate.TabIndex = 20
    Me.btnUpdate.Text = "Update"
    '
    'txtOnOrder
    '
    Me.txtOnOrder.Location = New System.Drawing.Point(392, 288)
    Me.txtOnOrder.MaxLength = 12
    Me.txtOnOrder.Name = "txtOnOrder"
    Me.txtOnOrder.Size = New System.Drawing.Size(88, 26)
    Me.txtOnOrder.TabIndex = 16
    Me.txtOnOrder.Text = ""
    '
    'txtPrice
    '
    Me.txtPrice.Location = New System.Drawing.Point(392, 208)
    Me.txtPrice.MaxLength = 12
    Me.txtPrice.Name = "txtPrice"
    Me.txtPrice.Size = New System.Drawing.Size(88, 26)
    Me.txtPrice.TabIndex = 12
    Me.txtPrice.Text = ""
    '
    'cboSupplier
    '
    Me.cboSupplier.DropDownWidth = 200
    Me.cboSupplier.Location = New System.Drawing.Point(392, 88)
    Me.cboSupplier.Name = "cboSupplier"
    Me.cboSupplier.Size = New System.Drawing.Size(200, 28)
    Me.cboSupplier.Sorted = True
    Me.cboSupplier.TabIndex = 6
    '
    'txtInStock
    '
    Me.txtInStock.Location = New System.Drawing.Point(392, 248)
    Me.txtInStock.MaxLength = 12
    Me.txtInStock.Name = "txtInStock"
    Me.txtInStock.Size = New System.Drawing.Size(88, 26)
    Me.txtInStock.TabIndex = 14
    Me.txtInStock.Text = ""
    '
    'Label8
    '
    Me.Label8.Location = New System.Drawing.Point(264, 328)
    Me.Label8.Name = "Label8"
    Me.Label8.Size = New System.Drawing.Size(128, 24)
    Me.Label8.TabIndex = 18
    Me.Label8.Text = "Reorder Level"
    '
    'txtReorder
    '
    Me.txtReorder.Location = New System.Drawing.Point(392, 328)
    Me.txtReorder.MaxLength = 12
    Me.txtReorder.Name = "txtReorder"
    Me.txtReorder.Size = New System.Drawing.Size(88, 26)
    Me.txtReorder.TabIndex = 17
    Me.txtReorder.Text = ""
    '
    'txtName
    '
    Me.txtName.Location = New System.Drawing.Point(392, 48)
    Me.txtName.MaxLength = 20
    Me.txtName.Name = "txtName"
    Me.txtName.Size = New System.Drawing.Size(200, 26)
    Me.txtName.TabIndex = 3
    Me.txtName.Text = ""
    '
    'txtQty
    '
    Me.txtQty.Location = New System.Drawing.Point(392, 168)
    Me.txtQty.MaxLength = 40
    Me.txtQty.Name = "txtQty"
    Me.txtQty.Size = New System.Drawing.Size(200, 26)
    Me.txtQty.TabIndex = 10
    Me.txtQty.Text = ""
    '
    'Label5
    '
    Me.Label5.Location = New System.Drawing.Point(264, 208)
    Me.Label5.Name = "Label5"
    Me.Label5.Size = New System.Drawing.Size(112, 24)
    Me.Label5.TabIndex = 11
    Me.Label5.Text = "Unit Price"
    '
    'Label6
    '
    Me.Label6.Location = New System.Drawing.Point(264, 248)
    Me.Label6.Name = "Label6"
    Me.Label6.Size = New System.Drawing.Size(112, 24)
    Me.Label6.TabIndex = 13
    Me.Label6.Text = "Units In Stock"
    '
    'Label7
    '
    Me.Label7.Location = New System.Drawing.Point(264, 288)
    Me.Label7.Name = "Label7"
    Me.Label7.Size = New System.Drawing.Size(128, 24)
    Me.Label7.TabIndex = 15
    Me.Label7.Text = "Units On Order"
    '
    'btnDelete
    '
    Me.btnDelete.Location = New System.Drawing.Point(344, 400)
    Me.btnDelete.Name = "btnDelete"
    Me.btnDelete.Size = New System.Drawing.Size(120, 48)
    Me.btnDelete.TabIndex = 21
    Me.btnDelete.Text = "Delete"
    '
    'Label1
    '
    Me.Label1.Location = New System.Drawing.Point(264, 88)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(112, 24)
    Me.Label1.TabIndex = 5
    Me.Label1.Text = "Suppliers"
    '
    'Label4
    '
    Me.Label4.Location = New System.Drawing.Point(264, 168)
    Me.Label4.Name = "Label4"
    Me.Label4.Size = New System.Drawing.Size(112, 24)
    Me.Label4.TabIndex = 9
    Me.Label4.Text = "Qty Per Unit"
    '
    'Label3
    '
    Me.Label3.Location = New System.Drawing.Point(264, 8)
    Me.Label3.Name = "Label3"
    Me.Label3.Size = New System.Drawing.Size(112, 24)
    Me.Label3.TabIndex = 1
    Me.Label3.Text = "Product ID"
    '
    'lblFirst
    '
    Me.lblFirst.Location = New System.Drawing.Point(264, 48)
    Me.lblFirst.Name = "lblFirst"
    Me.lblFirst.Size = New System.Drawing.Size(120, 24)
    Me.lblFirst.TabIndex = 4
    Me.lblFirst.Text = "Product Name"
    '
    'Label2
    '
    Me.Label2.Location = New System.Drawing.Point(264, 128)
    Me.Label2.Name = "Label2"
    Me.Label2.Size = New System.Drawing.Size(112, 24)
    Me.Label2.TabIndex = 7
    Me.Label2.Text = "Categories"
    '
    'cboCategory
    '
    Me.cboCategory.DropDownWidth = 200
    Me.cboCategory.Location = New System.Drawing.Point(392, 128)
    Me.cboCategory.Name = "cboCategory"
    Me.cboCategory.Size = New System.Drawing.Size(200, 28)
    Me.cboCategory.TabIndex = 8
    '
    'lstProducts
    '
    Me.lstProducts.ItemHeight = 20
    Me.lstProducts.Location = New System.Drawing.Point(8, 8)
    Me.lstProducts.Name = "lstProducts"
    Me.lstProducts.Size = New System.Drawing.Size(248, 384)
    Me.lstProducts.Sorted = True
    Me.lstProducts.TabIndex = 0
    '
    'txtID
    '
    Me.txtID.Location = New System.Drawing.Point(392, 8)
    Me.txtID.MaxLength = 20
    Me.txtID.Name = "txtID"
    Me.txtID.Size = New System.Drawing.Size(64, 26)
    Me.txtID.TabIndex = 2
    Me.txtID.Text = ""
    '
    'chkDisc
    '
    Me.chkDisc.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
    Me.chkDisc.Location = New System.Drawing.Point(264, 368)
    Me.chkDisc.Name = "chkDisc"
    Me.chkDisc.Size = New System.Drawing.Size(144, 16)
    Me.chkDisc.TabIndex = 18
    Me.chkDisc.Text = "Discontinued"
    '
    'btnClear
    '
    Me.btnClear.Location = New System.Drawing.Point(472, 400)
    Me.btnClear.Name = "btnClear"
    Me.btnClear.Size = New System.Drawing.Size(120, 48)
    Me.btnClear.TabIndex = 22
    Me.btnClear.Text = "Clear"
    '
    'btnAdd
    '
    Me.btnAdd.Location = New System.Drawing.Point(88, 400)
    Me.btnAdd.Name = "btnAdd"
    Me.btnAdd.Size = New System.Drawing.Size(120, 48)
    Me.btnAdd.TabIndex = 19
    Me.btnAdd.Text = "Add"
    '
    'frmProduct
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
    Me.ClientSize = New System.Drawing.Size(600, 458)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label8, Me.txtReorder, Me.Label7, Me.txtOnOrder, Me.Label6, Me.txtInStock, Me.Label5, Me.Label4, Me.cboCategory, Me.cboSupplier, Me.btnClear, Me.btnDelete, Me.btnUpdate, Me.txtID, Me.Label3, Me.chkDisc, Me.txtPrice, Me.Label2, Me.txtQty, Me.Label1, Me.txtName, Me.lblFirst, Me.lstProducts, Me.btnAdd})
    Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
    Me.Name = "frmProduct"
    Me.Text = "Product Information"
    Me.ResumeLayout(False)

  End Sub

#End Region

  Private Sub SupplierLoad()
    Dim oCmd As OleDb.OleDbCommand
    Dim oDR As OleDb.OleDbDataReader
    Dim oItem As PDSAListItemNumeric
    Dim strSQL As String
    Dim strConn As String

    strConn = ConnectStringBuild()

    strSQL = "SELECT SupplierID, CompanyName "
    strSQL &= "FROM Suppliers"

    Try
      oCmd = New OleDb.OleDbCommand()
      With oCmd
        .Connection = New OleDb.OleDbConnection(strConn)
        .Connection.Open()
        .CommandText = strSQL
        ' Closes connection when closing DataReader object
        oDR = .ExecuteReader(CommandBehavior.CloseConnection)
      End With

      Do While oDR.Read()
        oItem = New PDSAListItemNumeric()
        With oDR
          oItem.Value = .Item("CompanyName").ToString()
          oItem.ID = CType(.Item("SupplierID"), Integer)
        End With

        cboSupplier.Items.Add(oItem)
      Loop
      oDR.Close()
      ' No need to close this because of the 
      ' CommandBehavior.CloseConnection on the ExecuteReader
      'oCmd.Connection.Close()

    Catch oExcept As Exception
      MessageBox.Show(oExcept.Message)

    End Try
  End Sub

  Private Sub CategoryLoad()
    Dim oCmd As OleDb.OleDbCommand
    Dim oDR As OleDb.OleDbDataReader
    Dim strSQL As String
    Dim strConn As String
    Dim oItem As PDSAListItemNumeric

    strConn = ConnectStringBuild()

    strSQL = "SELECT CategoryID, CategoryName "
    strSQL &= "FROM Categories"

    Try
      oCmd = New OleDb.OleDbCommand()
      With oCmd
        .Connection = New OleDb.OleDbConnection(strConn)
        .Connection.Open()
        .CommandText = strSQL
        ' Closes connection when closing DataReader object
        oDR = .ExecuteReader(CommandBehavior.CloseConnection)
      End With

      Do While oDR.Read()
        oItem = New PDSAListItemNumeric()
        With oDR
          oItem.ID = CType(.Item("CategoryID"), Integer)
          oItem.Value = .Item("CategoryName").ToString()
        End With

        cboCategory.Items.Add(oItem)
      Loop
      oDR.Close()
      ' No need to close this because of the 
      ' CommandBehavior.CloseConnection on the ExecuteReader
      'oCmd.Connection.Close()

    Catch oExcept As Exception
      MessageBox.Show(oExcept.Message)

    End Try

  End Sub

  Private Sub ListLoadSimple()
    Dim oCmd As OleDb.OleDbCommand
    Dim oDR As OleDb.OleDbDataReader
    Dim strSQL As String
    Dim strConn As String

    strConn = ConnectStringBuild()

    strSQL = "SELECT ProductName "
    strSQL &= "FROM Products"

    Try
      oCmd = New OleDb.OleDbCommand()
      With oCmd
        .Connection = _
          New OleDb.OleDbConnection(strConn)
        .Connection.Open()
        .CommandText = strSQL
        ' Returns rows/column in sequential order only
        oDR = _
          .ExecuteReader(CommandBehavior.SequentialAccess)
      End With

      lstProducts.Items.Clear()
      Do While oDR.Read()
        Debug.WriteLine(oDR.Item("ProductName"))
        Debug.WriteLine(oDR.Item("ProductID"))
        lstProducts.Items.Add(oDR.Item("ProductName"))
      Loop
      oDR.Close()
      oCmd.Connection.Close()

    Catch oExcept As Exception
      MessageBox.Show(oExcept.Message)

    End Try
  End Sub

  Private Sub ListLoad()
    Dim oCmd As OleDb.OleDbCommand
    Dim oDR As OleDb.OleDbDataReader
    Dim oItem As PDSAListItemNumeric
    Dim strSQL As String
    Dim strConn As String

    strConn = ConnectStringBuild()

    strSQL = "SELECT ProductID, ProductName "
    strSQL &= "FROM Products"

    Try
      oCmd = New OleDb.OleDbCommand()
      With oCmd
        .Connection = _
          New OleDb.OleDbConnection(strConn)
        .Connection.Open()
        .CommandText = strSQL
        ' Returns rows/column in sequential order only
        oDR = .ExecuteReader( _
          CommandBehavior.SequentialAccess)
      End With

      lstProducts.Items.Clear()
      Do While oDR.Read()
        oItem = New PDSAListItemNumeric()
        With oDR
          oItem.ID = CInt(.Item("ProductID"))
          oItem.Value = .Item("ProductName").ToString()
        End With

        lstProducts.Items.Add(oItem)
      Loop
      oDR.Close()
      If lstProducts.Items.Count > 0 Then
        lstProducts.SetSelected(0, True)
      End If
      oCmd.Connection.Close()

    Catch oExcept As Exception
      MessageBox.Show(oExcept.Message)

    End Try
  End Sub

  Private Sub DataAdd()
    Dim strSQL As String
    Dim oCmd As OleDb.OleDbCommand
    Dim intRows As Integer

    strSQL = "INSERT INTO Products("
    strSQL &= "ProductName, "
    strSQL &= "SupplierID,"
    strSQL &= "CategoryID,"
    strSQL &= "QuantityPerUnit,"
    strSQL &= "UnitPrice,"
    strSQL &= "UnitsInStock,"
    strSQL &= "UnitsOnOrder,"
    strSQL &= "ReorderLevel,"
    strSQL &= "Discontinued) VALUES ("
    strSQL &= Str2Field(txtName.Text) & ", "
    strSQL &= CType(cboSupplier.Items(cboSupplier.SelectedIndex), PDSAListItemNumeric).ID & ", "
    strSQL &= CType(cboCategory.Items(cboCategory.SelectedIndex), PDSAListItemNumeric).ID & ", "
    strSQL &= Str2Field(cboSupplier.Text) & ", "
    strSQL &= txtPrice.Text & ", "
    strSQL &= txtInStock.Text & ", "
    strSQL &= txtOnOrder.Text & ", "
    strSQL &= txtReorder.Text & ", "
    strSQL &= CType(IIf(chkDisc.Checked, "1", "0"), String)
    strSQL &= ")"

    Try
      oCmd = New OleDb.OleDbCommand()
      With oCmd
        .Connection = New OleDb.OleDbConnection(ConnectStringBuild())
        .Connection.Open()
        .CommandText = strSQL
        intRows = .ExecuteNonQuery()
        If intRows <> 1 Then
          MessageBox.Show("Did not insert row")
        End If
        .Connection.Close()
      End With

    Catch oException As Exception
      MessageBox.Show(oException.Message)

    End Try
  End Sub

  Private Sub DataUpdate()
    Dim oCmd As OleDb.OleDbCommand
    Dim strSQL As String
    Dim intRows As Integer

    strSQL = "UPDATE Products SET "
    strSQL &= "ProductName = " & Str2Field(txtName.Text) & ", "
    strSQL &= "SupplierID = " & CType(cboSupplier.Items(cboSupplier.SelectedIndex), PDSAListItemNumeric).ID & ", "
    strSQL &= "CategoryID = " & CType(cboCategory.Items(cboCategory.SelectedIndex), PDSAListItemNumeric).ID & ", "
    strSQL &= "QuantityPerUnit = " & Str2Field(cboSupplier.Text) & ", "
    strSQL &= "UnitPrice = " & txtPrice.Text & ", "
    strSQL &= "UnitsInStock = " & txtInStock.Text & ", "
    strSQL &= "UnitsOnOrder = " & txtOnOrder.Text & ", "
    strSQL &= "ReorderLevel = " & txtReorder.Text & ", "
    strSQL &= "Discontinued = " & CType(IIf(chkDisc.Checked, "1", "0"), String)
    strSQL &= " WHERE ProductID =  " & CType(lstProducts.SelectedItem, PDSAListItemNumeric).ID

    Try
      oCmd = New OleDb.OleDbCommand()
      With oCmd
        .Connection = New OleDb.OleDbConnection(ConnectStringBuild())
        .Connection.Open()
        .CommandText = strSQL
        intRows = .ExecuteNonQuery()
        If intRows <> 1 Then
          MessageBox.Show("Did not insert row")
        End If
        .Connection.Close()
      End With

    Catch oException As Exception
      MessageBox.Show(oException.Message)

    End Try
  End Sub

  Private Sub DataDelete()
    Dim oCmd As OleDb.OleDbCommand
    Dim strSQL As String
    Dim intRows As Integer

    strSQL = "DELETE FROM Products "
    strSQL &= " WHERE ProductID =  " & CType(lstProducts.SelectedItem, PDSAListItemNumeric).ID

    oCmd = New OleDb.OleDbCommand()
    With oCmd
      .Connection = New OleDb.OleDbConnection(ConnectStringBuild())
      .Connection.Open()
      .CommandText = strSQL
      intRows = .ExecuteNonQuery()
      If intRows <> 1 Then
        MessageBox.Show("Did not delete")
      End If
      .Connection.Close()
    End With
  End Sub

  Private Sub FormShow()
    Dim oCmd As OleDb.OleDbCommand
    Dim oDR As OleDb.OleDbDataReader
    Dim oItem As PDSAListItemNumeric
    Dim strSQL As String
    Dim strConn As String
    Dim strID As String

    strConn = ConnectStringBuild()

    ' Get Primary Key From List Box
    oItem = CType(lstProducts.SelectedItem, PDSAListItemNumeric)

    strSQL = "SELECT ProductID, ProductName, "
    strSQL &= " SupplierID, CategoryID, "
    strSQL &= " QuantityPerUnit, UnitPrice, "
    strSQL &= " UnitsInStock, UnitsOnOrder, "
    strSQL &= " ReorderLevel, Discontinued "
    strSQL &= " FROM Products "
    strSQL &= " WHERE ProductID = " & oItem.ID

    Try
      oCmd = New OleDb.OleDbCommand()
      With oCmd
        .Connection = New OleDb.OleDbConnection(strConn)
        .Connection.Open()
        .CommandText = strSQL
        ' Use SingleRow to improve performance
        ' Sequential access to column level
        oDR = .ExecuteReader(CommandBehavior.SingleRow)
      End With

      If oDR.Read() Then
        With oDR
          txtID.Text = .Item("ProductID").ToString()
          txtName.Text = .Item("ProductName").ToString()

          ' Code to find data in Combo Boxes
          strID = .Item("SupplierID").ToString()
          Call FindItem(cboSupplier, strID)
          strID = .Item("CategoryID").ToString()
          Call FindItem(cboCategory, strID)

          txtQty.Text = .Item("QuantityPerUnit").ToString()
          txtPrice.Text = .Item("UnitPrice").ToString()
          txtInStock.Text = .Item("UnitsInStock").ToString()
          txtOnOrder.Text = .Item("UnitsOnOrder").ToString()
          txtReorder.Text = .Item("ReorderLevel").ToString()
          chkDisc.Checked = _
            CType(.Item("Discontinued"), Boolean)
        End With
      Else
        DataClear()
      End If
      oDR.Close()
      oCmd.Connection.Close()

    Catch oException As Exception
      MessageBox.Show(oException.Message)

    End Try
  End Sub

  Private Sub DataClear()
    txtID.Text = ""
    txtName.Text = ""
    cboSupplier.SelectedIndex = -1
    cboCategory.SelectedIndex = -1
    txtQty.Text = ""
    txtPrice.Text = "0"
    txtInStock.Text = "0"
    txtOnOrder.Text = "0"
    txtReorder.Text = "0"
    chkDisc.Checked = False
  End Sub

  Private Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
    DataAdd()
    ListLoad()
  End Sub

  Private Sub btnClear_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClear.Click
    DataClear()
  End Sub

  Private Sub btnDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelete.Click
    Dim oResult As DialogResult

    oResult = MessageBox.Show("Delete this record?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
    If oResult = DialogResult.Yes Then
      DataDelete()
      ListLoad()
    End If
  End Sub

  Private Sub btnUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
    DataUpdate()
    ListLoad()
  End Sub

  Private Sub lstProducts_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstProducts.SelectedIndexChanged
    FormShow()
  End Sub

  Private Sub FindItem(ByVal cboCombo As ComboBox, _
    ByVal strID As String)
    Dim intLoop As Integer
    Dim boolFound As Boolean
    Dim oItem As PDSAListItemNumeric

    oItem = New PDSAListItemNumeric()
    For intLoop = 0 To cboCombo.Items.Count - 1
      oItem = CType(cboCombo.Items(intLoop), _
        PDSAListItemNumeric)
      If oItem.ID = CInt(strID) Then
        cboCombo.SelectedIndex = intLoop
        boolFound = True
        Exit For
      End If
    Next
    If Not boolFound Then
      cboCombo.SelectedIndex = -1
    End If
  End Sub


  Private Function ConnectStringBuild() As String
    Dim strConn As String

    strConn = "Provider=sqloledb;"
    strConn &= "Data Source=(local);"
    strConn &= "Initial Catalog=Northwind;"
    strConn &= "User ID=sa"

    Return strConn
  End Function

  Private Function Str2Field(ByVal strValue As String) As String
    If strValue.Trim() = "" Then
      Return "Null"
    Else
      Return "'" & strValue.Trim() & "'"
    End If
  End Function

  Private Sub frmProduct_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    ' Load Suppliers
    SupplierLoad()
    ' Load Categories
    CategoryLoad()
    ' Load List Box of Products
    ListLoad()
  End Sub
End Class