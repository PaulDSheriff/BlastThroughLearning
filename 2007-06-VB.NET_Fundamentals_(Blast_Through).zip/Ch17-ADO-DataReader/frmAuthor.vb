Public Class frmAuthor
    Inherits System.Windows.Forms.Form
    
    Private Const CON_AUID As Integer = 0
    Private Const CON_LNAME As Integer = 1
    Private Const CON_FNAME As Integer = 2
    
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    Private WithEvents txtID As System.Windows.Forms.TextBox
    Private WithEvents Label3 As System.Windows.Forms.Label
    Private WithEvents chkContract As System.Windows.Forms.CheckBox
    Private WithEvents txtPhone As System.Windows.Forms.TextBox
    Private WithEvents Label2 As System.Windows.Forms.Label
    Private WithEvents txtLast As System.Windows.Forms.TextBox
    Private WithEvents Label1 As System.Windows.Forms.Label
    Private WithEvents txtFirst As System.Windows.Forms.TextBox
    Private WithEvents lblFirst As System.Windows.Forms.Label
    Private WithEvents btnLoad2 As System.Windows.Forms.Button
    Private WithEvents lstNames As System.Windows.Forms.ListBox
    Private WithEvents btnLoad As System.Windows.Forms.Button

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.txtFirst = New System.Windows.Forms.TextBox()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.chkContract = New System.Windows.Forms.CheckBox()
        Me.btnLoad = New System.Windows.Forms.Button()
        Me.lblFirst = New System.Windows.Forms.Label()
        Me.lstNames = New System.Windows.Forms.ListBox()
        Me.txtLast = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnLoad2 = New System.Windows.Forms.Button()
        Me.txtPhone = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()

        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        txtFirst.Location = New System.Drawing.Point(424, 56)
        txtFirst.MaxLength = 20
        txtFirst.TabIndex = 5
        txtFirst.Size = New System.Drawing.Size(168, 26)

        txtID.Location = New System.Drawing.Point(424, 16)
        txtID.MaxLength = 20
        txtID.TabIndex = 13
        txtID.Size = New System.Drawing.Size(168, 26)
        txtID.Visible = False

        chkContract.Checked = True
        chkContract.Location = New System.Drawing.Point(296, 176)
        chkContract.Text = "Contract"
        chkContract.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        chkContract.Size = New System.Drawing.Size(144, 16)
        chkContract.CheckState = System.Windows.Forms.CheckState.Checked
        chkContract.TabIndex = 10

        btnLoad.Location = New System.Drawing.Point(8, 224)
        btnLoad.Size = New System.Drawing.Size(104, 48)
        btnLoad.TabIndex = 0
        btnLoad.Text = "Load (1)"

        lblFirst.Location = New System.Drawing.Point(296, 56)
        lblFirst.Text = "First Name"
        lblFirst.Size = New System.Drawing.Size(112, 24)
        lblFirst.TabIndex = 4

        lstNames.Location = New System.Drawing.Point(8, 8)
        lstNames.Size = New System.Drawing.Size(280, 204)
        lstNames.TabIndex = 1

        txtLast.Location = New System.Drawing.Point(424, 96)
        txtLast.MaxLength = 40
        txtLast.TabIndex = 7
        txtLast.Size = New System.Drawing.Size(200, 26)

        Label1.Location = New System.Drawing.Point(296, 96)
        Label1.Text = "Last Name"
        Label1.Size = New System.Drawing.Size(112, 24)
        Label1.TabIndex = 6

        btnLoad2.Location = New System.Drawing.Point(112, 224)
        btnLoad2.Size = New System.Drawing.Size(104, 48)
        btnLoad2.TabIndex = 2
        btnLoad2.Text = "Load (2)"

        txtPhone.Location = New System.Drawing.Point(424, 136)
        txtPhone.MaxLength = 12
        txtPhone.TabIndex = 9
        txtPhone.Size = New System.Drawing.Size(200, 26)

        Label3.Location = New System.Drawing.Point(296, 16)
        Label3.Text = "Author ID"
        Label3.Size = New System.Drawing.Size(112, 24)
        Label3.TabIndex = 12
        Label3.Visible = False

        Label2.Location = New System.Drawing.Point(296, 136)
        Label2.Text = "Phone"
        Label2.Size = New System.Drawing.Size(112, 24)
        Label2.TabIndex = 8
        Me.Text = "Authors"
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold)
        Me.ClientSize = New System.Drawing.Size(632, 274)

        Me.Controls.Add(txtID)
        Me.Controls.Add(Label3)
        Me.Controls.Add(chkContract)
        Me.Controls.Add(txtPhone)
        Me.Controls.Add(Label2)
        Me.Controls.Add(txtLast)
        Me.Controls.Add(Label1)
        Me.Controls.Add(txtFirst)
        Me.Controls.Add(lblFirst)
        Me.Controls.Add(btnLoad2)
        Me.Controls.Add(lstNames)
        Me.Controls.Add(btnLoad)
    End Sub

#End Region
    
    Private Sub lstNames_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstNames.SelectedIndexChanged
        FormShow()
    End Sub

    Private Sub btnLoad2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnLoad2.Click
        ListLoad2()
    End Sub

    Private Sub btnLoad_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnLoad.Click
        ListLoad1()
    End Sub

    Private Sub ListLoad1()
        Dim oConn As OleDb.OleDbConnection
        Dim oCmd As OleDb.OleDbCommand
        Dim oDR As OleDb.OleDbDataReader
        Dim oItem As PDSAListItemString
        Dim strConn As String
        Dim strSQL As String

        strConn = ConnectStringBuild()

        strSQL = "SELECT au_id, au_lname, au_fname FROM Authors"

        Try
            '** Create the Objects
            oConn = New OleDb.OleDbConnection()
            oCmd = New OleDb.OleDbCommand()

            '** Open the Connection
            With oConn
                .ConnectionString = strConn
                .Open()
            End With

            '** Set the command text
            With oCmd
                .CommandText = strSQL
                .Connection = oConn
                .CommandType = Data.CommandType.Text

                oDR = .ExecuteReader(CommandBehavior.SequentialAccess)
            End With

            lstNames.Items.Clear()
            Do While oDR.Read()
                oItem = New PDSAListItemString()
                oItem.ID = oDR.GetString(CON_AUID)
                oItem.Value = oDR.GetString(CON_LNAME) & _
                  ", " & oDR.GetString(CON_FNAME)

                lstNames.Items.Add(oItem)
            Loop
            oDR.Close()
            oConn.Close()

        Catch oException As Exception
            MessageBox.Show(oException.Message)

        End Try
        If lstNames.Items.Count > 0 Then
            lstNames.SelectedIndex = 0
        End If
    End Sub

    Private Sub ListLoad2()
        Dim oCmd As OleDb.OleDbCommand
        Dim oDR As OleDb.OleDbDataReader
        Dim oItem As PDSAListItemString
        Dim strConn As String
        Dim strSQL As String

        strConn = ConnectStringBuild()

        strSQL = "SELECT au_id, au_lname, au_fname FROM Authors"

        Try
            oCmd = New OleDb.OleDbCommand()
            With oCmd
                .CommandText = strSQL
                .Connection = (New OleDb.OleDbConnection(strConn))
                .Connection.Open()
                .CommandType = Data.CommandType.Text

                oDR = .ExecuteReader(CommandBehavior.SequentialAccess)
            End With

            lstNames.Items.Clear()
            Do While oDR.Read()
                oItem = New PDSAListItemString()
                oItem.ID = oDR.Item("au_id").ToString()
                oItem.Value = oDR.Item("au_lname").ToString() & _
                 ", " & oDR.Item("au_fname").ToString()

                lstNames.Items.Add(oItem)
            Loop
            oDR.Close()
            oCmd.Connection.Close()

        Catch oException As Exception
            MessageBox.Show(oException.Message)

        End Try
        If lstNames.Items.Count > 0 Then
            lstNames.SelectedIndex = 0
        End If
    End Sub

    Private Sub FormShow()
        Dim oCmd As OleDb.OleDbCommand
        Dim oDR As OleDb.OleDbDataReader
        Dim oItem As PDSAListItemString
        Dim strSQL As String
        Dim strID As String
        Dim strConn As String

        strConn = ConnectStringBuild()

        oItem = CType(lstNames.SelectedItem, PDSAListItemString)

        '** Set the command text
        strSQL = "SELECT au_id, au_lname, au_fname, "
        strSQL &= "phone, contract FROM Authors "
        strSQL &= "WHERE au_id = '" & oItem.ID & "'"

        Try
            oCmd = New OleDb.OleDbCommand()
            With oCmd
                .CommandText = strSQL
                .CommandType = Data.CommandType.Text
                .Connection = (New OleDb.OleDbConnection(strConn))
                .Connection.Open()

                oDR = .ExecuteReader(CommandBehavior.CloseConnection)
            End With

            If oDR.Read Then
                ' When you specify CommandBehavior.SequentialAccess 
                ' you must read columns in the order specified in the SELECT list
                txtID.Text = oDR("au_id").ToString()
                txtLast.Text = oDR("au_lname").ToString()
                txtFirst.Text = oDR("au_fname").ToString()
                txtPhone.Text = oDR("phone").ToString()

                If oDR.Item("contract").ToString = "True" Then
                    chkContract.Checked = True
                Else
                    chkContract.Checked = False
                End If
            Else
                txtID.Text = ControlChars.NullChar
                txtFirst.Text = ControlChars.NullChar
                txtLast.Text = ControlChars.NullChar
                txtPhone.Text = ControlChars.NullChar
                chkContract.Checked = False
            End If
            oDR.Close()
            oCmd.Connection.Close()

        Catch oException As Exception
            MessageBox.Show(oException.Message)

        End Try
    End Sub

    Private Function ConnectStringBuild() As String
        Dim strConn As String

        strConn = "Provider=sqloledb;"
        strConn &= "Data Source=(local);"
        strConn &= "Initial Catalog=Pubs;"
        strConn &= "User id=sa"

        Return strConn
    End Function
End Class
