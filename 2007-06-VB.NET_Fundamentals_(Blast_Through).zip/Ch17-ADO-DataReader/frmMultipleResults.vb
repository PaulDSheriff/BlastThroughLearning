Public Class frmMultipleResults
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents btnLoad As System.Windows.Forms.Button
    Friend WithEvents lstProducts As System.Windows.Forms.ListBox
    Friend WithEvents lstCustomers As System.Windows.Forms.ListBox

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.lstProducts = New System.Windows.Forms.ListBox()
        Me.lstCustomers = New System.Windows.Forms.ListBox()
        Me.btnLoad = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lstProducts
        '
        Me.lstProducts.ItemHeight = 20
        Me.lstProducts.Location = New System.Drawing.Point(8, 8)
        Me.lstProducts.Name = "lstProducts"
        Me.lstProducts.Size = New System.Drawing.Size(200, 184)
        Me.lstProducts.TabIndex = 0
        '
        'lstCustomers
        '
        Me.lstCustomers.ItemHeight = 20
        Me.lstCustomers.Location = New System.Drawing.Point(224, 8)
        Me.lstCustomers.Name = "lstCustomers"
        Me.lstCustomers.Size = New System.Drawing.Size(200, 184)
        Me.lstCustomers.TabIndex = 1
        '
        'btnLoad
        '
        Me.btnLoad.Location = New System.Drawing.Point(352, 200)
        Me.btnLoad.Name = "btnLoad"
        Me.btnLoad.TabIndex = 2
        Me.btnLoad.Text = "Load"
        '
        'frmMultipleResults
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(432, 226)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnLoad, Me.lstCustomers, Me.lstProducts})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmMultipleResults"
        Me.Text = "frmMultipleResults"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoad.Click
        Dim oCmd As OleDb.OleDbCommand
        Dim oDR As OleDb.OleDbDataReader
        Dim strSQL As String
        Dim strConn As String
        Dim oItem As PDSAListItemNumeric

        strConn = ConnectStringBuild()

        strSQL = "SELECT ProductName FROM Products "
        strSQL &= "SELECT CompanyName FROM Customers"

        Try
            oCmd = New OleDb.OleDbCommand()
            With oCmd
                .Connection = New OleDb.OleDbConnection(strConn)
                .Connection.Open()
                .CommandText = strSQL
                ' Closes connection when closing DataReader object
                oDR = .ExecuteReader(CommandBehavior.CloseConnection)
            End With

            Do While oDR.Read()
                lstProducts.Items.Add(oDR("ProductName"))
            Loop

            ' Get Next Result Set
            oDR.NextResult()

            Do While oDR.Read()
                lstCustomers.Items.Add(oDR("CompanyName"))
            Loop
            oDR.Close()

        Catch oExcept As Exception
            MessageBox.Show(oExcept.Message)

        End Try

    End Sub

    Private Function ConnectStringBuild() As String
        Dim strConn As String

        strConn = "Provider=sqloledb;"
        strConn &= "Data Source=(local);"
        strConn &= "Initial Catalog=Northwind;"
        strConn &= "User ID=sa"

        Return strConn
    End Function
End Class
