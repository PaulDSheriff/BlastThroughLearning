Public Class frmMain
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    Private WithEvents btnProducts As System.Windows.Forms.Button
    Private WithEvents btnAuthor As System.Windows.Forms.Button
    Friend WithEvents btnMultiple As System.Windows.Forms.Button
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnAuthor = New System.Windows.Forms.Button()
        Me.btnMultiple = New System.Windows.Forms.Button()
        Me.btnProducts = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnAuthor
        '
        Me.btnAuthor.Location = New System.Drawing.Point(24, 8)
        Me.btnAuthor.Name = "btnAuthor"
        Me.btnAuthor.Size = New System.Drawing.Size(104, 48)
        Me.btnAuthor.TabIndex = 0
        Me.btnAuthor.Text = "Authors"
        '
        'btnMultiple
        '
        Me.btnMultiple.Location = New System.Drawing.Point(264, 8)
        Me.btnMultiple.Name = "btnMultiple"
        Me.btnMultiple.Size = New System.Drawing.Size(104, 48)
        Me.btnMultiple.TabIndex = 1
        Me.btnMultiple.Text = "Multiple Results"
        '
        'btnProducts
        '
        Me.btnProducts.Location = New System.Drawing.Point(144, 8)
        Me.btnProducts.Name = "btnProducts"
        Me.btnProducts.Size = New System.Drawing.Size(104, 48)
        Me.btnProducts.TabIndex = 1
        Me.btnProducts.Text = "Products"
        '
        'frmMain
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(384, 66)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnMultiple, Me.btnProducts, Me.btnAuthor})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold)
        Me.Name = "frmMain"
        Me.Text = "DataReader Object"
        Me.ResumeLayout(False)

    End Sub

#End Region
    
    Private Sub btnProducts_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnProducts.Click
        Dim frm As frmProduct

        frm = New frmProduct()

        frm.Show()
    End Sub

    Private Sub btnAuthor_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAuthor.Click
        Dim frm As frmAuthor

        frm = New frmAuthor()

        frm.Show()
    End Sub

    Private Sub btnMultiple_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMultiple.Click
        Dim frm As frmMultipleResults

        frm = New frmMultipleResults()

        frm.Show()
    End Sub
End Class
