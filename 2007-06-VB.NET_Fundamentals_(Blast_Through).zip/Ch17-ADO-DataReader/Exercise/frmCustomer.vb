Public Class frmCustomer
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Win Form Designer.
        InitializeComponent()

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    Private WithEvents Label5 As System.Windows.Forms.Label
    Private WithEvents Label4 As System.Windows.Forms.Label
    Private WithEvents Label3 As System.Windows.Forms.Label
    Private WithEvents lblFirst As System.Windows.Forms.Label
    Private WithEvents txtTitle As System.Windows.Forms.TextBox
    Private WithEvents txtCompany As System.Windows.Forms.TextBox
    Private WithEvents txtContact As System.Windows.Forms.TextBox
    Private WithEvents lstCustomers As System.Windows.Forms.ListBox
    Private WithEvents txtCustID As System.Windows.Forms.TextBox

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtTitle = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtCustID = New System.Windows.Forms.TextBox()
        Me.lblFirst = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lstCustomers = New System.Windows.Forms.ListBox()
        Me.txtCompany = New System.Windows.Forms.TextBox()
        Me.txtContact = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(264, 88)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(104, 24)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Contact"
        '
        'txtTitle
        '
        Me.txtTitle.Location = New System.Drawing.Point(384, 128)
        Me.txtTitle.MaxLength = 12
        Me.txtTitle.Name = "txtTitle"
        Me.txtTitle.Size = New System.Drawing.Size(208, 26)
        Me.txtTitle.TabIndex = 12
        Me.txtTitle.Text = ""
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(264, 128)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(104, 24)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Title"
        '
        'txtCustID
        '
        Me.txtCustID.Location = New System.Drawing.Point(384, 8)
        Me.txtCustID.MaxLength = 20
        Me.txtCustID.Name = "txtCustID"
        Me.txtCustID.Size = New System.Drawing.Size(136, 26)
        Me.txtCustID.TabIndex = 2
        Me.txtCustID.Text = ""
        '
        'lblFirst
        '
        Me.lblFirst.Location = New System.Drawing.Point(264, 48)
        Me.lblFirst.Name = "lblFirst"
        Me.lblFirst.Size = New System.Drawing.Size(104, 24)
        Me.lblFirst.TabIndex = 4
        Me.lblFirst.Text = "Company"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(264, 8)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(104, 24)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Customer ID"
        '
        'lstCustomers
        '
        Me.lstCustomers.ItemHeight = 20
        Me.lstCustomers.Location = New System.Drawing.Point(8, 8)
        Me.lstCustomers.Name = "lstCustomers"
        Me.lstCustomers.Size = New System.Drawing.Size(248, 204)
        Me.lstCustomers.Sorted = True
        Me.lstCustomers.TabIndex = 0
        '
        'txtCompany
        '
        Me.txtCompany.Location = New System.Drawing.Point(384, 48)
        Me.txtCompany.MaxLength = 20
        Me.txtCompany.Name = "txtCompany"
        Me.txtCompany.Size = New System.Drawing.Size(208, 26)
        Me.txtCompany.TabIndex = 3
        Me.txtCompany.Text = ""
        '
        'txtContact
        '
        Me.txtContact.Location = New System.Drawing.Point(384, 88)
        Me.txtContact.MaxLength = 40
        Me.txtContact.Name = "txtContact"
        Me.txtContact.Size = New System.Drawing.Size(208, 26)
        Me.txtContact.TabIndex = 10
        Me.txtContact.Text = ""
        '
        'frmCustomer
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(600, 226)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label5, Me.Label4, Me.txtCustID, Me.Label3, Me.txtTitle, Me.txtContact, Me.txtCompany, Me.lblFirst, Me.lstCustomers})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold)
        Me.Name = "frmCustomer"
        Me.Text = "Customer Information"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub ListLoad()
        Dim oCmd As OleDb.OleDbCommand
        Dim oDR As OleDb.OleDbDataReader
        Dim oItem As PDSAListItemString
        Dim strSQL As String
        Dim strConn As String

        strConn = ConnectStringBuild()

        strSQL = "SELECT CustomerID, CompanyName, ContactName, ContactTitle "
        strSQL &= "FROM Customers"

        Try
            oCmd = New OleDb.OleDbCommand()
            With oCmd
                .Connection = _
                 New OleDb.OleDbConnection(strConn)
                .Connection.Open()
                .CommandText = strSQL
                ' Returns rows/column in sequential order only
                oDR = .ExecuteReader( _
                 CommandBehavior.SequentialAccess)
            End With

            ' Write code here to load list box


        Catch oExcept As Exception
            MessageBox.Show(oExcept.Message)

        End Try
    End Sub

    Private Function ConnectStringBuild() As String
        Dim strConn As String

        strConn = "Provider=sqloledb;"
        strConn &= "Data Source=(local);"
        strConn &= "Initial Catalog=Northwind;"
        strConn &= "User ID=sa"

        Return strConn
    End Function

    Private Function Str2Field(ByVal strValue As String) As String
        If strValue.Trim() = "" Then
            Return "Null"
        Else
            Return "'" & strValue.Trim() & "'"
        End If
    End Function

    Private Sub frmCustomer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Load List Box of Customers
        ListLoad()
    End Sub

    Private Sub lstCustomers_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstCustomers.SelectedIndexChanged
        Call FormShow()
    End Sub

    Private Sub FormShow()
        Dim oCmd As OleDb.OleDbCommand
        Dim oDR As OleDb.OleDbDataReader
        Dim oItem As PDSAListItemString
        Dim strSQL As String
        Dim strConn As String

        strConn = ConnectStringBuild()

        ' Get Primary Key From List Box
        oItem = CType(lstCustomers.SelectedItem, PDSAListItemString)

        strSQL = "SELECT CustomerID, CompanyName, ContactName, ContactTitle "
        strSQL &= "FROM Customers WHERE CustomerID = '" & oItem.ID & "'"

        Try
            oCmd = New OleDb.OleDbCommand()
            With oCmd
                .Connection = _
                 New OleDb.OleDbConnection(strConn)
                .Connection.Open()
                .CommandText = strSQL
                ' Returns rows/column in sequential order only
                oDR = .ExecuteReader( _
                 CommandBehavior.SequentialAccess)
            End With

            ' Write code here to load text boxes


        Catch oExcept As Exception
            MessageBox.Show(oExcept.Message)

        End Try
    End Sub
End Class