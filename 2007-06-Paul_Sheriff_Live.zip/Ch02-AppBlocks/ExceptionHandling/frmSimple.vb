Public Class frmSimple
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnNone As System.Windows.Forms.Button
    Friend WithEvents btnMsg As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnNone = New System.Windows.Forms.Button()
        Me.btnMsg = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnNone
        '
        Me.btnNone.Location = New System.Drawing.Point(8, 16)
        Me.btnNone.Name = "btnNone"
        Me.btnNone.Size = New System.Drawing.Size(112, 56)
        Me.btnNone.TabIndex = 0
        Me.btnNone.Text = "No Catch"
        '
        'btnMsg
        '
        Me.btnMsg.Location = New System.Drawing.Point(136, 16)
        Me.btnMsg.Name = "btnMsg"
        Me.btnMsg.Size = New System.Drawing.Size(144, 56)
        Me.btnMsg.TabIndex = 1
        Me.btnMsg.Text = "Catch with MessageBox"
        '
        'frmSimple
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(296, 82)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnMsg, Me.btnNone})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmSimple"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Simple Exceptions"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnNone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNone.Click
        Dim ds As New DataSet()
        Dim da As SqlClient.SqlDataAdapter

        da = New SqlClient.SqlDataAdapter( _
         ConfigurationSettings.AppSettings("SL"), _
         ConfigurationSettings.AppSettings("ConnectString"))

        da.Fill(ds)

    End Sub

    Private Sub btnMsg_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMsg.Click
        Dim ds As New DataSet()
        Dim da As SqlClient.SqlDataAdapter

        Try
            da = New SqlClient.SqlDataAdapter( _
             ConfigurationSettings.AppSettings("SL"), _
             ConfigurationSettings.AppSettings("ConnectString"))

            da.Fill(ds)

        Catch exp As Exception
            MessageBox.Show(exp.Message)

        End Try
    End Sub
End Class
