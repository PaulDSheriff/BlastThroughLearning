Public Class frmMain
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnSimple As System.Windows.Forms.Button
    Friend WithEvents btnAppBlock As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnSimple = New System.Windows.Forms.Button()
        Me.btnAppBlock = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnSimple
        '
        Me.btnSimple.Location = New System.Drawing.Point(8, 8)
        Me.btnSimple.Name = "btnSimple"
        Me.btnSimple.Size = New System.Drawing.Size(176, 64)
        Me.btnSimple.TabIndex = 0
        Me.btnSimple.Text = "Simple Exceptions"
        '
        'btnAppBlock
        '
        Me.btnAppBlock.Location = New System.Drawing.Point(200, 8)
        Me.btnAppBlock.Name = "btnAppBlock"
        Me.btnAppBlock.Size = New System.Drawing.Size(168, 64)
        Me.btnAppBlock.TabIndex = 1
        Me.btnAppBlock.Text = "Exception Management App Block"
        '
        'frmMain
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.ClientSize = New System.Drawing.Size(384, 82)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnAppBlock, Me.btnSimple})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Exception Management"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnSimple_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimple.Click
        Dim frm As New frmSimple()

        frm.Show()
    End Sub

    Private Sub btnAppBlock_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAppBlock.Click
        Dim frm As New frmAppBlock()

        frm.Show()
    End Sub
End Class
