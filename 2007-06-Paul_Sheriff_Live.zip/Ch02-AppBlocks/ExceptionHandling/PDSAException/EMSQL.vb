Imports Microsoft.ApplicationBlocks.ExceptionManagement
Imports System.Collections.Specialized

Public Class EMSQL
    Implements IExceptionPublisher

    Public Sub Publish(ByVal exception As Exception, _
        ByVal additionalInfo As NameValueCollection, _
        ByVal configSettings As NameValueCollection) _
        Implements IExceptionPublisher.Publish

        Dim strConn As String
        Dim strSQL As String
        Dim strFormName As String
        Dim strAppName As String
        Dim cmd As SqlClient.SqlCommand


        If Not (additionalInfo Is Nothing) Then
            ' Process Additional Info
            With additionalInfo
                strFormName = .Item("FormName")
                strAppName = .Item("ApplicationName")
            End With
        End If

        If Not (configSettings Is Nothing) Then
            ' Retrieve Attributes from Config File
            strConn = configSettings.Item("SQLConnect")
        End If

        strSQL = "INSERT INTO ErrorLog("
        strSQL &= "szUser_nm, szForm_nm, "
        strSQL &= "dtError_dt, szAppl_nm, szError_tx )"
        strSQL &= " VALUES('{0}', '{1}', '{2}', '{3}', '{4}')"

        strSQL = String.Format(strSQL, _
            System.Security.Principal.WindowsIdentity.GetCurrent.Name, _
            strFormName, Now(), _
            strAppName, _
            Replace(exception.ToString(), "'", "''"))

        Try
            cmd = New SqlClient.SqlCommand(strSQL)
            cmd.Connection = New SqlClient.SqlConnection(strConn)
            cmd.Connection.Open()

            cmd.ExecuteNonQuery()

            cmd.Connection.Close()

        Catch exp As Exception
            ' Log error from Exception Manager
            ' into Application Event Log
            Throw exp

        End Try
    End Sub
End Class