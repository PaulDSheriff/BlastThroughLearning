Public Class EMInfo
    Public Shared Function AdditionalInfo( _
        ByVal FormName As String, _
        ByVal ApplicationName As String) As _
        System.Collections.Specialized.NameValueCollection

        Dim nvc As New System.Collections.Specialized.NameValueCollection()

        nvc.Add("FormName", FormName)
        nvc.Add("ApplicationName", ApplicationName)

        Return nvc
    End Function
End Class
