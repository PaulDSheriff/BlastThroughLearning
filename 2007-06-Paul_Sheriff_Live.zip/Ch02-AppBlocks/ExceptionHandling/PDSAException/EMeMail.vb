Imports Microsoft.ApplicationBlocks.ExceptionManagement
Imports System.Collections.Specialized
Imports System.Web.Mail

Public Class EMeMail
    Implements IExceptionPublisher

    Public Sub Publish(ByVal exception As Exception, _
        ByVal additionalInfo As NameValueCollection, _
        ByVal configSettings As NameValueCollection) _
        Implements IExceptionPublisher.Publish

        Dim strFromEmail As String
        Dim strToEmail As String
        Dim strSubject As String
        Dim strFormName As String
        Dim strAppName As String
        Dim strSMTP As String

        If Not (additionalInfo Is Nothing) Then
            ' Retrieve Additional Info
            With additionalInfo
                strFormName = .Item("FormName")
                strAppName = .Item("ApplicationName")
            End With
        End If

        If Not (configSettings Is Nothing) Then
            ' Retrieve Attributes from Config File
            With configSettings
                strFromEmail = .Item("FromEMail")
                strToEmail = .Item("ToEMail")
                strSubject = .Item("Subject")
                strSMTP = .Item("SMTPServer")
            End With
        End If

        strSubject &= " - " & strFormName & _
            " - " & strAppName

        Try
            ' Send Exception via Email
            SmtpMail.SmtpServer = strSMTP
            SmtpMail.Send(strFromEmail, strToEmail, _
            strSubject, exception.ToString())

        Catch exp As Exception
            ' Log error from Exception Manager
            ' into Application Event Log
            Throw exp

        End Try
    End Sub
End Class