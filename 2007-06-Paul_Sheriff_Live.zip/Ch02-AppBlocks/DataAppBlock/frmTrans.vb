Imports Microsoft.ApplicationBlocks.Data

Public Class frmTrans
  Inherits System.Windows.Forms.Form

  Const conCONNECT As String = "Server=localhost;Database=Northwind;uid=sa;pwd=sa"

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  Friend WithEvents btnADOTrans As System.Windows.Forms.Button
  Friend WithEvents btnTransSql As System.Windows.Forms.Button
  Friend WithEvents btnSqlTrans As System.Windows.Forms.Button
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.btnADOTrans = New System.Windows.Forms.Button()
    Me.btnTransSql = New System.Windows.Forms.Button()
    Me.btnSqlTrans = New System.Windows.Forms.Button()
    Me.SuspendLayout()
    '
    'btnADOTrans
    '
    Me.btnADOTrans.Location = New System.Drawing.Point(8, 8)
    Me.btnADOTrans.Name = "btnADOTrans"
    Me.btnADOTrans.Size = New System.Drawing.Size(144, 64)
    Me.btnADOTrans.TabIndex = 3
    Me.btnADOTrans.Text = "Transaction using ADO.NET"
    '
    'btnTransSql
    '
    Me.btnTransSql.Location = New System.Drawing.Point(168, 8)
    Me.btnTransSql.Name = "btnTransSql"
    Me.btnTransSql.Size = New System.Drawing.Size(144, 64)
    Me.btnTransSql.TabIndex = 4
    Me.btnTransSql.Text = "Transaction using SqlHelper"
    '
    'btnSqlTrans
    '
    Me.btnSqlTrans.Location = New System.Drawing.Point(328, 8)
    Me.btnSqlTrans.Name = "btnSqlTrans"
    Me.btnSqlTrans.Size = New System.Drawing.Size(144, 64)
    Me.btnSqlTrans.TabIndex = 5
    Me.btnSqlTrans.Text = "Transaction using SqlTrans"
    '
    'frmTrans
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
    Me.ClientSize = New System.Drawing.Size(480, 82)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnSqlTrans, Me.btnTransSql, Me.btnADOTrans})
    Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Name = "frmTrans"
    Me.Text = "Transaction Example"
    Me.ResumeLayout(False)

  End Sub

#End Region

  Private Sub btnADOTrans_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnADOTrans.Click
    ADONetTrans()
  End Sub

  Private Sub ADONetTrans()
    Dim cmd As SqlClient.SqlCommand
    Dim tr As SqlClient.SqlTransaction
    Dim strSQL As String
    Dim intRows As Integer

    Try
      ' Create a new Command Object
      cmd = New SqlClient.SqlCommand()
      ' Create a new Connection Object
      cmd.Connection = New _
       SqlClient.SqlConnection(conCONNECT)
      ' Open the Connection
      cmd.Connection.Open()

      ' Start Transaction
      tr = cmd.Connection.BeginTransaction()
      ' Put Transaction Object into Command Object
      cmd.Transaction = tr

      strSQL = "UPDATE Products "
      strSQL &= " SET ProductName = 'Chai 2' "
      strSQL &= " WHERE ProductID = 1"
      ' Fill in Command Object
      cmd.CommandText = strSQL
      cmd.CommandType = CommandType.Text
      ' Execute the Query
      intRows = cmd.ExecuteNonQuery()

      strSQL = "UPDATE Categories "
      strSQL &= " SET CategoryName = 'Beverages 2' "
      strSQL &= " WHERE CategoryID = 1"
      ' Fill in Command Object
      cmd.CommandText = strSQL
      cmd.CommandType = CommandType.Text
      ' Execute the Query
      intRows = cmd.ExecuteNonQuery()

      ' Commit the Transaction
      tr.Commit()
      ' Close the Connection
         cmd.Connection.Close()
         cmd.Connection.Dispose()

      MessageBox.Show("Transaction Successful")

    Catch exp As Exception
      ' Rollback the Transaction
      tr.Rollback()
      ' Close the Connection

            cmd.Connection.Close()
            MessageBox.Show("Transaction Aborted")

        End Try
    End Sub

    Private Sub btnTransSql_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTransSql.Click
        SqlHelperTrans()
    End Sub

    Private Sub SqlHelperTrans()
        Dim cnn As SqlClient.SqlConnection
        Dim tr As SqlClient.SqlTransaction
        Dim strSQL As String
        Dim intRows As Integer

        Try
            ' Create Connect Object
            cnn = New SqlClient.SqlConnection(conCONNECT)
            ' Open the Connection
            cnn.Open()

            ' Start Transaction
            tr = cnn.BeginTransaction()

            strSQL = "UPDATE Products "
            strSQL &= " SET ProductName = 'Chai 2' "
            strSQL &= " WHERE ProductID = 1"
            ' Execute the SQL
            intRows = SqlHelper.ExecuteNonQuery(tr, _
             CommandType.Text, strSQL)

            strSQL = "UPDATE Categories "
            strSQL &= " SET CategoryName = 'Beverages 2' "
            strSQL &= " WHERE CategoryID = 1"
            ' Execute the SQL
            intRows = SqlHelper.ExecuteNonQuery(tr, _
             CommandType.Text, strSQL)

            ' Commit the Transaction
            tr.Commit()
            ' Close the Connection
            cnn.Close()

            MessageBox.Show("Transaction Successful")

        Catch exp As Exception
            ' Rollback the Transaction
            tr.Rollback()
            ' Close the Connection
            cnn.Close()
            MessageBox.Show("Transaction Aborted")
        End Try
    End Sub

    Private Sub btnSqlTrans_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSqlTrans.Click
        SqlTrans()
    End Sub

    Private Sub SqlTrans()
        Dim astrSQL(1) As String
        Dim strSQL As String

        strSQL = "UPDATE Products "
        strSQL &= " SET ProductName = 'Chai 2' "
        strSQL &= " WHERE ProductID = 1"
        astrSQL(0) = strSQL

        strSQL = "UPDATE Categories "
        strSQL &= " SET CategoryName = 'Beverages 2' "
        strSQL &= " WHERE CategoryID = 1"
        astrSQL(1) = strSQL

        Try
            ' Pass array of SQL to ExecuteTrans
            SQLTransHelper.ExecuteTrans( _
             conCONNECT, astrSQL)

            MessageBox.Show("Transaction Successful")
        Catch exp As Exception
            MessageBox.Show("Transaction Aborted")
        End Try
    End Sub
End Class

Public Class SQLTransHelper
  Public Shared Sub ExecuteTrans(ByVal ConnectString As String, _
   ByVal ParamArray SQLStatements() As String)
    Dim cnn As SqlClient.SqlConnection
    Dim tr As SqlClient.SqlTransaction
    Dim strSQL As String

    Try
      ' Create Connect Object
      cnn = New SqlClient.SqlConnection(ConnectString)
      ' Open the Connection
      cnn.Open()

      ' Start Transaction
      tr = cnn.BeginTransaction()

      For Each strSQL In SQLStatements
        ' Execute the SQL
        SqlHelper.ExecuteNonQuery(tr, _
         CommandType.Text, strSQL)
      Next

      ' Commit the Transaction
      tr.Commit()
      ' Close the Connection
      cnn.Close()

    Catch exp As Exception
      ' Rollback the Transaction
      tr.Rollback()
      ' Close the Connection
      cnn.Close()
      ' Throw an exception back to caller
      Throw exp
    End Try
  End Sub
End Class
