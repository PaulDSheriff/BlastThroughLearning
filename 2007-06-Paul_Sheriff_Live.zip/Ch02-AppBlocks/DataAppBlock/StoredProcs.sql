Use Northwind
Go

DROP PROC procProductsAll
Go
DROP PROC procProductsUpdate
Go
DROP PROC procProductsCount
Go
DROP TABLE UserTicket
Go
DROP PROC procTicketCreate
Go

CREATE PROCEDURE procProductsAll
AS
SELECT * FROM Products
GO

CREATE PROCEDURE procProductsUpdate
@ProductName Char(40), 
@ProductID Int
AS
UPDATE Products 
SET ProductName = @ProductName
WHERE ProductID = @ProductID
GO

CREATE PROCEDURE procProductsCount
AS
SELECT Count(*) FROM Products
GO

CREATE TABLE UserTicket
(
TicketID uniqueidentifier NOT NULL PRIMARY KEY,
UserID varchar(15) NULL,
)
GO

CREATE PROCEDURE procTicketCreate
	@UserID varchar(15),
	@NewGUID varchar(40) OUTPUT
AS
SELECT @NewGUID = NewID()
INSERT INTO UserTicket(TicketID, UserID)
VALUES(@NewGUID, @UserID)
GO