Public Class ConfigSettings
   Inherits System.Web.UI.Page

   Protected WithEvents Label1 As System.Web.UI.WebControls.Label
   Protected WithEvents txtSessionID As System.Web.UI.WebControls.TextBox
   Protected WithEvents Label2 As System.Web.UI.WebControls.Label
   Protected WithEvents litAppSettings As System.Web.UI.WebControls.Literal
   Protected WithEvents litConfig As System.Web.UI.WebControls.Literal
   Protected WithEvents litSingle As System.Web.UI.WebControls.Literal
   Protected WithEvents Label4 As System.Web.UI.WebControls.Label
   Protected WithEvents Label5 As System.Web.UI.WebControls.Label
   Protected WithEvents txtSessionInfo As System.Web.UI.WebControls.TextBox
   Protected WithEvents txtApp As System.Web.UI.WebControls.TextBox
   Protected WithEvents Label6 As System.Web.UI.WebControls.Label
   Protected WithEvents Label7 As System.Web.UI.WebControls.Label
   Protected WithEvents litNameValue As System.Web.UI.WebControls.Literal
   Protected WithEvents btnSetAppInfo As System.Web.UI.WebControls.Button
   Protected WithEvents Label8 As System.Web.UI.WebControls.Label
   Protected WithEvents txtMyAppInfo As System.Web.UI.WebControls.TextBox
   Protected WithEvents litDictionary As System.Web.UI.WebControls.Literal
   Protected WithEvents Label9 As System.Web.UI.WebControls.Label
   Protected WithEvents litGroup As System.Web.UI.WebControls.Literal
   Protected WithEvents Label10 As System.Web.UI.WebControls.Label
   Protected WithEvents litDataSet As System.Web.UI.WebControls.Literal
   Protected WithEvents Label11 As System.Web.UI.WebControls.Label
   Protected WithEvents litReg As System.Web.UI.WebControls.Literal
   Protected WithEvents Label12 As System.Web.UI.WebControls.Label
   Protected WithEvents litTable As System.Web.UI.WebControls.Literal
   Protected WithEvents Label13 As System.Web.UI.WebControls.Label
   Protected WithEvents Label3 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

   'This call is required by the Web Form Designer.
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

   End Sub

   Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
      'CODEGEN: This method call is required by the Web Form Designer
      'Do not modify it using the code editor.
      InitializeComponent()
   End Sub

#End Region

   Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

      txtApp.Text = Convert.ToString(Application("DateTime"))
      If Application("ConnectString") Is Nothing Then
         txtMyAppInfo.Text = "Application ConnectString does NOT exist!"
      Else
         txtMyAppInfo.Text = Application("ConnectString").ToString()
      End If
      txtSessionID.Text = Session.SessionID
      txtSessionInfo.Text = Session("ConnectString").ToString()

      litAppSettings.Text = GetFromAppSettings()

      litSingle.Text = GetFromSingleTag()

      litNameValue.Text = GetFromNameValueSection()
      litGroup.Text = GetFromGroupSection()

      litDictionary.Text = GetFromDictionary()

      litConfig.Text = GetFromConfigClass()
      litDataSet.Text = GetFromXMLFile()

      litReg.Text = GetFromRegistry()
      litTable.Text = GetFromTable()


   End Sub

   Private Function GetFromXMLFile() As String
      Dim sb As New System.Text.StringBuilder(255)

      sb.Append("<br><b>Group1</b><br>")
      sb.Append("ConnectString: " & AppSettings.ConnectString & "<br>")
      sb.Append("SMTP Server: " & AppSettings.SMTPServer & "<br>")

      Return sb.ToString()
   End Function

   Private Function GetFromGroupSection() As String
      Dim sb As New System.Text.StringBuilder(255)
      Dim nv As System.Collections.Specialized.NameValueCollection

      nv = DirectCast(ConfigurationSettings.GetConfig("Groups/Group1"), System.Collections.Specialized.NameValueCollection)

      sb.Append("<br><b>Group1</b><br>")
      sb.Append("ConnectString: " & nv.Item("ConnectString").ToString() & "<br>")
      sb.Append("SMTP Server: " & nv.Item("SMTPServer").ToString() & "<br>")

      nv = DirectCast(ConfigurationSettings.GetConfig("Groups/Group2"), System.Collections.Specialized.NameValueCollection)

      sb.Append("<br><b>Group2</b><br>")
      sb.Append("ConnectString: " & nv.Item("ConnectString").ToString() & "<br>")
      sb.Append("SMTP Server: " & nv.Item("SMTPServer").ToString() & "<br>")

      Return sb.ToString()
   End Function

   Private Function GetFromNameValueSection() As String
      Dim sb As New System.Text.StringBuilder(255)
      Dim nv As System.Collections.Specialized.NameValueCollection

      nv = DirectCast(ConfigurationSettings.GetConfig("nameValueSection"), System.Collections.Specialized.NameValueCollection)

      sb.Append("<br>")
      sb.Append("ConnectString: " & nv.Item("ConnectString").ToString() & "<br>")
      sb.Append("SMTP Server: " & nv.Item("SMTPServer").ToString() & "<br>")

      Return sb.ToString()
   End Function

   Private Function GetFromConfigClass() As String
      Dim sb As New System.Text.StringBuilder(255)

      sb.Append("<br>")
      sb.Append("Connect: " & AppConfig.ConnectString & "<br>")
      sb.Append("SMTP Server: " & AppConfig.SMTPServer & "<br>")
      sb.Append("Physical Path: " & AppConfig.PhysicalPath & "<br>")
      sb.Append("URL Fragment: " & AppConfig.URLFragment & "<br>")
      sb.Append("URL Normal: " & AppConfig.URLNormal & "<br>")
      sb.Append("URL Secure: " & AppConfig.URLSecure & "<br>")

      Return sb.ToString()
   End Function

   Private Function GetFromAppSettings() As String
      Dim sb As New System.Text.StringBuilder(255)

      sb.Append("<br>")
      sb.Append("ConnectString: " & ConfigurationSettings.AppSettings("ConnectString") & "<br>")
      sb.Append("SMTP Server: " & ConfigurationSettings.AppSettings("SMTPServer").ToString() & "<br>")

      Return sb.ToString()
   End Function

   Private Function GetFromDictionary() As String
      Dim sb As New System.Text.StringBuilder(255)
      Dim ht As IDictionary

      ht = DirectCast(ConfigurationSettings.GetConfig("dictionarySection"), Hashtable)

      sb.Append("<br>")
      sb.Append("ConnectString: " & ht.Item("ConnectString").ToString() & "<br>")
      sb.Append("SMTP Server: " & ht.Item("SMTPServer").ToString() & "<br>")

      Return sb.ToString()
   End Function

   Private Function GetFromSingleTag() As String
      Dim sb As New System.Text.StringBuilder(255)
      Dim ht As Hashtable

      ht = DirectCast(ConfigurationSettings.GetConfig("singleTagSection"), Hashtable)

      sb.Append("<br>")
      sb.Append("ConnectString: " & ht.Item("ConnectString").ToString() & "<br>")
      sb.Append("SMTP Server: " & ht.Item("SMTPServer").ToString() & "<br>")

      Return sb.ToString()
   End Function

   Private Function GetFromRegistry() As String
      Dim sb As New System.Text.StringBuilder(255)

      sb.Append("<br>")
      sb.Append("ConnectString: " & RegSettings.ConnectString & "<br>")
      sb.Append("SMTP Server: " & RegSettings.SMTPServer.ToString() & "<br>")

      Return sb.ToString()
   End Function

   Private Function GetFromTable() As String
      Dim sb As New System.Text.StringBuilder(255)

      sb.Append("<br>")
      sb.Append("ConnectString: " & TableSettings.ConnectString & "<br>")
      sb.Append("SMTP Server: " & TableSettings.SMTPServer.ToString() & "<br>")

      Return sb.ToString()
   End Function

   Private Sub btnSetAppInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSetAppInfo.Click
      Application("ConnectString") = "Server=GlobalApp"
      txtMyAppInfo.Text = Application("ConnectString").ToString()
   End Sub
End Class