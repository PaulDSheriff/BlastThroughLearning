Imports Microsoft.Win32

Public Class RegSettings
   Private Const REG_KEY As String = "Software\PDSAConfig"

   Public Shared ReadOnly Property ConnectString() As String
      Get
         Dim rk As RegistryKey
         Dim strREturn As String

         Try
            rk = Registry.LocalMachine.OpenSubKey(REG_KEY)

            strREturn = rk.GetValue("ConnectString").ToString()

            rk.Close()

            Return strREturn

         Catch exp As Exception
            Throw exp

         End Try
      End Get
   End Property

   Public Shared ReadOnly Property SMTPServer() As String
      Get
         Dim rk As RegistryKey
         Dim strReturn As String

         Try
            rk = Registry.LocalMachine.OpenSubKey(REG_KEY)

            strReturn = rk.GetValue("SMTPServer").ToString()

            rk.Close()

            Return strReturn
         Catch exp As Exception
            Throw exp

         End Try
      End Get
   End Property
End Class