Public Class WebSession
   Public Shared Property CurrentUser() As String
      Get
         Return HttpContext.Current.Session("CurrentUser").ToString()
      End Get
      Set(ByVal Value As String)
         HttpContext.Current.Session("CurrentUser") = Value
      End Set
   End Property

   Public Shared Property TempDataSet() As DataSet
      Get
         Return DirectCast(HttpContext.Current.Session("TempDataSet"), DataSet)
      End Get
      Set(ByVal Value As DataSet)
         HttpContext.Current.Session("TempDataSet") = Value
      End Set
   End Property
End Class
