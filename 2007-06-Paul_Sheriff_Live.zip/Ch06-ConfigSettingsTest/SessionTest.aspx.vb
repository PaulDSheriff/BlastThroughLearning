Public Class SessionTest
    Inherits System.Web.UI.Page
   Protected WithEvents btnSet As System.Web.UI.WebControls.Button
   Protected WithEvents btnGet As System.Web.UI.WebControls.Button
   Protected WithEvents grdConfig As System.Web.UI.WebControls.DataGrid

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

   End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

   Private Sub btnSet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSet.Click
      WebSession.CurrentUser = "PSheriff"
      WebSession.TempDataSet = TableSettings.DataSet
   End Sub

   Private Sub btnGet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGet.Click
      Response.Write(WebSession.CurrentUser)

      grdConfig.DataSource = WebSession.TempDataSet
      grdConfig.DataBind()
   End Sub
End Class
