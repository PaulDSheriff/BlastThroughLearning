Public Class AppSettings
   Private Shared mboolFirstTime As Boolean = True
   Private Shared mds As DataSet
   Private Shared mdr As DataRow

   Private Shared Sub DataGet()
      mds = New DataSet()

      Try
         mds.ReadXml(HttpContext.Current.Server.MapPath("AppSettings.xml"))

         mboolFirstTime = False
         mdr = mds.Tables(0).Rows(0)
      Catch exp As Exception
         Throw exp
      End Try
   End Sub

   Public Shared Property ConnectString() As String
      Get
         Try
            If mboolFirstTime Then
               DataGet()
            End If
            Return mdr.Item("ConnectString").ToString()
         Catch exp As Exception
            Throw exp
         End Try
      End Get
      Set(ByVal Value As String)
         mdr.Item("ConnectString") = Value
      End Set
   End Property

   Public Shared Property SMTPServer() As String
      Get
         Try
            If mboolFirstTime Then
               DataGet()
            End If
            Return mdr.Item("SMTPServer").ToString()
         Catch exp As Exception
            Throw exp
         End Try
      End Get
      Set(ByVal Value As String)
         mdr.Item("SMTPServer") = Value
      End Set
   End Property
End Class
