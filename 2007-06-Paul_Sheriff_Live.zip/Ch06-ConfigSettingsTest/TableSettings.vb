Public Class TableSettings
   Private Shared mboolFirstTime As Boolean = True
   Private Shared mds As DataSet
   Private Shared mdr As DataRow

   Const conCONNECT As String = "Server=localhost;Database=Northwind;uid=sa;pwd=sa"

   Private Shared Sub DataGet()
      Try
         mds = New DataSet()
         Dim da As New SqlClient.SqlDataAdapter()
         mboolFirstTime = False

         Try
            da = New SqlClient.SqlDataAdapter("SELECT * FROM ConfigSettings", conCONNECT)
            da.Fill(mds)

            mdr = mds.Tables(0).Rows(0)

            ' For Oracle, you should do this...
            da.SelectCommand.Connection.Dispose()

         Catch exp As Exception
            Throw exp
         End Try
      Catch exp As Exception
         Throw New Exception()
      End Try
   End Sub

   Public Shared Property ConnectString() As String
      Get
         Try
            If mboolFirstTime Then
               DataGet()
            End If
            Return mdr.Item("ConnectString").ToString()
         Catch exp As Exception
            Throw exp
         End Try
      End Get
      Set(ByVal Value As String)
         mdr.Item("ConnectString") = Value
      End Set
   End Property

   Public Shared Property SMTPServer() As String
      Get
         Try
            If mboolFirstTime Then
               DataGet()
            End If
            Return mdr.Item("SMTPServer").ToString()
         Catch exp As Exception
            Throw exp
         End Try
      End Get
      Set(ByVal Value As String)
         mdr.Item("SMTPServer") = Value
      End Set
   End Property

   Public Shared ReadOnly Property DataSet() As DataSet
      Get
         Return mds
      End Get
   End Property
End Class
