' The following is needed for the XmlNode object
Imports System
' The following is for the NameValueCollection
' variable in the Create method
Imports System.Collections.Specialized

Public Class AppConfig
   Implements IConfigurationSectionHandler

   ' Variables created by this class
   Private Shared mstrPhysicalPath As String
   Private Shared mstrURLFragment As String
   Private Shared mstrURLNormal As String
   Private Shared mstrURLSecure As String

   ' Variables read from Config File
   Private Shared mstrConnectString As String
   Private Shared mstrSMTPServer As String

   Public Shared ReadOnly Property PhysicalPath() As String
      Get
         Return mstrPhysicalPath
      End Get
   End Property

   Public Shared ReadOnly Property URLFragment() As String
      Get
         Return mstrURLFragment
      End Get
   End Property

   Public Shared ReadOnly Property URLNormal() As String
      Get
         Return mstrURLNormal
      End Get
   End Property

   Public Shared ReadOnly Property URLSecure() As String
      Get
         Return mstrURLSecure
      End Get
   End Property

   Public Shared ReadOnly Property ConnectString() As String
      Get
         Return mstrConnectString
      End Get
   End Property

   Public Shared ReadOnly Property SMTPServer() As String
      Get
         Return mstrSMTPServer
      End Get
   End Property

   '************************************************
   ' Function to be called by Application_OnStart as described in the
   ' class description. Initializes the application root.
   '************************************************
   Public Shared Sub Init()
      Dim ctx As HttpContext

      ctx = HttpContext.Current
      mstrPhysicalPath = ctx.Server.MapPath(ctx.Request.ApplicationPath)
      mstrURLFragment = ctx.Request.Url.Host & ctx.Request.ApplicationPath
      mstrURLNormal = "http://" & mstrURLFragment
      mstrURLSecure = "https://" & mstrURLFragment

      ConfigurationSettings.GetConfig("customSettings")
   End Sub

   '************************************************
   ' The Create function must be created. It is called
   ' from ASP.NET
   '************************************************
   Public Function Create(ByVal parent As Object, _
                           ByVal configContext As Object, _
                           ByVal input As Xml.XmlNode) As Object Implements IConfigurationSectionHandler.Create

      Dim nvc As NameValueCollection
      Dim nvsh As NameValueSectionHandler
      Dim strValue As String

      Try
         nvsh = New NameValueSectionHandler()

         nvc = CType(nvsh.Create(parent, configContext, input), NameValueCollection)

      Catch exp As Exception
         Throw New ApplicationException("Error Trying to run the Create method in AppConfig class", exp)
      End Try

      If Not (nvc Is Nothing) Then
         Try
            strValue = "ConnectString"
            mstrConnectString = nvc.Item("ConnectString")

            strValue = "SMTPServer"
            mstrSMTPServer = nvc.Item("SMTPServer")

         Catch exp As Exception
            strValue = "Error reading the following Key from <customSettings> section: <Key=""" & strValue & """> Please check the key to make sure it exists and that the value is the correct data type"

            Throw New Exception(strValue, exp)
         End Try
      End If
   End Function
End Class
