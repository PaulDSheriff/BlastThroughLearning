CREATE TABLE ConfigSettings
(
ConnectString Varchar(255) NULL,
SMTPServer Varchar(100) NULL
)