Paul Sheriff Live
---------------------------------------
Below are instructions on how to setup the sample programs for this seminar.

Install the self extracting zip file into a folder on your hard drive into a folder called \BeyondTheBasics. Under this folder you will then find folders for each chapter we covered in the seminar.

Create a virtual directory in IIS called BeyondTheBasics. Map it to the folder where you installed this ZIP file. Then within IIS underneath this "BeyondTheBasics" VD, right mouse click on the following folders and go into properties on each one. Click the "Create" button to create a virtual directory.

Ch04-WebControls
Ch06-ConfigSettingsTest
Ch08-Security\Security-Forms
Ch08-Security\Security-Windows

All the rest of the folders have WinForm apps so you can just load the appropriate .SLN file under each of these folders.
