Imports System.Security.Principal

Public Class SecurityReport
  Inherits System.Web.UI.Page
   Protected WithEvents btnSecure As System.Web.UI.WebControls.Button

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

   End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    SecurityReport()
      'TestDB()
   End Sub

   Private Sub TestDB()
      Dim ds As New DataSet()
      Dim da As SqlClient.SqlDataAdapter

      Try
         da = New SqlClient.SqlDataAdapter("SELECT * FROM Products", "Server=Webprod02;Database=Northwind;Integrated Security=SSPI")

         da.Fill(ds)

      Catch exp As Exception
         Output(exp.Message)
      End Try
   End Sub

   Private Sub SecurityReport()
      Output("User.Identity.IsAuthenticated: " & User.Identity.IsAuthenticated())
      Output("User.Identity.AuthenticationType: " & User.Identity.AuthenticationType)
      Output("User.Identity.Name: " & User.Identity.Name)
      Output("Server.MachineName: " & Server.MachineName)
      Output("")

      ' The two below will not work with Windows authentication
      Output("User.IsInRole(""" & Server.MachineName & "\Administrators""): " & User.IsInRole(Server.MachineName & "\Administrators"))
      Output("User.IsInRole(""" & Server.MachineName & "\Backup Operators""): " & User.IsInRole(Server.MachineName & "\Backup Operators"))
      ' This one will work because it is not a built-in role
      Output("User.IsInRole(""" & Server.MachineName & "\Debugger Users""): " & User.IsInRole(Server.MachineName & "\Debugger Users"))
      Output("")

      Output("Thread: " & System.Threading.Thread.CurrentThread.CurrentPrincipal.Identity.Name)

      If TypeOf User.Identity Is WindowsIdentity Then
         ' To check the built in roles, you must use the enumerations
         Dim wp As WindowsPrincipal
         wp = New WindowsPrincipal(DirectCast(User.Identity, WindowsIdentity))

         Output("wp.IsInRole(WindowsBuiltInRole.Administrator)=" & wp.IsInRole(WindowsBuiltInRole.Administrator))
         Output("wp.IsInRole(WindowsBuiltInRole.BackupOperator)=" & wp.IsInRole(WindowsBuiltInRole.BackupOperator))
         ' The following does not work
         Output("wp.IsInRole(""" & Server.MachineName & "\Administrators"")=" & wp.IsInRole(Server.MachineName & "\Administrators"))
         Output("wp.IsInRole(""" & Server.MachineName & "\Backup Operators"")=" & wp.IsInRole(Server.MachineName & "\Backup Operators"))
         ' The following works
         Output("wp.IsInRole(""" & Server.MachineName & "\Debugger Users"")=" & wp.IsInRole(Server.MachineName & "\Debugger Users"))
      End If
   End Sub

   Private Sub Output(ByVal Msg As String)
      Response.Write("<span id=""lblOutput"" style=""font-size:Large;font-weight:bold;"">" & Msg & "</span><br>")
   End Sub

   Private Sub btnSecure_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSecure.Click
      Response.Redirect("SecurePage.aspx")
   End Sub
End Class
