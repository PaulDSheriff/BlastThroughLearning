CREATE TABLE UsersRoles
(
LoginID varchar(50) NOT NULL PRIMARY KEY,
RoleName varchar(20) NULL
)
GO
INSERT INTO UsersRoles VALUES('Paul', 'Admin')
INSERT INTO UsersRoles VALUES('Ken', 'Supervisor')
INSERT INTO UsersRoles VALUES('Bruce', 'User')
GO