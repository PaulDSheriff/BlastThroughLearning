Imports System.Security.Principal
Imports System.Web.Security

Public Class Login
  Inherits System.Web.UI.Page
  Protected WithEvents Label1 As System.Web.UI.WebControls.Label
  Protected WithEvents txtLogin As System.Web.UI.WebControls.TextBox
  Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
  Protected WithEvents Label3 As System.Web.UI.WebControls.Label
  Protected WithEvents btnLogin As System.Web.UI.WebControls.Button

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

   End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    'Put user code to initialize the page here
  End Sub

  Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
      If LoginValid() Then
         FormsAuthentication.RedirectFromLoginPage(txtLogin.Text, False)
      Else
         lblMessage.Text = "Invalid LoginID/Password"
      End If
  End Sub

  Private Function LoginValid() As Boolean
    Dim ds As New DataSet()
    Dim da As SqlClient.SqlDataAdapter
    Dim strSQL As String
    Dim strConn As String

    strSQL = "SELECT * FROM UsersRoles "
    strSQL &= " WHERE LoginID = '" & txtLogin.Text & "'"
    strConn = "Server=Localhost;Database=Northwind;uid=sa;pwd=sa"

    Try
      da = New SqlClient.SqlDataAdapter(strSQL, strConn)
      da.Fill(ds)

      If ds.Tables(0).Rows.Count = 0 Then
        Return False
      Else
        Return True
      End If

    Catch exp As Exception
      lblMessage.Text = exp.Message

    End Try
  End Function
End Class
