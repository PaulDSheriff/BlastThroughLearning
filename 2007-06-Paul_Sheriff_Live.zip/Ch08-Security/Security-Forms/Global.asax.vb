Imports System.Web
Imports System.Web.SessionState
Imports System.Security.Principal

Public Class Global
   Inherits System.Web.HttpApplication

#Region " Component Designer Generated Code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Component Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'Required by the Component Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Component Designer
   'It can be modified using the Component Designer.
   'Do not modify it using the code editor.
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      components = New System.ComponentModel.Container()
   End Sub

#End Region

   Sub Application_AuthenticateRequest(ByVal sender As Object, ByVal e As EventArgs)
      ' Fires upon attempting to authenticate the use
      Dim astrRoles() As String
      Dim gi As GenericIdentity

      If Request.IsAuthenticated Then
         astrRoles = RoleBuild()

         gi = New GenericIdentity(User.Identity.Name)
         Context.User = New GenericPrincipal(gi, astrRoles)
      End If
   End Sub

   Private Function RoleBuild() As String()
      Dim ds As New DataSet()
      Dim da As SqlClient.SqlDataAdapter
      Dim astrRoles() As String
      Dim strSQL As String
      Dim strConn As String

      strSQL = "SELECT * FROM UsersRoles "
      strSQL &= " WHERE LoginID = '" & User.Identity.Name & "'"
      strConn = "Server=Localhost;Database=Northwind;uid=sa;pwd=sa"

      Try
         da = New SqlClient.SqlDataAdapter(strSQL, strConn)
         da.Fill(ds)

         astrRoles = New String() {ds.Tables(0).Rows(0).Item("RoleName").ToString()}

         Return astrRoles

      Catch exp As Exception
         Throw exp

      End Try
   End Function
End Class
