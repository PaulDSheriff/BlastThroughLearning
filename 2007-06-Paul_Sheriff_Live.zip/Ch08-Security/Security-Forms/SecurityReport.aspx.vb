Imports System.Security.Principal

Public Class SecurityReport
   Inherits System.Web.UI.Page

  Protected WithEvents lnkSignOut As System.Web.UI.WebControls.LinkButton

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

   End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    SecurityReport()
  End Sub

  Private Sub SecurityReport()
    Output("User.Identity.IsAuthenticated: " & User.Identity.IsAuthenticated())
    Output("User.Identity.AuthenticationType: " & User.Identity.AuthenticationType)
    Output("User.Identity.Name: " & User.Identity.Name)
    Output("")

    ' The two below will not work with Windows authentication
    Output("User.IsInRole(""Admin""): " & User.IsInRole("Admin"))
    Output("User.IsInRole(""Supervisor""): " & User.IsInRole("Supervisor"))
    Output("User.IsInRole(""User""): " & User.IsInRole("User"))
    Output("")
  End Sub

  Private Sub Output(ByVal Msg As String)
    Response.Write("<span id=""lblOutput"" style=""font-size:Large;font-weight:bold;"">" & Msg & "</span><br>")
  End Sub

  Private Sub lnkSignOut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnkSignOut.Click
      System.Web.Security.FormsAuthentication.SignOut()
      Session.Abandon()

    Response.Redirect("SecurityReport.aspx")
  End Sub
End Class
