Imports System.Security.Principal

Public Class frmLogin
   Inherits System.Windows.Forms.Form

   Private mboolValidLogon As Boolean

   Property ValidLogon() As Boolean
      Get
         Return mboolValidLogon
      End Get
      Set(ByVal Value As Boolean)
         mboolValidLogon = Value
      End Set
   End Property

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents lblLogin As System.Windows.Forms.Label
   Friend WithEvents txtLogin As System.Windows.Forms.TextBox
   Friend WithEvents btnLogin As System.Windows.Forms.Button
   Friend WithEvents btnCancel As System.Windows.Forms.Button
   Friend WithEvents Label1 As System.Windows.Forms.Label
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.lblLogin = New System.Windows.Forms.Label()
      Me.txtLogin = New System.Windows.Forms.TextBox()
      Me.btnLogin = New System.Windows.Forms.Button()
      Me.btnCancel = New System.Windows.Forms.Button()
      Me.Label1 = New System.Windows.Forms.Label()
      Me.SuspendLayout()
      '
      'lblLogin
      '
      Me.lblLogin.Location = New System.Drawing.Point(8, 8)
      Me.lblLogin.Name = "lblLogin"
      Me.lblLogin.Size = New System.Drawing.Size(96, 24)
      Me.lblLogin.TabIndex = 5
      Me.lblLogin.Text = "Enter Login ID"
      Me.lblLogin.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
      '
      'txtLogin
      '
      Me.txtLogin.Location = New System.Drawing.Point(112, 8)
      Me.txtLogin.Name = "txtLogin"
      Me.txtLogin.Size = New System.Drawing.Size(192, 20)
      Me.txtLogin.TabIndex = 1
      Me.txtLogin.Text = ""
      '
      'btnLogin
      '
      Me.btnLogin.Location = New System.Drawing.Point(224, 40)
      Me.btnLogin.Name = "btnLogin"
      Me.btnLogin.TabIndex = 5
      Me.btnLogin.Text = "Login"
      '
      'btnCancel
      '
      Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
      Me.btnCancel.Location = New System.Drawing.Point(144, 40)
      Me.btnCancel.Name = "btnCancel"
      Me.btnCancel.TabIndex = 4
      Me.btnCancel.Text = "Cancel"
      '
      'Label1
      '
      Me.Label1.Location = New System.Drawing.Point(8, 40)
      Me.Label1.Name = "Label1"
      Me.Label1.Size = New System.Drawing.Size(104, 24)
      Me.Label1.TabIndex = 6
      Me.Label1.Text = "Use Paul, Ken or Bruce"
      '
      'frmLogin
      '
      Me.AcceptButton = Me.btnLogin
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.CancelButton = Me.btnCancel
      Me.ClientSize = New System.Drawing.Size(314, 68)
      Me.ControlBox = False
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label1, Me.btnCancel, Me.btnLogin, Me.txtLogin, Me.lblLogin})
      Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
      Me.MaximizeBox = False
      Me.MinimizeBox = False
      Me.Name = "frmLogin"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
      Me.Text = "Please Login..."
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
      mboolValidLogon = False
      Me.Close()
   End Sub

   Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
      Dim astrRoles() As String
      Dim gi As GenericIdentity
      Dim gp As GenericPrincipal

      Me.Cursor = Cursors.WaitCursor

      If LoginValid() Then
         astrRoles = RoleBuild()

         gi = New GenericIdentity(txtLogin.Text)
         gp = New GenericPrincipal(gi, astrRoles)
         System.Threading.Thread.CurrentThread.CurrentPrincipal = gp

         mboolValidLogon = True

         Me.Cursor = Cursors.Default

         Me.Close()
      Else
         Me.Cursor = Cursors.Default

         MessageBox.Show("Invalid Login ID")
      End If
   End Sub

   Private Function LoginValid() As Boolean
      Dim ds As New DataSet()
      Dim da As SqlClient.SqlDataAdapter
      Dim strSQL As String

      strSQL = "SELECT * FROM UsersRoles "
      strSQL &= " WHERE LoginID = '" & txtLogin.Text & "'"

      Try
         da = New SqlClient.SqlDataAdapter(strSQL, _
          AppConfig.ConnectString)
         da.Fill(ds)

         Return ds.Tables(0).Rows.Count > 0

      Catch exp As Exception
         MessageBox.Show(exp.Message)

      End Try
   End Function

   Private Function RoleBuild() As String()
      Dim ds As New DataSet()
      Dim da As SqlClient.SqlDataAdapter
      Dim astrRoles() As String
      Dim strSQL As String

      strSQL = "SELECT * FROM UsersRoles "
      strSQL &= " WHERE LoginID = '" & txtLogin.Text & "'"

      Try
         da = New SqlClient.SqlDataAdapter(strSQL, AppConfig.ConnectString)
         da.Fill(ds)

         astrRoles = New String() {ds.Tables(0).Rows(0). _
          Item("RoleName").ToString()}

         Return astrRoles

      Catch exp As Exception
         MessageBox.Show(exp.Message)

      End Try
   End Function
End Class