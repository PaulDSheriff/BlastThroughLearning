Imports System.Security.Principal

Public Class frmSecurityReport
   Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents txtSecurity As System.Windows.Forms.TextBox
   Friend WithEvents btnProtected As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.txtSecurity = New System.Windows.Forms.TextBox()
      Me.btnProtected = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'txtSecurity
      '
      Me.txtSecurity.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.txtSecurity.Location = New System.Drawing.Point(8, 8)
      Me.txtSecurity.Multiline = True
      Me.txtSecurity.Name = "txtSecurity"
      Me.txtSecurity.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
      Me.txtSecurity.Size = New System.Drawing.Size(400, 200)
      Me.txtSecurity.TabIndex = 0
      Me.txtSecurity.Text = ""
      '
      'btnProtected
      '
      Me.btnProtected.Location = New System.Drawing.Point(8, 216)
      Me.btnProtected.Name = "btnProtected"
      Me.btnProtected.Size = New System.Drawing.Size(112, 40)
      Me.btnProtected.TabIndex = 1
      Me.btnProtected.Text = "Call Protected Method"
      '
      'frmSecurityReport
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(416, 282)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnProtected, Me.txtSecurity})
      Me.Name = "frmSecurityReport"
      Me.Text = "Security Report"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub frmSecurityReport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      If AppConfig.FormsAuthentication Then
         FormsAuthenticationReport()
      ElseIf AppConfig.SetPrincipalPolicy Then
         PrincipalPolicyReport()
      Else
         WindowsAuthenticationReport()
      End If
   End Sub

   Private Sub FormsAuthenticationReport()
      Dim gp As GenericPrincipal

      Me.Cursor = Cursors.WaitCursor

      gp = DirectCast(System.Threading.Thread. _
       CurrentThread.CurrentPrincipal, GenericPrincipal)

      Output("Identity.IsAuthenticated: " & gp.Identity.IsAuthenticated)
      Output("Identity.AuthenticationType: " & gp.Identity.AuthenticationType)
      Output("Identity.Name: " & gp.Identity.Name)
      Output("")

      Output("cp.IsInRole(""Admin""): " & gp.IsInRole("Admin"))
      Output("cp.IsInRole(""Supervisor""): " & gp.IsInRole("Supervisor"))
      Output("cp.IsInRole(""User""): " & gp.IsInRole("User"))

      Me.Cursor = Cursors.Default
   End Sub

   Private Sub WindowsAuthenticationReport()
      Dim wid As WindowsIdentity
      Dim wp As WindowsPrincipal

      Me.Cursor = Cursors.WaitCursor

      wid = WindowsIdentity.GetCurrent()

      wp = New WindowsPrincipal(wid)

      Output("Identity.IsAuthenticated: " & wp.Identity.IsAuthenticated)
      Output("Identity.AuthenticationType: " & wp.Identity.AuthenticationType)
      Output("Identity.Name: " & wp.Identity.Name)
      Output("MachineName: " & Environment.MachineName)
      Output("")

      ' The following does NOT work because it is a built-in role
      ' Must use the enumerators on built-in roles
      Output("wp.IsInRole(""" & Environment.MachineName & "\Administrators""): " & wp.IsInRole(Environment.MachineName & "\Administrators"))

      ' The following does work
      Output("wp.IsInRole(WindowsBuiltInRole.Administrator): " & wp.IsInRole(WindowsBuiltInRole.Administrator))

      ' The following works because it is NOT a built-in role
      Output("wp.IsInRole(""" & Environment.MachineName & "\Debugger Users""): " & wp.IsInRole(Environment.MachineName & "\Debugger Users"))

      Me.Cursor = Cursors.Default
   End Sub

   Private Sub PrincipalPolicyReport()
      Dim wp As System.Security.Principal.WindowsPrincipal

      Me.Cursor = Cursors.WaitCursor

      wp = DirectCast(System.Threading.Thread.CurrentThread.CurrentPrincipal, WindowsPrincipal)

      Output("Identity.IsAuthenticated: " & wp.Identity.IsAuthenticated)
      Output("Identity.AuthenticationType: " & wp.Identity.AuthenticationType)
      Output("Identity.Name: " & wp.Identity.Name)
      Output("MachineName: " & Environment.MachineName)
      Output("")

      ' The following does NOT work
      Output("wp.IsInRole(""" & Environment.MachineName & "\Administrators""): " & wp.IsInRole(Environment.MachineName & "\Administrators"))

      ' The following does work
      Output("wp.IsInRole(WindowsBuiltInRole.Administrator): " & wp.IsInRole(WindowsBuiltInRole.Administrator))

      ' The following works because it is NOT a built-in role
      Output("wp.IsInRole(""" & Environment.MachineName & "\Debugger Users""): " & wp.IsInRole(Environment.MachineName & "\Debugger Users"))

      Me.Cursor = Cursors.Default
   End Sub

   Private Sub Output(ByVal Msg As String)
      txtSecurity.AppendText(Msg & ControlChars.CrLf)
   End Sub

   Private Sub ShowWindowsIdentity()
      Dim wid As WindowsIdentity
      Dim wp As WindowsPrincipal

      ' Get Current Identity
      wid = WindowsIdentity.GetCurrent()

      'Put the identity into a principal object.
      wp = New WindowsPrincipal(wid)

      Debug.WriteLine(wp.Identity.IsAuthenticated)
      Debug.WriteLine(wp.Identity.AuthenticationType)
      Debug.WriteLine(wp.Identity.Name)
      Debug.WriteLine(wp.IsInRole(WindowsBuiltInRole.Administrator))
   End Sub
End Class
