Imports System.Security.Principal

Module modMain
   Sub Main()
      Dim frm As Form

      If AppConfig.FormsAuthentication Then
         frm = New frmLogin()

         frm.ShowDialog()
         If DirectCast(frm, frmLogin).ValidLogon Then
            frm = New frmSecurityReport()

            Application.Run(frm)
         End If
      Else
         frm = New frmSecurityReport()

         If AppConfig.SetPrincipalPolicy Then
            ' Assign Windows Principal to current application
            AppDomain.CurrentDomain.SetPrincipalPolicy(PrincipalPolicy.WindowsPrincipal)
         End If

         Application.Run(frm)
      End If
   End Sub
End Module
