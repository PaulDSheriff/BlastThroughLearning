Imports System.Configuration

Public Class AppConfig
   Public Shared ReadOnly Property ConnectString() As String
      Get
         Return ConfigurationSettings.AppSettings("ConnectString")
      End Get
   End Property

   Public Shared ReadOnly Property FormsAuthentication() As Boolean
      Get
         Return Convert.ToBoolean(ConfigurationSettings.AppSettings("FormsAuthentication"))
      End Get
   End Property

   Public Shared ReadOnly Property SetPrincipalPolicy() As Boolean
      Get
         Return Convert.ToBoolean(ConfigurationSettings.AppSettings("SetPrincipalPolicy"))
      End Get
   End Property
End Class
