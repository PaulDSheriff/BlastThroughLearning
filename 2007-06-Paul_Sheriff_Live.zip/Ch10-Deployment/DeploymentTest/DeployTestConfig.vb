Imports System.ComponentModel
Imports System.Configuration.Install

<RunInstaller(True)> Public Class DeployTestConfig
    Inherits System.Configuration.Install.Installer

#Region " Component Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Installer overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub

#End Region

  Public Overrides Sub Install(ByVal stateSaver As System.Collections.IDictionary)
    Dim strConfig As String

    Try
      ' Call any other Installers
      MyBase.Install(stateSaver)

      ' Get the Path from the Custom Action Item
      strConfig = Me.Context.Parameters.Item("ConfigFile").ToString()


         ' Change Server name in Web.Config file
      ModifyConfig(strConfig)

    Catch exp As Exception
      MessageBox.Show(exp.Message)

    End Try
  End Sub

  Private Sub ModifyConfig(ByVal ConfigFile As String)
    Dim xd As New System.Xml.XmlDocument()
    Dim xn As System.Xml.XmlNode
    Dim strXPath As String

    Try
      ' Load Config File
      xd.Load(ConfigFile)

      ' Get the ConnectString node
      xn = xd.SelectSingleNode("/configuration/appSettings/add[@key='ConnectString']")

      ' Change the Computer Name
      xn.Attributes("value").Value = "Server=" & _
           Me.Context.Parameters.Item("ComputerName").ToString() & _
           ";Database=Northwind;uid=sa;pwd="

      ' Resave Config File
      xd.Save(ConfigFile)

    Catch exp As Exception
      MessageBox.Show(exp.Message)

    End Try
  End Sub

   Public Overrides Sub Uninstall(ByVal savedState As System.Collections.IDictionary)

   End Sub
End Class
