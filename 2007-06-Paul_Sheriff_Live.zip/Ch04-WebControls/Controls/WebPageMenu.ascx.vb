Public MustInherit Class WebPageMenu
    Inherits System.Web.UI.UserControl

   Public WithEvents dlstHeader As System.Web.UI.WebControls.DataList

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            MenuLoad()
        End If
    End Sub

    Private Sub MenuLoad()
      Dim ds As New DataSet()

      Try
         ' Pre initialize Session variable
         ds.ReadXml(Server.MapPath("../xml/MenuHeader.xml"))

         ' Bind the datalist to the dataview
         dlstHeader.DataSource = ds
         dlstHeader.DataBind()

      Catch exp As Exception
         Response.Write(exp.ToString())

      End Try
   End Sub

   Private Sub dlstHeader_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataListCommandEventArgs) Handles dlstHeader.ItemCommand
      Dim lnk As LinkButton

      lnk = CType(e.CommandSource, LinkButton)

      Session("Title") = e.CommandName

      ' Redirect to the next page
      Response.Redirect(lnk.CommandArgument.ToString, True)
   End Sub
End Class
