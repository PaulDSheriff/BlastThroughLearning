Public MustInherit Class WebPageLeftNav
    Inherits System.Web.UI.UserControl

   Public WithEvents dlstLeftNav As System.Web.UI.WebControls.DataList

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

   End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            NavigationLoad()
        End If
    End Sub

    Private Sub NavigationLoad()
      Dim ds As New DataSet()
      Dim dv As DataView
      Dim strTitle As String

      Try
         strTitle = Session("Title").ToString()

         ds.ReadXml(Server.MapPath("../xml/MenuLeftNav.xml"))
         dv = ds.Tables(0).DefaultView
         dv.RowFilter = "Title='" & strTitle & "'"

         dlstLeftNav.DataSource = dv
         dlstLeftNav.DataBind()

      Catch exp As Exception
         Response.Write(exp.ToString())

      End Try
   End Sub
End Class
