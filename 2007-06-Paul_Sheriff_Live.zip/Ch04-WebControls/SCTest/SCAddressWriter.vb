Imports System.ComponentModel
Imports System.Web.UI
Imports System.Web

<DefaultProperty("Text"), ToolboxData("<{0}:SCAddress runat=server></{0}:SCAddress>")> Public Class SCAddressWriter
   Inherits System.Web.UI.WebControls.WebControl

   Private mstrName As String
   Private mstrAddress As String
   Private mstrCSZ As String

   <Bindable(True), Category("Appearance"), DefaultValue("")> Property Name() As String
      Get
         Return mstrName
      End Get

      Set(ByVal Value As String)
         mstrName = Value
      End Set
   End Property

   <Bindable(True), Category("Appearance"), DefaultValue("")> Property Address() As String
      Get
         Return mstrAddress
      End Get

      Set(ByVal Value As String)
         mstrAddress = Value
      End Set
   End Property

   <Bindable(True), Category("Appearance"), DefaultValue("")> Property CSZ() As String
      Get
         Return mstrCSZ
      End Get

      Set(ByVal Value As String)
         mstrCSZ = Value
      End Set
   End Property

   Protected Overrides Sub Render(ByVal output As System.Web.UI.HtmlTextWriter)
      With output
         ' <p>
         .RenderBeginTag("p")
         ' <span>...</span>
         .RenderBeginTag("span")
         .WriteAttribute("id", Me.UniqueID & "_lblAddrName")
         .WriteStyleAttribute("width", "110px")
         .Write("Name")
         .RenderEndTag()
         ' <input>...</input>
         .RenderBeginTag("input")
         .WriteAttribute("type", "text")
         .WriteAttribute("id", Me.UniqueID & "_txtName")
         ' </p>
         .RenderEndTag()

         ' <p>
         .RenderBeginTag("p")
         ' <span>...</span>
         .RenderBeginTag("span")
         .WriteAttribute("id", Me.UniqueID & "_lblAddress")
         .WriteStyleAttribute("width", "110px")
         .Write("Address")
         .RenderEndTag()
         ' <input>...</input>
         .RenderBeginTag("input")
         .WriteAttribute("type", "text")
         .WriteAttribute("id", Me.UniqueID & "_txtAddress")
         ' </p>
         .RenderEndTag()

         ' <p>
         .RenderBeginTag("p")
         ' <span>...</span>
         .RenderBeginTag("span")
         .WriteAttribute("id", Me.UniqueID & "_lblCSZ")
         .WriteStyleAttribute("width", "110px")
         .Write("City, State, ZIP")
         .RenderEndTag()
         ' <input>...</input>
         .RenderBeginTag("input")
         .WriteAttribute("type", "text")
         .WriteAttribute("id", Me.UniqueID & "_txtCSZ")
         ' </p>
         .RenderEndTag()
      End With
   End Sub

   Protected Overrides Sub OnLoad(ByVal e As System.EventArgs)
      If Page.IsPostBack Then
         With HttpContext.Current
            mstrName = .Request(Me.UniqueID & "_txtName")
            mstrAddress = .Request(Me.UniqueID & "_txtAddress")
            mstrCSZ = .Request(Me.UniqueID & "_txtCSZ")
         End With
      End If

      MyBase.OnLoad(e)
   End Sub
End Class
