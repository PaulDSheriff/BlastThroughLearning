Imports System.ComponentModel
Imports System.Web.UI

<DefaultProperty("DataTable"), _
ToolboxData("<{0}:SCDropDown runat=server></{0}:SCDropDown>")> _
Public Class SCDropDown
   Inherits System.Web.UI.WebControls.DropDownList

   Private mstrConnect As String = ""
   Private mstrDataTable As String = ""

   <Bindable(True), Category("Data"), DefaultValue("")> Public Property DataTable() As String
      Get
         Return mstrDataTable
      End Get
      Set(ByVal Value As String)
         mstrDataTable = Value
      End Set
   End Property

   <Bindable(True), Category("Data"), DefaultValue("")> Property ConnectString() As String
      Get
         Return mstrConnect
      End Get

      Set(ByVal Value As String)
         mstrConnect = Value
      End Set
   End Property

   Protected Overrides Sub Render(ByVal output As System.Web.UI.HtmlTextWriter)
      MyBase.Render(output)
   End Sub

   Public Overrides Sub DataBind()
      Dim strSQL As String
      Dim strConn As String

      Try
         ' Make sure properties are filled in
         Check()

         ' Build SQL String
         strSQL = String.Format("SELECT {0}, {1} FROM {2}", _
         DataTextField, DataValueField, DataTable)

         ' Fill in DataSource
         MyBase.DataSource = _
             GetDataSet(strSQL)

         ' Bind the Data
         MyBase.DataBind()

      Catch
         Throw

      End Try
   End Sub

   Private Function GetDataSet(ByVal SQL As String) As DataSet
      Dim ds As New DataSet()
      Dim da As SqlClient.SqlDataAdapter

      Try
         da = New SqlClient.SqlDataAdapter(SQL, mstrConnect)

         da.Fill(ds)

         Return ds

      Catch exp As Exception
         Throw
      End Try
   End Function

   Private Sub Check()
      Dim strProp As String

      ' Check to see if all values are filled in correctly
      If DataTextField.Trim() = "" Then
         strProp &= "DataTextField"
      End If
      If DataValueField.Trim() = "" Then
         strProp &= ", DataValueField"
      End If
      If mstrDataTable.Trim() = "" Then
         strProp &= ",DataTable"
      End If
      If mstrConnect.Trim() = "" Then
         strProp &= ",ConnectString"
      End If

      If strProp <> "" Then
         strProp = "The following properties are required: " & strProp
         Throw New ApplicationException(strProp)
      End If
   End Sub
End Class