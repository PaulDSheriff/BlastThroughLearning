Imports System.ComponentModel
Imports System.Web.UI

<DefaultProperty("Text"), _
ToolboxData("<{0}:NewTextBox runat=server></{0}:NewTextBox>")> _
Public Class NewTextBox
  Inherits System.Web.UI.WebControls.TextBox

   Public Event StatusMessage(ByVal Message As String)

  Private mHBColor As System.Drawing.KnownColor
  Private mHFColor As System.Drawing.KnownColor
  Private mboolHBold As Boolean

  Public Property HighlightBold() As Boolean
    Get
      Return mboolHBold
    End Get
    Set(ByVal Value As Boolean)
      mboolHBold = Value
    End Set
  End Property

  Public Property HighlightBackColor() As System.Drawing.KnownColor
    Get
      Return mHBColor
    End Get
    Set(ByVal Value As System.Drawing.KnownColor)
      mHBColor = Value
    End Set
  End Property

  Public Property HighlightForeColor() As System.Drawing.KnownColor
    Get
      Return mHFColor
    End Get
    Set(ByVal Value As System.Drawing.KnownColor)
      mHFColor = Value
    End Set
  End Property

  Public Sub New()
    MyBase.New()

    mHBColor = System.Drawing.KnownColor.Yellow
    mHFColor = System.Drawing.KnownColor.Black
    mboolHBold = True
  End Sub

   Protected Overrides Sub Render(ByVal output As System.Web.UI.HtmlTextWriter)
      RaiseEvent StatusMessage("This is the Render Event")

      MyBase.Render(output)
   End Sub

   Protected Overrides Sub OnPreRender(ByVal e As System.EventArgs)
      Dim sb As New System.Text.StringBuilder(1000)
      Dim strFunction As String

      sb.Append("<script language=""Javascript"">" & ControlChars.CrLf)
      sb.Append("function txtFocus(varBackColor, varForeColor, varBold)" & ControlChars.CrLf)
      sb.Append("{" & ControlChars.CrLf)
      sb.Append("event.srcElement.style.backgroundColor = varBackColor;" & ControlChars.CrLf)
      sb.Append("event.srcElement.style.color = varForeColor;" & ControlChars.CrLf)
      If mboolHBold Then
         sb.Append("event.srcElement.style.fontWeight = varBold" & ControlChars.CrLf)
      End If
      sb.Append("}" & ControlChars.CrLf)

      sb.Append(ControlChars.CrLf & ControlChars.CrLf)

      sb.Append("function txtBlur()" & ControlChars.CrLf)
      sb.Append("{" & ControlChars.CrLf)
      sb.Append("event.srcElement.style.backgroundColor = 'white';" & ControlChars.CrLf)
      sb.Append("event.srcElement.style.color = 'black';" & ControlChars.CrLf)
      sb.Append("event.srcElement.style.fontWeight = 'normal'" & ControlChars.CrLf)
      sb.Append("}" & ControlChars.CrLf)
      sb.Append("</script>" & ControlChars.CrLf)

      If Not Page.IsClientScriptBlockRegistered("NewTextBox_JS") Then
         Page.RegisterClientScriptBlock("NewTextBox_JS", sb.ToString())
      End If

      strFunction = "txtFocus('{0}', '{1}', '{2}');"
      strFunction = String.Format(strFunction, Me.mHBColor.ToString(), Me.mHFColor.ToString(), IIf(Me.mboolHBold, "bold", "normal").ToString())
      Me.Attributes.Add("onfocus", strFunction)

      Me.Attributes.Add("onblur", "txtBlur();")
   End Sub
End Class
