Imports System.ComponentModel
Imports System.Web.UI
Imports System.Web

<DefaultProperty("Text"), ToolboxData("<{0}:SCAddress runat=server></{0}:SCAddress>")> Public Class SCAddress
   Inherits System.Web.UI.WebControls.WebControl

   Private mstrName As String
   Private mstrAddress As String
   Private mstrCSZ As String

   <Bindable(True), Category("Appearance"), DefaultValue("")> Property Name() As String
      Get
         Return mstrName
      End Get

      Set(ByVal Value As String)
         mstrName = Value
      End Set
   End Property

   <Bindable(True), Category("Appearance"), DefaultValue("")> Property Address() As String
      Get
         Return mstrAddress
      End Get

      Set(ByVal Value As String)
         mstrAddress = Value
      End Set
   End Property

   <Bindable(True), Category("Appearance"), DefaultValue("")> Property CSZ() As String
      Get
         Return mstrCSZ
      End Get

      Set(ByVal Value As String)
         mstrCSZ = Value
      End Set
   End Property

   Protected Overrides Sub Render(ByVal output As System.Web.UI.HtmlTextWriter)
      Dim sb As New System.Text.StringBuilder(1000)

      sb.Append("<P>" & ControlChars.CrLf)
      sb.Append("<span id=""" & Me.UniqueID & "_lblAddrName"" style=""width:110px;"">Name</span>" & ControlChars.CrLf)
      sb.Append("<input name=""" & Me.UniqueID & "_txtName"" type=""text"" id=""SCAddr_txtName"" /></P>" & ControlChars.CrLf)
      sb.Append("<P>" & ControlChars.CrLf)
      sb.Append("<span id=""" & Me.UniqueID & "_lblAddress"" style=""width:110px;"">Address</span>" & ControlChars.CrLf)
      sb.Append("<input id=""" & Me.UniqueID & "_txtAddress"" type=""text"" /></P>" & ControlChars.CrLf)
      sb.Append("<P>" & ControlChars.CrLf)
      sb.Append("<span id=""" & Me.UniqueID & "_lblCSZ"" style=""width:110px;"">City, State ZIP</span>" & ControlChars.CrLf)
      sb.Append("<input id=""" & Me.UniqueID & "_txtCSZ"" type=""text""  /></P>" & ControlChars.CrLf)

      output.Write(sb.ToString())
   End Sub

   Protected Overrides Sub OnLoad(ByVal e As System.EventArgs)
      If Page.IsPostBack Then
         With HttpContext.Current
            mstrName = .Request(Me.UniqueID & "_txtName")
            mstrAddress = .Request(Me.UniqueID & "_txtAddress")
            mstrCSZ = .Request(Me.UniqueID & "_txtCSZ")
         End With
      End If

      MyBase.OnLoad(e)
   End Sub
End Class
