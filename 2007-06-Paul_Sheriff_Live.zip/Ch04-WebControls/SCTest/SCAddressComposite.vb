Imports System.ComponentModel
Imports System.Web.UI
Imports System.Web.UI.WebControls

<DefaultProperty("Name"), ToolboxData("<{0}:SCAddressComposite runat=server></{0}:SCAddressComposite>")> Public Class SCAddressComposite
   Inherits System.Web.UI.WebControls.WebControl
   Implements INamingContainer

   Private mstrName As String
   Private mstrAddress As String
   Private mstrCSZ As String

   <Bindable(True), Category("Appearance"), DefaultValue("")> Property Name() As String
      Get
         Me.EnsureChildControls()
         Return mstrName
      End Get

      Set(ByVal Value As String)
         Me.EnsureChildControls()
         mstrName = Value
      End Set
   End Property

   <Bindable(True), Category("Appearance"), DefaultValue("")> Property Address() As String
      Get
         Me.EnsureChildControls()
         Return mstrAddress
      End Get

      Set(ByVal Value As String)
         Me.EnsureChildControls()
         mstrAddress = Value
      End Set
   End Property

   <Bindable(True), Category("Appearance"), DefaultValue("")> Property CSZ() As String
      Get
         Me.EnsureChildControls()
         Return mstrCSZ
      End Get

      Set(ByVal Value As String)
         Me.EnsureChildControls()
         mstrCSZ = Value
      End Set
   End Property

   Protected Overrides Sub Render(ByVal output As System.Web.UI.HtmlTextWriter)
      Me.EnsureChildControls()
      MyBase.Render(output)
   End Sub

   Protected Overrides Sub CreateChildControls()
      Dim txt As TextBox
      Dim lbl As Label
      Dim lit As Literal

      lit = New Literal()
      lit.Text = "<p>"
      Me.Controls.Add(lit)

      lbl = New Label()
      lbl.Text = "Name"
      lbl.Width = New Unit("110px")
      lbl.ID = Me.UniqueID & "lbl1"
      Me.Controls.Add(lbl)

      txt = New TextBox()
      txt.ID = Me.UniqueID & "_txtName"
      Me.Controls.Add(txt)

      lit = New Literal()
      lit.Text = "</p>"
      Me.Controls.Add(lit)
   End Sub
End Class
